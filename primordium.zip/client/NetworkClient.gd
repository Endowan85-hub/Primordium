class_name NetworkClient
extends Node

# =============================================================
# NETWORK CLIENT
# Connects to the server via WebSocket.
# Sends player actions, receives game state updates.
# Never simulates - only relays.
# =============================================================


signal connected_to_server()
signal disconnected_from_server()
signal handshake_complete(player_id: int)
signal message_received(message: Dictionary)

# Specific signals for common message types
signal tick_received(tick: int, day: int, season: String, year: int)
signal init_received(data: Dictionary)
signal city_updated(city_id: int, city: Dictionary)
signal unit_updated(unit_id: int, unit: Dictionary)
signal unit_removed(unit_id: int)
signal actions_received(unit_id: int, tile_x: int, tile_y: int, actions: Array)
signal tile_chunk_received(tiles: Dictionary)
signal tile_updated(x: int, y: int, tile: Dictionary)
signal event_received(event: Dictionary)
signal day_changed(day: int, season: String, year: int)
signal season_changed(season: String)


var _client: WebSocketPeer
var _status: WebSocketPeer.State = WebSocketPeer.STATE_CLOSED

var player_id: int    = -1
var player_name: String = ""
var connected: bool   = false

var _server_url: String = ""
var _reconnect_timer: float = 0.0
var _reconnect_interval: float = 5.0
var _should_reconnect: bool = false


# -------------------------------------------------------------
# CONNECT TO SERVER
# -------------------------------------------------------------
func connect_to_server(url: String, name: String) -> void:
	player_name  = name
	_server_url  = url
	_should_reconnect = true
	_do_connect()


func _do_connect() -> void:
	_client = WebSocketPeer.new()
	var err  = _client.connect_to_url(_server_url)
	if err != OK:
		push_error("Failed to connect to server: " + _server_url)
		return
	_status = WebSocketPeer.STATE_CONNECTING
	print("Connecting to ", _server_url, "...")


func disconnect_from_server() -> void:
	_should_reconnect = false
	if _client:
		_client.close()
	connected = false


# -------------------------------------------------------------
# PROCESS
# -------------------------------------------------------------
func _process(delta: float) -> void:
	if not _client:
		return

	_client.poll()
	var new_status = _client.get_ready_state()

	if new_status != _status:
		_status = new_status
		match _status:
			WebSocketPeer.STATE_OPEN:
				print("Connected to server.")
				connected = true
				emit_signal("connected_to_server")
				_send_handshake()

			WebSocketPeer.STATE_CLOSED:
				print("Disconnected from server.")
				connected = false
				emit_signal("disconnected_from_server")
				if _should_reconnect:
					_reconnect_timer = _reconnect_interval
				player_id = -1

	# Read incoming packets
	while _client and _client.get_available_packet_count() > 0:
		var packet = _client.get_packet()
		_handle_packet(packet)

	# Reconnect timer
	if not connected and _should_reconnect and _reconnect_timer > 0:
		_reconnect_timer -= delta
		if _reconnect_timer <= 0:
			print("Attempting reconnect...")
			_do_connect()


# -------------------------------------------------------------
# HANDSHAKE
# -------------------------------------------------------------
func _send_handshake() -> void:
	var msg: Dictionary = {
		"type": "handshake",
		"name": player_name
	}
	# Include player_id if reconnecting
	if player_id > 0:
		msg["player_id"] = player_id
	send(msg)


# -------------------------------------------------------------
# PACKET HANDLING
# -------------------------------------------------------------
func _handle_packet(packet: PackedByteArray) -> void:
	var text = packet.get_string_from_utf8()
	var json = JSON.new()
	var err  = json.parse(text)
	if err != OK:
		push_warning("Malformed packet from server: ", text)
		return

	var message = json.get_data()
	if not message is Dictionary:
		return

	var msg_type = message.get("type", "")

	# Handle specific message types
	match msg_type:
		"handshake_ack":
			player_id = message.get("player_id", -1)
			print("Handshake complete. Player ID: ", player_id)
			emit_signal("handshake_complete", player_id)

		"init":
			emit_signal("init_received", message)

		"tick":
			emit_signal("tick_received",
				message.get("tick", 0),
				message.get("day", 0),
				message.get("season", "spring"),
				message.get("year", 1)
			)

		"day_changed":
			emit_signal("day_changed",
				message.get("day", 0),
				message.get("season", "spring"),
				message.get("year", 1)
			)

		"season_changed":
			emit_signal("season_changed", message.get("season", "spring"))

		"city_update":
			emit_signal("city_updated",
				message.get("city_id", -1),
				message.get("city", {})
			)

		"actions_response":
			emit_signal("actions_received",
				message.get("unit_id", -1),
				message.get("tile_x", -1),
				message.get("tile_y", -1),
				message.get("actions", []))

		"unit_update":
			emit_signal("unit_updated",
				message.get("unit_id", -1),
				message.get("unit", {})
			)

		"unit_removed":
			emit_signal("unit_removed", int(message.get("unit_id", -1)))

		"tile_chunk":
			emit_signal("tile_chunk_received", message.get("tiles", {}))

		"tile_update":
			emit_signal("tile_updated",
				message.get("x", 0),
				message.get("y", 0),
				message.get("tile", {})
			)

		"event":
			emit_signal("event_received", message.get("event", {}))

		"heartbeat":
			# Just a keepalive - no action needed
			pass

		"dev_ack":
			print("[DEV SERVER] ", message.get("msg", ""))

	# Always emit the generic signal too
	emit_signal("message_received", message)


# -------------------------------------------------------------
# SENDING ACTIONS TO SERVER
# -------------------------------------------------------------
func send(message: Dictionary) -> void:
	if not _client or _status != WebSocketPeer.STATE_OPEN:
		push_warning("Cannot send - not connected")
		return
	_client.send_text(JSON.stringify(message))


# Unit actions
func send_move_unit(unit_id: int, target_x: int, target_y: int) -> void:
	send({
		"type":    "move_unit",
		"unit_id": unit_id,
		"x":       target_x,
		"y":       target_y
	})


func send_set_path(unit_id: int, path: Array) -> void:
	var path_data: Array = []
	for p in path:
		path_data.append({"x": p.x, "y": p.y})
	send({
		"type":    "set_path",
		"unit_id": unit_id,
		"path":    path_data
	})


func send_cancel_move(unit_id: int) -> void:
	send({
		"type":    "cancel_move",
		"unit_id": unit_id
	})


func send_get_actions(unit_id: int, tile_x: int, tile_y: int) -> void:
	send({
		"type":    "get_actions",
		"unit_id": unit_id,
		"x":       tile_x,
		"y":       tile_y
	})


func send_do_action(action_id: String, unit_id: int,
		tile_x: int, tile_y: int, text_input: String = "") -> void:
	send({
		"type":       "do_action",
		"action_id":  action_id,
		"unit_id":    unit_id,
		"x":          tile_x,
		"y":          tile_y,
		"text_input": text_input
	})


func send_found_city(unit_id: int, city_name: String) -> void:
	send({
		"type":    "found_city",
		"unit_id": unit_id,
		"name":    city_name
	})


func send_assign_workers(city_id: int, farmers: int,
		woodcutters: int, miners: int, researchers: int) -> void:
	send({
		"type":        "assign_workers",
		"city_id":     city_id,
		"farmers":     farmers,
		"woodcutters": woodcutters,
		"miners":      miners,
		"researchers": researchers
	})


func send_resolve_event(event_id: String, choice_index: int) -> void:
	send({
		"type":     "resolve_event",
		"event_id": event_id,
		"choice":   choice_index
	})


func send_request_tiles(coords: Array) -> void:
	var coords_data: Array = []
	for c in coords:
		coords_data.append({"x": c.x, "y": c.y})
	send({
		"type":   "request_tiles",
		"coords": coords_data
	})


# Dev commands
func dev_set_timescale(scale: float) -> void:
	send({"type": "dev_timescale", "scale": scale})


func dev_give_resources(city_id: int,
		food: float, wood: float, stone: float) -> void:
	send({
		"type":    "dev_give",
		"city_id": city_id,
		"food":    food,
		"wood":    wood,
		"stone":   stone
	})


func dev_reveal_map() -> void:
	send({"type": "dev_reveal"})


func dev_set_day(day: int) -> void:
	send({"type": "dev_day", "day": day})


func dev_spawn_unit(unit_type: String, x: int, y: int) -> void:
	send({
		"type":      "dev_spawn",
		"unit_type": unit_type,
		"x":         x,
		"y":         y
	})


func send_village_build(city_id: int, building_type: int, gx: int, gy: int) -> void:
	send({
		"type":          "village_build",
		"city_id":       city_id,
		"building_type": building_type,
		"gx":            gx,
		"gy":            gy,
	})


func send_village_role(city_id: int, role: String, delta: int) -> void:
	send({
		"type":    "village_role",
		"city_id": city_id,
		"role":    role,
		"delta":   delta,
	})
