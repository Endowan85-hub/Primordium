class_name IsometricMap
extends Node2D

# =============================================================
# ISOMETRIC MAP
# Renders the 200x200 tile grid in isometric view.
# 64x32 pixel tiles in classic 2:1 ratio.
#
# Coordinate system:
#   World (tile) coords: integer x, y on the grid
#   Screen coords: pixel position on screen
#
# Isometric conversion:
#   screen_x = (tile_x - tile_y) * HALF_TILE_W
#   screen_y = (tile_x + tile_y) * HALF_TILE_H
# =============================================================


signal tile_clicked(x: int, y: int)
signal tile_right_clicked(x: int, y: int)
signal unit_clicked(unit_id: int)
signal unit_right_clicked(unit_id: int)
signal city_right_clicked(city_id: int)


const TILE_W: int = 64
const TILE_H: int = 32
const HALF_W: int = TILE_W / 2
const HALF_H: int = TILE_H / 2

# Elevation: how many units tall each tile type is.
# Each elevation level = WALL_STEP pixels of vertical lift.
# With smoothed terrain (max 1 level diff between neighbors) 5px gives
# gentle rolling hills rather than floating platform blocks.
const WALL_STEP: float = 5.0  # pixels per elevation level
const TILE_ELEVATION: Dictionary = {
	# 0 = sea level, no wall
	# TileTypes.Type values as ints
	0: 1,   # GRASSLAND
	1: 2,   # FOREST  (slightly raised, trees feel taller)
	2: 3,   # HILLS
	3: 5,   # MOUNTAIN
	4: 0,   # RIVER   (carved low)
	5: 0,   # COASTAL (at sea)
	6: 0,   # OCEAN
	7: 1,   # DESERT
	8: 1,   # TUNDRA
	9: 2,   # SNOW    (elevated cold plateau)
}

# Wall face colors per tile type (side of the cliff)
# Slightly darker/warmer than the top face
const WALL_COLORS: Dictionary = {
	0: Color(0.25, 0.45, 0.15),  # GRASSLAND
	1: Color(0.06, 0.28, 0.06),  # FOREST
	2: Color(0.45, 0.38, 0.20),  # HILLS
	3: Color(0.38, 0.38, 0.42),  # MOUNTAIN
	4: Color(0.12, 0.32, 0.60),  # RIVER
	5: Color(0.20, 0.45, 0.55),  # COASTAL
	6: Color(0.07, 0.20, 0.50),  # OCEAN
	7: Color(0.65, 0.55, 0.25),  # DESERT
	8: Color(0.48, 0.50, 0.42),  # TUNDRA
	9: Color(0.60, 0.65, 0.70),  # SNOW
}

# How many tiles to render around the camera center
const RENDER_RADIUS: int = 20

# Tile colors by type and depletion state
# Used as placeholder until pixel art sprites are added
const TILE_COLORS: Dictionary = {
	TileTypes.Type.GRASSLAND: [Color(0.35, 0.65, 0.25), Color(0.45, 0.55, 0.30), Color(0.50, 0.50, 0.30), Color(0.55, 0.50, 0.35)],
	TileTypes.Type.FOREST:    [Color(0.10, 0.45, 0.10), Color(0.15, 0.40, 0.12), Color(0.20, 0.38, 0.15), Color(0.30, 0.35, 0.20)],
	TileTypes.Type.HILLS:     [Color(0.60, 0.55, 0.35), Color(0.62, 0.52, 0.33), Color(0.65, 0.50, 0.30), Color(0.68, 0.48, 0.28)],
	TileTypes.Type.MOUNTAIN:  [Color(0.55, 0.55, 0.60), Color(0.58, 0.55, 0.58), Color(0.60, 0.55, 0.55), Color(0.65, 0.60, 0.58)],
	TileTypes.Type.RIVER:     [Color(0.20, 0.50, 0.85), Color(0.22, 0.48, 0.80), Color(0.25, 0.45, 0.75), Color(0.30, 0.42, 0.70)],
	TileTypes.Type.COASTAL:   [Color(0.30, 0.65, 0.80), Color(0.32, 0.62, 0.75), Color(0.35, 0.60, 0.70), Color(0.38, 0.58, 0.65)],
	TileTypes.Type.OCEAN:     [Color(0.10, 0.30, 0.70), Color(0.10, 0.30, 0.70), Color(0.10, 0.30, 0.70), Color(0.10, 0.30, 0.70)],
	TileTypes.Type.DESERT:    [Color(0.85, 0.78, 0.45), Color(0.87, 0.75, 0.42), Color(0.88, 0.72, 0.40), Color(0.90, 0.70, 0.38)],
	TileTypes.Type.TUNDRA:    [Color(0.65, 0.70, 0.60), Color(0.67, 0.68, 0.58), Color(0.70, 0.68, 0.58), Color(0.72, 0.68, 0.58)],
	TileTypes.Type.SNOW:      [Color(0.90, 0.93, 0.97), Color(0.88, 0.90, 0.95), Color(0.87, 0.88, 0.93), Color(0.85, 0.87, 0.90)],
}

# Unit colors by type
const UNIT_COLORS: Dictionary = {
	"settler":  Color(0.9, 0.9, 0.2),
	"worker":   Color(0.6, 0.8, 0.3),
	"scout":    Color(0.3, 0.9, 0.7),
	"soldier":  Color(0.9, 0.3, 0.3),
	"cavalry":  Color(0.9, 0.6, 0.2),
}

# Fog of war overlay
const FOG_COLOR: Color      = Color(0.0, 0.0, 0.0, 0.6)
const UNKNOWN_COLOR: Color  = Color(0.05, 0.05, 0.08, 1.0)

# Selection highlight
const SELECT_COLOR: Color   = Color(1.0, 1.0, 0.3, 0.5)
const HOVER_COLOR: Color    = Color(1.0, 1.0, 1.0, 0.2)


# -------------------------------------------------------------
# STATE
# -------------------------------------------------------------
var _tiles: Dictionary      = {}   # "x,y" -> tile data
var _units: Dictionary      = {}   # unit_id -> unit data
var _cities: Dictionary     = {}   # city_id -> city data

var _camera_pos: Vector2    = Vector2.ZERO
var _zoom: float            = 1.0
var _zoom_min: float        = 0.3
var _zoom_max: float        = 3.0

var _hovered_tile: Vector2i    = Vector2i(-1, -1)
var _selected_tile: Vector2i   = Vector2i(-1, -1)
var _hovered_unit_id: int      = -1   # Unit under mouse cursor
var _selected_unit_id: int     = -1   # Currently selected unit
var _block_next_left_click: bool = false  # True after right-click to block menu click-through

var _current_season: String = "spring"
var _drag_start: Vector2    = Vector2.ZERO
var _dragging: bool         = false

# Player colors cache: player_id -> Color
var _player_colors: Dictionary = {}

# Sprite cache: unit_type -> Texture2D (null if not found)
var _unit_sprites: Dictionary = {}

# Tile sprite paths — base tile, then depletion states
# Code falls back to colored polygon if file doesn't exist
# Tile variant system:
# - Folder names are fixed (grassland, forest, …)
# - Sprites inside MUST be named:  TypeName.png  (base, always used as variant 0)
#                                  TypeName2.png, TypeName3.png … TypeName10.png
# - Code auto-discovers however many exist — just drop files in, press F5.
# - No sprite → falls back to colored polygon.
const TILE_FOLDERS: Dictionary = {
	TileTypes.Type.GRASSLAND: ["res://assets/tiles/grassland/", "Grassland"],
	TileTypes.Type.FOREST:    ["res://assets/tiles/forest/",    "Forest"],
	TileTypes.Type.HILLS:     ["res://assets/tiles/hills/",     "Hills"],
	TileTypes.Type.MOUNTAIN:  ["res://assets/tiles/mountain/",  "Mountain"],
	TileTypes.Type.RIVER:     ["res://assets/tiles/river/",     "River"],
	TileTypes.Type.COASTAL:   ["res://assets/tiles/coastal/",   "Coastal"],
	TileTypes.Type.OCEAN:     ["res://assets/tiles/ocean/",     "Ocean"],
	TileTypes.Type.DESERT:    ["res://assets/tiles/desert/",    "Desert"],
	TileTypes.Type.TUNDRA:    ["res://assets/tiles/tundra/",    "Tundra"],
	TileTypes.Type.SNOW:      ["res://assets/tiles/snow/",      "Snow"],
}
const MAX_VARIANTS: int = 20   # Max variants checked per tile type

# tile_type -> Array[Texture2D]  (empty array = no sprites, use polygon)
var _tile_variants: Dictionary = {}

# "x,y" -> variant_index  (assigned once when tile data arrives)
var _tile_variant_map: Dictionary = {}

var _city_sprite: Texture2D = null  # Village center sprite
var _grass_layer:   GrassLayer   = null  # Animated grass overlay

# Animated tile system — drop TypeName_anim.png (sprite sheet) +
# TypeName_anim.json (Aseprite array export) into the tile folder.
# Loaded automatically, plays in _draw_tile_top via frame slicing.
# Structure: tile_type -> { "texture": Texture2D, "frames": int,
#                           "frame_w": int, "fps": float }
var _tile_anims: Dictionary = {}
var _anim_time:  float      = 0.0   # global clock for frame stepping

# Last known visual world position per unit (for smooth redirect)
var _unit_visual_pos: Dictionary = {}
const UNIT_SPRITE_PATHS: Dictionary = {
	"settler": "res://assets/units/settler/Settler.png",
	"worker":  "res://assets/units/worker/Worker.png",
	"scout":   "res://assets/units/scout/Scout.png",
	"soldier": "res://assets/units/soldier/Soldier.png",
}


# -------------------------------------------------------------
# READY
# -------------------------------------------------------------
func _ready() -> void:
	# Preload unit sprites
	for unit_type in UNIT_SPRITE_PATHS:
		var path = UNIT_SPRITE_PATHS[unit_type]
		if ResourceLoader.exists(path):
			_unit_sprites[unit_type] = load(path)
		else:
			_unit_sprites[unit_type] = null

	# Auto-discover tile sprite variants.
	# Looks for TypeName.png, TypeName2.png, TypeName3.png … up to MAX_VARIANTS.
	# Only loads variants that actually exist — drop a file in, press F5, it works.
	for tile_type in TILE_FOLDERS:
		var info    = TILE_FOLDERS[tile_type]  # [folder_path, base_name]
		var folder  = info[0]
		var base    = info[1]
		var loaded: Array[Texture2D] = []
		# Base sprite (no number suffix)
		var base_path = folder + base + ".png"
		if ResourceLoader.exists(base_path):
			loaded.append(load(base_path))
		# Numbered variants 2..MAX_VARIANTS
		for n in range(2, MAX_VARIANTS + 1):
			var vpath = folder + base + str(n) + ".png"
			if ResourceLoader.exists(vpath):
				loaded.append(load(vpath))
			else:
				break   # Stop at first gap — keeps it fast
		_tile_variants[tile_type] = loaded
		if loaded.size() > 0:
			print("Tile variants loaded — ", base, ": ", loaded.size(), " sprite(s)")

	# Auto-discover animated tile sheets.
	# Looks for TypeName_anim.png + TypeName_anim.json in each tile folder.
	# JSON must be exported from Aseprite as "Array" format.
	# Falls back to static sprite if no _anim files found.
	for tile_type in TILE_FOLDERS:
		var info       = TILE_FOLDERS[tile_type]
		var folder     = info[0]
		var base       = info[1]
		var sheet_path = folder + base + "_anim.png"
		var json_path  = folder + base + "_anim.json"
		if ResourceLoader.exists(sheet_path) and ResourceLoader.exists(json_path):
			var tex        = load(sheet_path) as Texture2D
			var json_file  = FileAccess.open(json_path, FileAccess.READ)
			if tex and json_file:
				var json_text  = json_file.get_as_text()
				json_file.close()
				var parsed     = JSON.parse_string(json_text)
				if parsed is Array and parsed.size() > 0:
					var frame_count = parsed.size()
					var frame_w     = int(parsed[0].get("sourceSize", {}).get("w", 64))
					# Average duration across frames (ms → fps)
					var total_ms: float = 0.0
					for fd in parsed:
						total_ms += float(fd.get("duration", 100))
					var fps = float(frame_count) / (total_ms / 1000.0)
					_tile_anims[tile_type] = {
						"texture": tex,
						"frames":  frame_count,
						"frame_w": frame_w,
						"fps":     fps,
					}
					print("Tile anim loaded — ", base, ": ", frame_count, " frames @ ", snappedf(fps, 0.1), " fps")

	# Preload village center sprite
	var city_path = "res://assets/cities/VillageCenter.png"
	if ResourceLoader.exists(city_path):
		_city_sprite = load(city_path)

	# Grass layer — NOT added as a child node (would draw on top of units).
	# Instead we call _grass_layer.draw_into(self) from within _draw(),
	# so grass renders between tile tops and units in the correct order.
	_grass_layer = GrassLayer.new()
	_grass_layer._map = self

	# Center camera on map center
	var map_center = tile_to_screen(
		GameConstants.MAP_WIDTH / 2,
		GameConstants.MAP_HEIGHT / 2
	)
	_camera_pos = map_center
	queue_redraw()


# -------------------------------------------------------------
# INPUT
# -------------------------------------------------------------
# Grass animation runs on its own timer at 24fps max.
# This decouples animation redraws from mouse input redraws so
# hover highlight updates feel instant instead of frame-delayed.
var _anim_timer: float = 0.0
const ANIM_FPS: float  = 24.0

func _process(delta: float) -> void:
	if _grass_layer and not _blade_cache_empty():
		_anim_timer += delta
		if _anim_timer >= 1.0 / ANIM_FPS:
			_anim_timer = 0.0
			queue_redraw()


func _blade_cache_empty() -> bool:
	return _grass_layer == null or _grass_layer._blade_cache.is_empty()


func _input(event: InputEvent) -> void:
	# Mouse movement - update hover
	if event is InputEventMouseMotion:
		var tile         = _screen_to_world_tile(event.position)
		var hovered_unit = _unit_at_screen(event.position)
		_hovered_tile    = tile
		_hovered_unit_id = hovered_unit
		queue_redraw()

		# Drag to pan — needs full redraw to move tiles
		if _dragging:
			_camera_pos -= event.relative / _zoom
			queue_redraw()

	# Mouse button
	elif event is InputEventMouseButton:
		match event.button_index:
			MOUSE_BUTTON_LEFT:
				if event.pressed:
					_drag_start  = event.position
					_dragging    = false
				else:
					if _block_next_left_click:
						_block_next_left_click = false
					elif not _dragging:
						_handle_click(event.position)
					_dragging = false

			MOUSE_BUTTON_MIDDLE:
				_dragging = event.pressed

			MOUSE_BUTTON_RIGHT:
				if event.pressed:
					_handle_right_click(event.position)
				else:
					_dragging = false

			MOUSE_BUTTON_WHEEL_UP:
				_zoom_toward(event.position, 1.1)

			MOUSE_BUTTON_WHEEL_DOWN:
				_zoom_toward(event.position, 0.9)

	# Keyboard camera pan
	elif event is InputEventKey and event.pressed:
		# Don't pan while a text field is focused (e.g. city name input)
		var focused = get_viewport().gui_get_focus_owner()
		if focused is LineEdit or focused is TextEdit:
			return
		var pan_speed = 10.0 / _zoom
		match event.keycode:
			KEY_W, KEY_UP:    _camera_pos.y -= pan_speed; queue_redraw()
			KEY_S, KEY_DOWN:  _camera_pos.y += pan_speed; queue_redraw()
			KEY_A, KEY_LEFT:  _camera_pos.x -= pan_speed; queue_redraw()
			KEY_D, KEY_RIGHT: _camera_pos.x += pan_speed; queue_redraw()

	# Detect drag vs click
	if event is InputEventMouseMotion and Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT):
		if event.position.distance_to(_drag_start) > 5:
			_dragging = true


# Returns unit_id of any unit whose origin, travel target,
# or current visual tile matches the clicked tile. -1 if none.
func _unit_at_tile(tile: Vector2i) -> int:
	for unit_id in _units:
		var unit  = _units[unit_id]

		# Check logical position
		var utile = Vector2i(unit.get("x", -1), unit.get("y", -1))
		if utile == tile:
			return unit_id

		# Check travel target tile
		var tt = unit.get("travel_target", null)
		if tt != null:
			var ttile = Vector2i(int(tt.get("x", -1)), int(tt.get("y", -1)))
			if ttile == tile:
				return unit_id

		# Check current visual tile (for mid-move clicking)
		if _unit_visual_pos.has(unit_id):
			var vis_world = _unit_visual_pos[unit_id]
			var vis_tile  = screen_to_tile(vis_world)
			if vis_tile == tile:
				return unit_id

	return -1


func _screen_to_world_tile(screen_pos: Vector2) -> Vector2i:
	# Test candidate tiles near the click and pick whichever elevated diamond
	# actually contains the screen point. This handles clicking tall tiles correctly.
	var half_vp   = get_viewport_rect().size / 2.0
	var world_pos = screen_pos / _zoom + _camera_pos - half_vp
	var base_tile = screen_to_tile(world_pos)

	# Check a 3-tile radius around the base guess (elevation shifts tiles upward)
	var best_tile = base_tile
	for dy in range(-4, 3):
		for dx in range(-3, 4):
			var cx = base_tile.x + dx
			var cy = base_tile.y + dy
			if cx < 0 or cy < 0: continue
			var key = str(cx) + "," + str(cy)
			var tile = _tiles.get(key, {})
			if tile.is_empty(): continue
			var lift = _get_tile_lift(tile) * _zoom
			var spos      = tile_to_screen(cx, cy) - _camera_pos + half_vp
			spos         *= _zoom
			spos.y       -= lift
			var pts       = _get_tile_diamond(spos)
			# Point-in-diamond test using cross products
			if _point_in_diamond(screen_pos, pts):
				best_tile = Vector2i(cx, cy)
	return best_tile


func _point_in_diamond(p: Vector2, pts: PackedVector2Array) -> bool:
	# pts = [top, right, bottom, left] — convex quad, test with cross products
	for i in range(4):
		var a = pts[i]
		var b = pts[(i + 1) % 4]
		var cross = (b.x - a.x) * (p.y - a.y) - (b.y - a.y) * (p.x - a.x)
		if cross < 0:
			return false
	return true


# Returns unit_id if screen_pos is over any unit sprite, -1 otherwise.
# Uses sprite bounding box so the entire sprite is clickable.
func _unit_at_screen(screen_pos: Vector2) -> int:
	var half_vp = get_viewport_rect().size / 2.0
	for unit_id in _units:
		var unit      = _units[unit_id]
		var draw_pos  = _get_unit_draw_pos(unit_id, unit, half_vp)
		var sprite    = _unit_sprites.get(unit.get("type", ""), null)
		var sw        = (sprite.get_width()  if sprite else 16.0) * _zoom
		var sh        = (sprite.get_height() if sprite else 16.0) * _zoom
		# Sprite rect: centered horizontally, bottom at draw_pos
		var rect = Rect2(
			draw_pos.x - sw / 2.0,
			draw_pos.y - sh,
			sw, sh
		)
		if rect.has_point(screen_pos):
			return unit_id
	return -1


# Returns the screen-space draw position for a unit (reused in draw and hit-test)
# Accounts for tile elevation so unit stands on top of the elevated surface.
func _get_unit_draw_pos(unit_id: int, unit: Dictionary, half_vp: Vector2) -> Vector2:
	var ux     = unit.get("x", 0)
	var uy     = unit.get("y", 0)
	var status = unit.get("status", "idle")
	var world_pos: Vector2

	if status == "moving" and unit.get("travel_target") != null:
		var target   = unit["travel_target"]
		var progress = unit.get("travel_progress", 0.0)
		var total    = unit.get("travel_total", 1.0)
		var t        = clamp(progress / max(total, 0.001), 0.0, 1.0)
		var fx       = unit.get("travel_from_x", float(ux))
		var fy       = unit.get("travel_from_y", float(uy))
		world_pos    = tile_to_screen_f(fx, fy).lerp(
			tile_to_screen(int(target["x"]), int(target["y"])), t)
		# Interpolate elevation between from and to tiles
		var from_key  = str(int(fx)) + "," + str(int(fy))
		var to_key    = str(int(target["x"])) + "," + str(int(target["y"]))
		var from_lift = _get_tile_lift(_tiles.get(from_key, {}))
		var to_lift   = _get_tile_lift(_tiles.get(to_key, {}))
		var lift      = lerp(from_lift, to_lift, t) * _zoom
		_unit_visual_pos[unit_id] = world_pos
		var screen = (world_pos - _camera_pos + half_vp) * _zoom
		screen.y  -= lift
		return screen
	else:
		world_pos = tile_to_screen(ux, uy)
		_unit_visual_pos[unit_id] = world_pos
		var tile_key = str(ux) + "," + str(uy)
		var lift = _get_tile_lift(_tiles.get(tile_key, {})) * _zoom
		var screen = (world_pos - _camera_pos + half_vp) * _zoom
		screen.y  -= lift
		return screen


func _handle_click(screen_pos: Vector2) -> void:
	# Check screen-space unit hit first (whole sprite is clickable)
	var unit_id = _unit_at_screen(screen_pos)
	if unit_id >= 0:
		var unit = _units[unit_id]
		_selected_tile = Vector2i(unit.get("x", 0), unit.get("y", 0))
		queue_redraw()
		emit_signal("unit_clicked", unit_id)
		return

	# Otherwise tile click
	var tile = _screen_to_world_tile(screen_pos)
	_selected_tile = tile
	queue_redraw()
	emit_signal("tile_clicked", tile.x, tile.y)


func _handle_right_click(screen_pos: Vector2) -> void:
	# Check city click first (city occupies its tile center)
	var tile = _screen_to_world_tile(screen_pos)
	for city_id in _cities:
		var city = _cities[city_id]
		if city.get("x", -1) == tile.x and city.get("y", -1) == tile.y:
			emit_signal("city_right_clicked", city_id)
			return

	# Check screen-space unit hit
	var unit_id = _unit_at_screen(screen_pos)
	if unit_id >= 0:
		var unit = _units[unit_id]
		_selected_tile = Vector2i(unit.get("x", 0), unit.get("y", 0))
		queue_redraw()
		emit_signal("unit_right_clicked", unit_id)
		return

	# Otherwise tile right-click — tile already computed above
	if tile.x < 0:
		return
	emit_signal("tile_right_clicked", tile.x, tile.y)


# -------------------------------------------------------------
# DRAW
# -------------------------------------------------------------
func _draw() -> void:
	var viewport_size = get_viewport_rect().size
	var half_vp       = viewport_size / 2.0

	# Calculate which tiles are visible
	var cam_tile = screen_to_tile(_camera_pos)
	var min_x    = max(0, cam_tile.x - RENDER_RADIUS)
	var max_x    = min(GameConstants.MAP_WIDTH  - 1, cam_tile.x + RENDER_RADIUS)
	var min_y    = max(0, cam_tile.y - RENDER_RADIUS)
	var max_y    = min(GameConstants.MAP_HEIGHT - 1, cam_tile.y + RENDER_RADIUS)

	# Draw tiles in isometric order (back to front)
	# Two-pass per row: walls first, then top faces — prevents tall back tiles
	# from having their walls overdraw the top surface of tiles in front.
	for ty in range(min_y, max_y + 1):
		for tx in range(min_x, max_x + 1):
			_draw_tile_walls(tx, ty, half_vp)
	for ty in range(min_y, max_y + 1):
		for tx in range(min_x, max_x + 1):
			_draw_tile_top(tx, ty, half_vp)

	# Draw grass AFTER tile tops, BEFORE units — correct depth order
	if _grass_layer:
		_grass_layer.draw_into(self, half_vp)

	# Draw units on top of grass
	for unit_id in _units:
		_draw_unit(unit_id, half_vp)

	# Draw cities on top of tiles
	for city_id in _cities:
		_draw_city(city_id, half_vp)


# Shared setup for a tile — returns [screen_pos, points, tile, tile_type, base_color, lift]
# Returns empty array if tile should be skipped (off screen)
func _tile_draw_setup(tx: int, ty: int, half_vp: Vector2) -> Array:
	var key       = str(tx) + "," + str(ty)
	var tile      = _tiles.get(key, {})
	var tile_type = int(tile.get("type", TileTypes.Type.GRASSLAND)) if not tile.is_empty() else 0
	var lift      = (_get_tile_lift(tile) if not tile.is_empty() else _get_elevation_lift(tile_type)) * _zoom
	var screen_pos = tile_to_screen(tx, ty) - _camera_pos + half_vp
	screen_pos    *= _zoom
	screen_pos.y  -= lift

	if screen_pos.x < -(TILE_W * _zoom + 4.0) or screen_pos.x > get_viewport_rect().size.x + TILE_W * _zoom:
		return []
	if screen_pos.y < -(TILE_H * _zoom + lift + 4.0) or screen_pos.y > get_viewport_rect().size.y + lift + 4.0:
		return []

	var points     = _get_tile_diamond(screen_pos)
	var depletion  = int(tile.get("depletion_state", TileTypes.DepletionState.FULL))
	var color_arr  = TILE_COLORS.get(tile_type, [Color.GRAY, Color.GRAY, Color.GRAY, Color.GRAY])
	var base_color = color_arr[min(depletion, color_arr.size() - 1)]
	var owner      = tile.get("owner", -1)
	if owner >= 0:
		base_color = base_color.lerp(_get_player_color(owner), 0.15)
	return [screen_pos, points, tile, tile_type, base_color, lift, owner]


# Pass 1: draw only the cliff walls (behind everything else)
func _draw_tile_walls(tx: int, ty: int, half_vp: Vector2) -> void:
	var d = _tile_draw_setup(tx, ty, half_vp)
	if d.is_empty() or (d[2] as Dictionary).is_empty():
		return
	var screen_pos: Vector2 = d[0]
	var points: PackedVector2Array = d[1]
	var tile_type: int = d[3]
	var base_color: Color = d[4]
	var lift: float = d[5]

	if lift > 0.5:
		var wall_faces = _get_wall_points(points, lift)
		var wall_base  = WALL_COLORS.get(tile_type, base_color.darkened(0.35))
		draw_colored_polygon(wall_faces[0], wall_base.lightened(0.08))
		draw_colored_polygon(wall_faces[1], wall_base.darkened(0.15))
		var edge_color = wall_base.darkened(0.4)
		edge_color.a   = 0.7
		draw_polyline(wall_faces[0], edge_color, 0.5 * _zoom)
		draw_polyline(wall_faces[1], edge_color, 0.5 * _zoom)


# Pass 2: draw the top face, highlights, improvements, bars
func _draw_tile_top(tx: int, ty: int, half_vp: Vector2) -> void:
	var d = _tile_draw_setup(tx, ty, half_vp)
	if d.is_empty():
		return
	var screen_pos: Vector2 = d[0]
	var points: PackedVector2Array = d[1]
	var tile: Dictionary = d[2]
	var tile_type: int = d[3]
	var base_color: Color = d[4]
	var owner: int = d[6]

	if tile.is_empty():
		draw_colored_polygon(points, UNKNOWN_COLOR)
		return

	# Top face — pick variant sprite if available, polygon fallback if not
	var variants   = _tile_variants.get(tile_type, [])
	var tile_key   = str(tx) + "," + str(ty)
	var var_idx    = _tile_variant_map.get(tile_key, 0)
	var tile_sprite: Texture2D = null
	if variants.size() > 0:
		tile_sprite = variants[clamp(var_idx, 0, variants.size() - 1)]
	if tile_sprite:
		var tw   = float(TILE_W) * _zoom
		var th   = float(TILE_H) * _zoom
		var rect = Rect2(screen_pos - Vector2(tw / 2.0, th / 2.0), Vector2(tw, th))
		var mod  = Color.WHITE if owner < 0 else Color.WHITE.lerp(_get_player_color(owner), 0.15)
		draw_texture_rect(tile_sprite, rect, false, mod)
	else:
		draw_colored_polygon(points, base_color)

	# Grid line
	var border_color = base_color.darkened(0.3)
	border_color.a   = 0.4
	draw_polyline(points + PackedVector2Array([points[0]]), border_color, 0.5 * _zoom)

	# Hover/selection highlights
	if Vector2i(tx, ty) == _hovered_tile:
		draw_polyline(points + PackedVector2Array([points[0]]), HOVER_COLOR, 1.0 * _zoom)
	if Vector2i(tx, ty) == _selected_tile and _selected_unit_id < 0:
		draw_polyline(points + PackedVector2Array([points[0]]), SELECT_COLOR, 2.0 * _zoom)

	# Improvement indicator
	var improvement = int(tile.get("improvement", TileTypes.Improvement.NONE))
	if improvement != TileTypes.Improvement.NONE:
		_draw_improvement_indicator(screen_pos, improvement)

	# Resource bar
	if tile_type != TileTypes.Type.OCEAN:
		_draw_resource_bar(screen_pos, tile)


func _draw_improvement_indicator(screen_pos: Vector2, improvement: int) -> void:
	# Small colored dot in center of tile indicating improvement type
	var imp_colors: Dictionary = {
		TileTypes.Improvement.FARM:        Color(0.9, 0.8, 0.2),
		TileTypes.Improvement.LUMBER_CAMP: Color(0.6, 0.4, 0.1),
		TileTypes.Improvement.MINE:        Color(0.7, 0.7, 0.7),
		TileTypes.Improvement.FISHING_HUT: Color(0.2, 0.5, 0.9),
		TileTypes.Improvement.IRRIGATION:  Color(0.3, 0.7, 0.9),
		TileTypes.Improvement.ROAD:        Color(0.6, 0.5, 0.4),
		TileTypes.Improvement.FORT:        Color(0.8, 0.2, 0.2),
		TileTypes.Improvement.WATCHTOWER:  Color(0.9, 0.7, 0.1),
		TileTypes.Improvement.REPLANTED:   Color(0.2, 0.8, 0.3),
	}
	var color = imp_colors.get(improvement, Color.WHITE)
	draw_circle(screen_pos, 3.0 * _zoom, color)


func _draw_resource_bar(screen_pos: Vector2, tile: Dictionary) -> void:
	var tile_type = tile.get("type", TileTypes.Type.GRASSLAND)
	var data      = TileTypes.TILE_RESOURCES.get(tile_type, {})
	var primary   = data.get("primary", "")
	if primary == "":
		return

	var current = tile.get("resources", {}).get(primary, 0.0)
	var max_val  = tile.get("resources", {}).get(primary + "_max", 1.0)
	if max_val <= 0:
		return

	var pct      = clamp(current / max_val, 0.0, 1.0)
	var bar_w    = float(TILE_W) * 0.5 * _zoom
	var bar_h    = 2.0 * _zoom
	var bar_x    = screen_pos.x - bar_w / 2.0
	var bar_y    = screen_pos.y + float(HALF_H) * _zoom * 0.6

	# Background
	draw_rect(Rect2(bar_x, bar_y, bar_w, bar_h), Color(0.2, 0.2, 0.2, 0.7))

	# Fill - color based on percentage
	var fill_color = Color(0.2, 0.8, 0.2)
	if pct < 0.25:
		fill_color = Color(0.9, 0.2, 0.2)
	elif pct < 0.5:
		fill_color = Color(0.9, 0.7, 0.1)
	draw_rect(Rect2(bar_x, bar_y, bar_w * pct, bar_h), fill_color)


func _draw_unit(unit_id: int, half_vp: Vector2) -> void:
	var unit       = _units[unit_id]
	var screen_pos = _get_unit_draw_pos(unit_id, unit, half_vp)

	# Skip if off screen
	if screen_pos.x < -32 or screen_pos.x > get_viewport_rect().size.x + 32:
		return
	if screen_pos.y < -32 or screen_pos.y > get_viewport_rect().size.y + 32:
		return

	var unit_type  = unit.get("type", "settler")
	var status     = unit.get("status", "idle")
	var owner      = unit.get("owner", 0)
	var unit_color = _get_player_color(owner)
	var sprite     = _unit_sprites.get(unit_type, null)

	if sprite:
		var sw       = sprite.get_width()
		var sh       = sprite.get_height()
		var dst_w    = sw * _zoom
		var dst_h    = sh * _zoom
		var offset   = Vector2(-dst_w / 2.0, -dst_h)
		var dst_rect = Rect2(screen_pos + offset, Vector2(dst_w, dst_h))

		draw_texture_rect(sprite, dst_rect, false)
		# Hover outline
		if unit_id == _hovered_unit_id:
			draw_rect(dst_rect.grow(2.0 * _zoom), Color(1, 1, 1, 0.7), false, 1.5 * _zoom)
		# Selection outline
		if unit_id == _selected_unit_id:
			draw_rect(dst_rect.grow(2.0 * _zoom), Color(1.0, 1.0, 0.3, 0.9), false, 2.0 * _zoom)
	else:
		# Fallback: placeholder circle
		var radius = 8.0 * _zoom
		draw_circle(screen_pos, radius, unit_color)
		draw_arc(screen_pos, radius, 0, TAU, 12, Color.BLACK, 1.0 * _zoom)
		var type_color = UNIT_COLORS.get(unit_type, Color.WHITE)
		draw_circle(screen_pos, radius * 0.5, type_color)

		# Selection ring
		if unit_id == _selected_unit_id:
			draw_arc(screen_pos, 11.0 * _zoom, 0, TAU, 16,
				Color(1.0, 1.0, 0.3), 2.0 * _zoom)

	# Travel progress arc
	if status == "moving":
		var progress   = unit.get("travel_progress", 0.0)
		var total      = unit.get("travel_total", 1.0)
		var t          = clamp(progress / max(total, 0.001), 0.0, 1.0)
		var arc_radius = 10.0 * _zoom
		draw_arc(screen_pos, arc_radius, -PI / 2.0,
			-PI / 2.0 + TAU * t, 16, Color(0.3, 1.0, 0.8), 2.0 * _zoom)


func _draw_city(city_id: int, half_vp: Vector2) -> void:
	var city       = _cities[city_id]
	var cx         = city.get("x", 0)
	var cy         = city.get("y", 0)
	var owner      = city.get("owner", 0)
	var base_screen = (tile_to_screen(cx, cy) - _camera_pos + half_vp) * _zoom
	var city_key  = str(cx) + "," + str(cy)
	var city_lift = _get_tile_lift(_tiles.get(city_key, {})) * _zoom
	var screen_pos     = base_screen
	screen_pos.y      -= city_lift

	# Skip if off screen
	if screen_pos.x < -128 or screen_pos.x > get_viewport_rect().size.x + 128:
		return

	var city_color  = _get_player_color(owner)
	var radius      = city.get("territory_radius", 3)

	# Draw territory ring — outline each claimed border tile
	var ring_color = Color(city_color.r, city_color.g, city_color.b, 0.35)
	for tile_key in _tiles:
		var parts = tile_key.split(",")
		if parts.size() < 2:
			continue
		var tx = int(parts[0])
		var ty = int(parts[1])
		var tile_data = _tiles[tile_key]
		if tile_data.get("owner", -1) == owner and 				tile_data.get("city_id", -1) == city_id:
			var tpos = (tile_to_screen(tx, ty) - _camera_pos + half_vp) * _zoom
			var tpts = _get_tile_diamond(tpos)
			draw_polyline(tpts + PackedVector2Array([tpts[0]]),
				ring_color, 1.5 * _zoom)

	# Draw village center sprite or fallback colored diamond
	if _city_sprite:
		var sw     = _city_sprite.get_width()
		var sh     = _city_sprite.get_height()
		var dst_w  = sw * _zoom
		var dst_h  = sh * _zoom
		# Center horizontally, bottom of sprite sits on tile center
		var rect   = Rect2(screen_pos + Vector2(-dst_w / 2.0, -dst_h), Vector2(dst_w, dst_h))
		draw_texture_rect(_city_sprite, rect, false)
	else:
		# Fallback: colored building shape
		var bw   = 20.0 * _zoom
		var bh   = 28.0 * _zoom
		var rect = Rect2(screen_pos + Vector2(-bw / 2.0, -bh), Vector2(bw, bh))
		draw_rect(rect, city_color)
		draw_rect(rect, Color.BLACK, false, 1.5 * _zoom)
		# Roof triangle
		var roof = PackedVector2Array([
			screen_pos + Vector2(-bw * 0.7, -bh),
			screen_pos + Vector2(0.0, -bh - bw * 0.6),
			screen_pos + Vector2(bw * 0.7, -bh),
		])
		draw_colored_polygon(roof, city_color.lightened(0.2))
		draw_polyline(roof + PackedVector2Array([roof[0]]), Color.BLACK, 1.5 * _zoom)

	# City name
	var font      = ThemeDB.fallback_font
	var font_size = int(clamp(11.0 * _zoom, 8, 18))
	var name_str  = city.get("name", "City")
	var pop_str   = "Pop: " + str(city.get("population", 0))
	var tw        = font.get_string_size(name_str, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size).x
	draw_string(font, screen_pos + Vector2(-tw / 2.0, -30.0 * _zoom - font_size),
		name_str, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size, Color.WHITE)
	if _zoom >= 0.7:
		var pw = font.get_string_size(pop_str, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size - 2).x
		draw_string(font, screen_pos + Vector2(-pw / 2.0, -30.0 * _zoom + 2),
			pop_str, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size - 2, Color(0.8, 0.9, 0.8))


# -------------------------------------------------------------
# COORDINATE CONVERSION
# -------------------------------------------------------------
func tile_to_screen(tx: int, ty: int) -> Vector2:
	return Vector2(
		float(tx - ty) * float(HALF_W),
		float(tx + ty) * float(HALF_H)
	)


# Returns how many pixels upward to shift a tile based on its elevation
# Primary: reads per-tile elevation from tile dict (smoothed, per-tile value)
# Falls back to type-based table if tile has no "elevation" key (old data)
func _get_elevation_lift(tile_type: int) -> float:
	var elev = TILE_ELEVATION.get(tile_type, 1)
	return float(elev) * WALL_STEP


func _get_tile_lift(tile: Dictionary) -> float:
	if tile.has("elevation"):
		return float(int(tile["elevation"])) * WALL_STEP
	# Fallback for tiles without per-tile elevation
	var tile_type = int(tile.get("type", 0))
	return _get_elevation_lift(tile_type)


# Builds the 4 wall points below a tile's diamond (left and right faces of the cliff)
# top_points = the 4 diamond points of the top face (already elevated)
# wall_h     = height of the wall in pixels (elevation * WALL_STEP)
func _get_wall_points(top_points: PackedVector2Array, wall_h: float) -> Array:
	# Isometric diamond: [top, right, bottom, left]
	# Left wall face:  top-left → bottom-left → bottom-left shifted down → top-left shifted down
	# Right wall face: bottom-right → ... same idea
	# We draw two quads: left face and right face of the cliff
	var top    = top_points[0]
	var right  = top_points[1]
	var bottom = top_points[2]
	var left   = top_points[3]
	var d      = Vector2(0, wall_h)
	# Left face (viewer sees this on the left side going down)
	var left_face = PackedVector2Array([left, bottom, bottom + d, left + d])
	# Right face (viewer sees this on the right side going down)
	var right_face = PackedVector2Array([bottom, right, right + d, bottom + d])
	return [left_face, right_face]


# Float version for fractional tile coordinates (mid-move redirect origin)
func tile_to_screen_f(tx: float, ty: float) -> Vector2:
	return Vector2(
		(tx - ty) * float(HALF_W),
		(tx + ty) * float(HALF_H)
	)


# Zoom keeping the world point under the cursor stationary.
# Draw formula: screen = (tile_world - _camera_pos + half_vp) * _zoom
# So: tile_world = screen / _zoom + _camera_pos - half_vp
# We want tile_world_at_cursor to be identical before and after zoom.
func _zoom_toward(mouse_screen: Vector2, factor: float) -> void:
	var half_vp = get_viewport_rect().size / 2.0

	# World point currently under the mouse
	var world_at_mouse = mouse_screen / _zoom + _camera_pos - half_vp

	# Apply zoom
	_zoom = clamp(_zoom * factor, _zoom_min, _zoom_max)

	# Solve for new _camera_pos so world_at_mouse maps back to mouse_screen:
	# mouse_screen = (world_at_mouse - new_camera + half_vp) * new_zoom
	# new_camera = world_at_mouse + half_vp - mouse_screen / new_zoom
	_camera_pos = world_at_mouse + half_vp - mouse_screen / _zoom
	queue_redraw()


func screen_to_tile(screen_pos: Vector2) -> Vector2i:
	# Inverse of tile_to_screen
	var tx = (screen_pos.x / float(HALF_W) + screen_pos.y / float(HALF_H)) / 2.0
	var ty = (screen_pos.y / float(HALF_H) - screen_pos.x / float(HALF_W)) / 2.0
	return Vector2i(int(round(tx)), int(round(ty)))


func _get_tile_diamond(center: Vector2) -> PackedVector2Array:
	var hw = float(HALF_W) * _zoom
	var hh = float(HALF_H) * _zoom
	return PackedVector2Array([
		Vector2(center.x,      center.y - hh),  # Top
		Vector2(center.x + hw, center.y),        # Right
		Vector2(center.x,      center.y + hh),  # Bottom
		Vector2(center.x - hw, center.y),        # Left
	])


# -------------------------------------------------------------
# DATA UPDATES (called by ClientMain)
# -------------------------------------------------------------
func receive_tile_chunk(tiles: Dictionary) -> void:
	# First pass: store all tile data
	for key in tiles:
		_tiles[key] = tiles[key]
	# Second pass: assign variants (after neighbors are stored)
	for key in tiles:
		var parts = key.split(",")
		if parts.size() >= 2:
			var tx        = int(parts[0])
			var ty        = int(parts[1])
			var tile_type = int(tiles[key].get("type", 0))
			if not _tile_variant_map.has(key):
				_assign_tile_variant(tx, ty, tile_type)
	_refresh_grass_layer()
	queue_redraw()


func _refresh_grass_layer() -> void:
	if _grass_layer == null:
		return
	var grass: Array[Vector2i] = []
	for key in _tiles:
		var tile_type = int(_tiles[key].get("type", -1))
		if tile_type == TileTypes.Type.GRASSLAND:
			var parts = key.split(",")
			if parts.size() >= 2:
				grass.append(Vector2i(int(parts[0]), int(parts[1])))
	_grass_layer.set_grass_tiles(grass)


func update_tile(x: int, y: int, tile: Dictionary) -> void:
	var key = str(x) + "," + str(y)
	_tiles[key] = tile
	# Re-assign variant only if the tile type changed
	var tile_type = int(tile.get("type", 0))
	if not _tile_variant_map.has(key):
		_assign_tile_variant(x, y, tile_type)
	queue_redraw()


func update_unit(unit_id: int, unit: Dictionary) -> void:
	_units[unit_id] = unit
	queue_redraw()


func remove_unit(unit_id: int) -> void:
	_units.erase(unit_id)
	_unit_visual_pos.erase(unit_id)
	if _hovered_unit_id == unit_id:
		_hovered_unit_id = -1
	queue_redraw()


# Assign a variant index to a tile using a no-same-neighbor rule.
# Called once per tile when tile data arrives. Deterministic per world seed.
func _assign_tile_variant(tx: int, ty: int, tile_type: int) -> void:
	var key      = str(tx) + "," + str(ty)
	var variants = _tile_variants.get(tile_type, [])
	if variants.size() == 0:
		return  # No sprites for this type — nothing to assign
	if variants.size() == 1:
		_tile_variant_map[key] = 0
		return

	# Gather variants already used by the 4 orthogonal neighbors
	var neighbor_offsets = [Vector2i(-1, 0), Vector2i(1, 0), Vector2i(0, -1), Vector2i(0, 1)]
	var used: Array[int] = []
	for offset in neighbor_offsets:
		var nkey = str(tx + offset.x) + "," + str(ty + offset.y)
		if _tile_variant_map.has(nkey):
			var nv = _tile_variant_map[nkey]
			if not used.has(nv):
				used.append(nv)

	# Build list of candidate indices that aren't used by neighbors
	var candidates: Array[int] = []
	for i in range(variants.size()):
		if not used.has(i):
			candidates.append(i)

	# If all variants are used by neighbors, allow any (still pick via hash)
	if candidates.is_empty():
		candidates = range(variants.size())

	# Deterministic pick: hash tile position so world looks the same on reload
	var hash_val = (tx * 73856093) ^ (ty * 19349663)
	_tile_variant_map[key] = candidates[abs(hash_val) % candidates.size()]


func set_selected_unit(unit_id: int) -> void:
	_selected_unit_id = unit_id
	if unit_id < 0:
		_selected_tile = Vector2i(-1, -1)
	queue_redraw()


func update_unit_position(unit_id: int, unit: Dictionary) -> void:
	if _units.has(unit_id):
		_units[unit_id] = unit
		queue_redraw()


func update_city(city_id: int, city: Dictionary) -> void:
	_cities[city_id] = city
	queue_redraw()


func update_season(season: String) -> void:
	_current_season = season
	queue_redraw()


# -------------------------------------------------------------
# CAMERA HELPERS
# -------------------------------------------------------------
func center_on_tile(tx: int, ty: int) -> void:
	_camera_pos = tile_to_screen(tx, ty)
	queue_redraw()


func center_on_unit(unit_id: int) -> void:
	if _units.has(unit_id):
		var unit = _units[unit_id]
		center_on_tile(unit.get("x", 0), unit.get("y", 0))


# -------------------------------------------------------------
# HELPERS
# -------------------------------------------------------------
func _get_player_color(player_id: int) -> Color:
	if _player_colors.has(player_id):
		return _player_colors[player_id]
	# Generate a consistent color from player_id
	var hue  = fmod(float(player_id) * 0.618033988, 1.0)
	var color = Color.from_hsv(hue, 0.7, 0.85)
	_player_colors[player_id] = color
	return color


func set_player_color(player_id: int, color: Color) -> void:
	_player_colors[player_id] = color
