class_name DevConsole
extends CanvasLayer

# =============================================================
# DEV CONSOLE
# In-game developer console. Only active when DEV_MODE = true.
# Toggle with backtick key.
# =============================================================


signal command_entered(command: String)


var _panel: PanelContainer
var _log_label: RichTextLabel
var _input: LineEdit
var _visible: bool = false

var _history: Array     = []
var _history_index: int = -1
var _log_lines: Array   = []
const MAX_LOG_LINES: int = 50


# -------------------------------------------------------------
# READY
# -------------------------------------------------------------
func _ready() -> void:
	layer = 100  # Always on top
	_build_console()
	visible = false


func _build_console() -> void:
	_panel = PanelContainer.new()
	add_child(_panel)

	var style = StyleBoxFlat.new()
	style.bg_color = Color(0.0, 0.0, 0.0, 0.88)
	style.border_color = Color(0.3, 0.8, 0.3, 0.9)
	style.set_border_width_all(1)
	_panel.add_theme_stylebox_override("panel", style)
	_panel.set_anchor(SIDE_LEFT,   0.0)
	_panel.set_anchor(SIDE_RIGHT,  1.0)
	_panel.set_anchor(SIDE_TOP,    0.0)
	_panel.set_anchor(SIDE_BOTTOM, 0.0)
	_panel.set_offset(SIDE_TOP,    0)
	_panel.set_offset(SIDE_BOTTOM, 280)

	var vbox = VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 2)
	_panel.add_child(vbox)

	# Header
	var header = Label.new()
	header.text = "  PRIMORDIUM DEV CONSOLE  |  /help for commands  |  ` to close"
	header.add_theme_color_override("font_color", Color(0.3, 0.9, 0.3))
	header.add_theme_font_size_override("font_size", 11)
	vbox.add_child(header)

	var sep = HSeparator.new()
	vbox.add_child(sep)

	# Log output
	_log_label = RichTextLabel.new()
	_log_label.custom_minimum_size = Vector2(0, 200)
	_log_label.bbcode_enabled      = true
	_log_label.scroll_following    = true
	_log_label.add_theme_font_size_override("normal_font_size", 11)
	vbox.add_child(_log_label)

	var sep2 = HSeparator.new()
	vbox.add_child(sep2)

	# Input row
	var input_row = HBoxContainer.new()
	vbox.add_child(input_row)

	var prompt = Label.new()
	prompt.text = "  > "
	prompt.add_theme_color_override("font_color", Color(0.3, 0.9, 0.3))
	prompt.add_theme_font_size_override("font_size", 12)
	input_row.add_child(prompt)

	_input = LineEdit.new()
	_input.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_input.add_theme_color_override("font_color", Color(0.9, 0.9, 0.9))
	_input.add_theme_font_size_override("font_size", 12)
	_input.text_submitted.connect(_on_input_submitted)
	input_row.add_child(_input)

	log_line("[color=#44ff44]Console ready. Type /help for commands.[/color]")


# -------------------------------------------------------------
# INPUT - history navigation
# -------------------------------------------------------------
func _unhandled_key_input(event: InputEvent) -> void:
	if not _visible:
		return
	if event is InputEventKey and event.pressed:
		match event.keycode:
			KEY_UP:
				if _history.size() > 0:
					_history_index = min(_history_index + 1, _history.size() - 1)
					_input.text    = _history[_history_index]
					_input.caret_column = _input.text.length()
			KEY_DOWN:
				if _history_index > 0:
					_history_index -= 1
					_input.text    = _history[_history_index]
				else:
					_history_index = -1
					_input.text    = ""
			KEY_ESCAPE:
				toggle()


# -------------------------------------------------------------
# TOGGLE
# -------------------------------------------------------------
func toggle() -> void:
	_visible = not _visible
	visible  = _visible
	if _visible:
		_input.grab_focus()
		_input.text = ""
	else:
		_input.release_focus()


# -------------------------------------------------------------
# COMMAND HANDLING
# -------------------------------------------------------------
func _on_input_submitted(text: String) -> void:
	var cmd = text.strip_edges()
	if cmd == "":
		return

	# Add to history
	if _history.size() == 0 or _history[0] != cmd:
		_history.push_front(cmd)
		if _history.size() > 50:
			_history.pop_back()
	_history_index = -1

	log_line("[color=#aaaaaa]> " + cmd + "[/color]")
	_input.text = ""

	emit_signal("command_entered", cmd)


# -------------------------------------------------------------
# LOGGING
# -------------------------------------------------------------
func log_line(text: String) -> void:
	_log_lines.append(text)
	if _log_lines.size() > MAX_LOG_LINES:
		_log_lines.remove_at(0)
	_log_label.clear()
	for line in _log_lines:
		_log_label.append_text(line + "\n")
