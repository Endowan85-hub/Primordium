class_name GameHUD
extends CanvasLayer

# =============================================================
# GAME HUD
# All in-game UI. Sits above the isometric map.
# Panels: top bar, unit panel, city panel, event panel,
#         tile info, minimap placeholder.
# =============================================================


signal found_city_requested(city_name: String)
signal assign_workers_requested(city_id: int, farmers: int, woodcutters: int, miners: int, researchers: int)
signal move_unit_requested(unit_id: int, tx: int, ty: int)
signal event_choice_made(event_id: String, choice_index: int)
signal dev_command(command: String)


# -------------------------------------------------------------
# PANELS
# -------------------------------------------------------------
var _top_bar: PanelContainer
var _unit_panel: PanelContainer
var _city_panel: PanelContainer
var _event_panel: PanelContainer
var _tile_panel: PanelContainer
var _status_label: Label

# Top bar labels
var _time_label: Label
var _season_label: Label
var _clock_label:  Label

# Unit panel
var _unit_name_label: Label
var _unit_status_label: Label
var _unit_travel_label: Label
var _found_city_btn: Button
var _found_city_name_edit: LineEdit

# City panel
var _city_name_label: Label
var _city_pop_label: Label
var _city_resources_label: Label
var _city_workers_label: Label
var _farmer_spin: SpinBox
var _woodcutter_spin: SpinBox
var _miner_spin: SpinBox
var _researcher_spin: SpinBox
var _assign_btn: Button

# Event panel
var _event_title_label: Label
var _event_desc_label: Label
var _event_timer_label: Label
var _event_choice_btns: Array = []
var _current_event: Dictionary = {}

# Tile panel
var _tile_type_label: Label
var _tile_resources_label: Label
var _tile_owner_label: Label
var _tile_improvement_label: Label

# Current city being shown
var _shown_city_id: int = -1


# -------------------------------------------------------------
# READY
# -------------------------------------------------------------
func _ready() -> void:
	_build_ui()


# -------------------------------------------------------------
# BUILD UI
# Programmatic UI construction - no scene file needed
# -------------------------------------------------------------
func _build_ui() -> void:
	_build_top_bar()
	_build_unit_panel()
	_build_city_panel()
	_build_event_panel()
	_build_tile_panel()
	_build_status_label()


func _build_top_bar() -> void:
	_top_bar = PanelContainer.new()
	_top_bar.name = "TopBar"
	add_child(_top_bar)

	var style = StyleBoxFlat.new()
	style.bg_color = Color(0.05, 0.05, 0.08, 0.85)
	style.set_corner_radius_all(0)
	_top_bar.add_theme_stylebox_override("panel", style)
	_top_bar.set_anchors_and_offsets_preset(Control.PRESET_TOP_WIDE)
	_top_bar.custom_minimum_size = Vector2(0, 36)

	var hbox = HBoxContainer.new()
	hbox.add_theme_constant_override("separation", 20)
	_top_bar.add_child(hbox)

	# Add spacer at left
	var spacer_l = Control.new()
	spacer_l.custom_minimum_size = Vector2(10, 0)
	hbox.add_child(spacer_l)

	_time_label = Label.new()
	_time_label.text = "Day 1 | Spring | Year 1"
	_time_label.add_theme_color_override("font_color", Color(0.9, 0.85, 0.6))
	_time_label.add_theme_font_size_override("font_size", 14)
	hbox.add_child(_time_label)

	var divider = Label.new()
	divider.text = "|"
	divider.add_theme_color_override("font_color", Color(0.4, 0.4, 0.4))
	hbox.add_child(divider)

	_season_label = Label.new()
	_season_label.text = "Spring"
	_season_label.add_theme_color_override("font_color", Color(0.5, 0.9, 0.5))
	_season_label.add_theme_font_size_override("font_size", 14)
	hbox.add_child(_season_label)

	var divider2 = Label.new()
	divider2.text = "|"
	divider2.add_theme_color_override("font_color", Color(0.4, 0.4, 0.4))
	hbox.add_child(divider2)

	_clock_label = Label.new()
	_clock_label.text = "6:00 AM"
	_clock_label.add_theme_color_override("font_color", Color(0.85, 0.9, 1.0))
	_clock_label.add_theme_font_size_override("font_size", 14)
	hbox.add_child(_clock_label)

	# Right side spacer
	var spacer_r = Control.new()
	spacer_r.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	hbox.add_child(spacer_r)


func _build_unit_panel() -> void:
	_unit_panel = PanelContainer.new()
	_unit_panel.name = "UnitPanel"
	add_child(_unit_panel)

	var style = StyleBoxFlat.new()
	style.bg_color = Color(0.05, 0.05, 0.10, 0.90)
	style.border_color = Color(0.3, 0.4, 0.6, 0.8)
	style.set_border_width_all(1)
	style.set_corner_radius_all(4)
	_unit_panel.add_theme_stylebox_override("panel", style)
	_unit_panel.set_anchor(SIDE_LEFT,   0.0)
	_unit_panel.set_anchor(SIDE_RIGHT,  0.0)
	_unit_panel.set_anchor(SIDE_TOP,    1.0)
	_unit_panel.set_anchor(SIDE_BOTTOM, 1.0)
	_unit_panel.set_offset(SIDE_LEFT,   10)
	_unit_panel.set_offset(SIDE_RIGHT,  220)
	_unit_panel.set_offset(SIDE_TOP,    -200)
	_unit_panel.set_offset(SIDE_BOTTOM, -10)
	_unit_panel.visible = false

	var vbox = VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 4)
	_unit_panel.add_child(vbox)

	_unit_name_label = Label.new()
	_unit_name_label.add_theme_color_override("font_color", Color(0.9, 0.85, 0.6))
	_unit_name_label.add_theme_font_size_override("font_size", 13)
	vbox.add_child(_unit_name_label)

	_unit_status_label = Label.new()
	_unit_status_label.add_theme_color_override("font_color", Color(0.7, 0.8, 0.7))
	_unit_status_label.add_theme_font_size_override("font_size", 11)
	vbox.add_child(_unit_status_label)

	_unit_travel_label = Label.new()
	_unit_travel_label.add_theme_color_override("font_color", Color(0.4, 0.8, 0.9))
	_unit_travel_label.add_theme_font_size_override("font_size", 11)
	_unit_travel_label.visible = false
	vbox.add_child(_unit_travel_label)

	var sep = HSeparator.new()
	vbox.add_child(sep)

	# Found city section
	_found_city_name_edit = LineEdit.new()
	_found_city_name_edit.placeholder_text = "City name..."
	_found_city_name_edit.custom_minimum_size = Vector2(0, 28)
	_found_city_name_edit.visible = false
	vbox.add_child(_found_city_name_edit)

	_found_city_btn = Button.new()
	_found_city_btn.text = "Found City"
	_found_city_btn.visible = false
	_found_city_btn.pressed.connect(_on_found_city_pressed)
	vbox.add_child(_found_city_btn)


func _build_city_panel() -> void:
	_city_panel = PanelContainer.new()
	_city_panel.name = "CityPanel"
	add_child(_city_panel)

	var style = StyleBoxFlat.new()
	style.bg_color = Color(0.05, 0.05, 0.10, 0.90)
	style.border_color = Color(0.5, 0.4, 0.2, 0.8)
	style.set_border_width_all(1)
	style.set_corner_radius_all(4)
	_city_panel.add_theme_stylebox_override("panel", style)
	_city_panel.set_anchor(SIDE_LEFT,   1.0)
	_city_panel.set_anchor(SIDE_RIGHT,  1.0)
	_city_panel.set_anchor(SIDE_TOP,    0.0)
	_city_panel.set_anchor(SIDE_BOTTOM, 0.0)
	_city_panel.set_offset(SIDE_LEFT,   -230)
	_city_panel.set_offset(SIDE_RIGHT,  -10)
	_city_panel.set_offset(SIDE_TOP,    46)
	_city_panel.set_offset(SIDE_BOTTOM, 340)
	_city_panel.visible = false

	var vbox = VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 5)
	_city_panel.add_child(vbox)

	_city_name_label = Label.new()
	_city_name_label.add_theme_color_override("font_color", Color(0.95, 0.85, 0.5))
	_city_name_label.add_theme_font_size_override("font_size", 14)
	vbox.add_child(_city_name_label)

	_city_pop_label = Label.new()
	_city_pop_label.add_theme_color_override("font_color", Color(0.7, 0.85, 0.7))
	_city_pop_label.add_theme_font_size_override("font_size", 11)
	vbox.add_child(_city_pop_label)

	_city_resources_label = Label.new()
	_city_resources_label.add_theme_color_override("font_color", Color(0.7, 0.8, 0.9))
	_city_resources_label.add_theme_font_size_override("font_size", 11)
	_city_resources_label.autowrap_mode = TextServer.AUTOWRAP_WORD
	vbox.add_child(_city_resources_label)

	var sep = HSeparator.new()
	vbox.add_child(sep)

	var workers_title = Label.new()
	workers_title.text = "WORKERS"
	workers_title.add_theme_color_override("font_color", Color(0.6, 0.6, 0.7))
	workers_title.add_theme_font_size_override("font_size", 10)
	vbox.add_child(workers_title)

	# Worker spinboxes
	var worker_types = [
		["Farmers", "_farmer_spin"],
		["Woodcutters", "_woodcutter_spin"],
		["Miners", "_miner_spin"],
		["Researchers", "_researcher_spin"]
	]
	for wt in worker_types:
		var row = HBoxContainer.new()
		vbox.add_child(row)
		var lbl = Label.new()
		lbl.text = wt[0]
		lbl.add_theme_color_override("font_color", Color(0.8, 0.8, 0.8))
		lbl.add_theme_font_size_override("font_size", 11)
		lbl.custom_minimum_size = Vector2(90, 0)
		row.add_child(lbl)
		var spin = SpinBox.new()
		spin.min_value = 0
		spin.max_value = 50
		spin.step = 1
		spin.custom_minimum_size = Vector2(70, 0)
		row.add_child(spin)
		set(wt[1], spin)

	_assign_btn = Button.new()
	_assign_btn.text = "Assign Workers"
	_assign_btn.pressed.connect(_on_assign_workers_pressed)
	vbox.add_child(_assign_btn)


func _build_event_panel() -> void:
	_event_panel = PanelContainer.new()
	_event_panel.name = "EventPanel"
	add_child(_event_panel)

	var style = StyleBoxFlat.new()
	style.bg_color = Color(0.08, 0.05, 0.05, 0.95)
	style.border_color = Color(0.7, 0.4, 0.1, 0.9)
	style.set_border_width_all(2)
	style.set_corner_radius_all(4)
	_event_panel.add_theme_stylebox_override("panel", style)
	_event_panel.set_anchor(SIDE_LEFT,   0.5)
	_event_panel.set_anchor(SIDE_RIGHT,  0.5)
	_event_panel.set_anchor(SIDE_TOP,    0.5)
	_event_panel.set_anchor(SIDE_BOTTOM, 0.5)
	_event_panel.set_offset(SIDE_LEFT,   -200)
	_event_panel.set_offset(SIDE_RIGHT,  200)
	_event_panel.set_offset(SIDE_TOP,    -150)
	_event_panel.set_offset(SIDE_BOTTOM, 150)
	_event_panel.visible = false

	var vbox = VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 8)
	_event_panel.add_child(vbox)

	_event_title_label = Label.new()
	_event_title_label.add_theme_color_override("font_color", Color(0.95, 0.75, 0.3))
	_event_title_label.add_theme_font_size_override("font_size", 14)
	_event_title_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vbox.add_child(_event_title_label)

	_event_timer_label = Label.new()
	_event_timer_label.add_theme_color_override("font_color", Color(0.8, 0.4, 0.2))
	_event_timer_label.add_theme_font_size_override("font_size", 10)
	_event_timer_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vbox.add_child(_event_timer_label)

	_event_desc_label = Label.new()
	_event_desc_label.add_theme_color_override("font_color", Color(0.85, 0.85, 0.85))
	_event_desc_label.add_theme_font_size_override("font_size", 11)
	_event_desc_label.autowrap_mode = TextServer.AUTOWRAP_WORD
	vbox.add_child(_event_desc_label)

	var sep = HSeparator.new()
	vbox.add_child(sep)

	# Up to 4 choice buttons
	for i in range(4):
		var btn = Button.new()
		btn.visible = false
		btn.autowrap_mode = TextServer.AUTOWRAP_WORD
		btn.custom_minimum_size = Vector2(0, 30)
		var captured_i = i
		btn.pressed.connect(func(): _on_event_choice_pressed(captured_i))
		vbox.add_child(btn)
		_event_choice_btns.append(btn)


func _build_tile_panel() -> void:
	_tile_panel = PanelContainer.new()
	_tile_panel.name = "TilePanel"
	add_child(_tile_panel)

	var style = StyleBoxFlat.new()
	style.bg_color = Color(0.05, 0.07, 0.05, 0.85)
	style.border_color = Color(0.3, 0.5, 0.3, 0.6)
	style.set_border_width_all(1)
	style.set_corner_radius_all(4)
	_tile_panel.add_theme_stylebox_override("panel", style)
	_tile_panel.set_anchor(SIDE_LEFT,   0.0)
	_tile_panel.set_anchor(SIDE_RIGHT,  0.0)
	_tile_panel.set_anchor(SIDE_TOP,    1.0)
	_tile_panel.set_anchor(SIDE_BOTTOM, 1.0)
	_tile_panel.set_offset(SIDE_LEFT,   10)
	_tile_panel.set_offset(SIDE_RIGHT,  220)
	_tile_panel.set_offset(SIDE_TOP,    -180)
	_tile_panel.set_offset(SIDE_BOTTOM, -10)
	_tile_panel.visible = false

	var vbox = VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 4)
	_tile_panel.add_child(vbox)

	_tile_type_label = Label.new()
	_tile_type_label.add_theme_color_override("font_color", Color(0.8, 0.9, 0.7))
	_tile_type_label.add_theme_font_size_override("font_size", 13)
	vbox.add_child(_tile_type_label)

	_tile_resources_label = Label.new()
	_tile_resources_label.add_theme_color_override("font_color", Color(0.7, 0.8, 0.9))
	_tile_resources_label.add_theme_font_size_override("font_size", 11)
	_tile_resources_label.autowrap_mode = TextServer.AUTOWRAP_WORD
	vbox.add_child(_tile_resources_label)

	_tile_owner_label = Label.new()
	_tile_owner_label.add_theme_color_override("font_color", Color(0.8, 0.7, 0.5))
	_tile_owner_label.add_theme_font_size_override("font_size", 11)
	vbox.add_child(_tile_owner_label)

	_tile_improvement_label = Label.new()
	_tile_improvement_label.add_theme_color_override("font_color", Color(0.7, 0.9, 0.7))
	_tile_improvement_label.add_theme_font_size_override("font_size", 11)
	vbox.add_child(_tile_improvement_label)


func _build_status_label() -> void:
	_status_label = Label.new()
	_status_label.name = "StatusLabel"
	add_child(_status_label)
	_status_label.set_anchor(SIDE_LEFT,   0.5)
	_status_label.set_anchor(SIDE_RIGHT,  0.5)
	_status_label.set_anchor(SIDE_TOP,    0.0)
	_status_label.set_anchor(SIDE_BOTTOM, 0.0)
	_status_label.set_offset(SIDE_LEFT,   -100)
	_status_label.set_offset(SIDE_RIGHT,  100)
	_status_label.set_offset(SIDE_TOP,    40)
	_status_label.set_offset(SIDE_BOTTOM, 60)
	_status_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_status_label.add_theme_color_override("font_color", Color(0.5, 0.8, 0.5))
	_status_label.add_theme_font_size_override("font_size", 12)
	_status_label.visible = false


# -------------------------------------------------------------
# PUBLIC API - called by ClientMain
# -------------------------------------------------------------
func update_time(day: int, season: String, year: int, tick: int = 0) -> void:
	var season_cap = season.capitalize()
	_time_label.text = "Day " + str(day % GameConstants.DAYS_PER_YEAR) + \
		"  |  " + season_cap + "  |  Year " + str(year)
	_season_label.text = season_cap

	# Clock: tick within current day → hour of day
	# Day starts at 6:00 AM so players wake into morning, not midnight
	var ticks_in_day  = tick % GameConstants.TICKS_PER_DAY
	var day_fraction  = float(ticks_in_day) / float(GameConstants.TICKS_PER_DAY)
	var hour_float    = fmod(6.0 + day_fraction * 24.0, 24.0)
	var hour          = int(hour_float)
	var minute        = int((hour_float - float(hour)) * 60.0)
	var is_am         = hour < 12
	var display_hour  = hour % 12
	if display_hour == 0:
		display_hour = 12
	var time_str      = str(display_hour) + ":" + ("%02d" % minute) + (" AM" if is_am else " PM")
	_clock_label.text = time_str
	# Tint: warm gold at dawn/dusk, pale blue midday, dark blue at night
	if hour >= 5 and hour < 8:      # Dawn
		_clock_label.add_theme_color_override("font_color", Color(1.0, 0.8, 0.4))
	elif hour >= 8 and hour < 17:   # Day
		_clock_label.add_theme_color_override("font_color", Color(0.85, 0.9, 1.0))
	elif hour >= 17 and hour < 20:  # Dusk
		_clock_label.add_theme_color_override("font_color", Color(1.0, 0.65, 0.3))
	else:                           # Night
		_clock_label.add_theme_color_override("font_color", Color(0.5, 0.55, 0.8))

	var season_colors: Dictionary = {
		"spring": Color(0.5, 0.9, 0.5),
		"summer": Color(0.9, 0.8, 0.3),
		"autumn": Color(0.9, 0.6, 0.2),
		"winter": Color(0.6, 0.7, 0.9)
	}
	_season_label.add_theme_color_override("font_color",
		season_colors.get(season, Color.WHITE))


func show_status(msg: String) -> void:
	_status_label.text = msg
	_status_label.visible = true
	# Auto-hide after 3 seconds
	var timer = get_tree().create_timer(3.0)
	timer.timeout.connect(func(): _status_label.visible = false)


func show_unit_panel(unit: Dictionary) -> void:
	_unit_panel.visible = true
	_city_panel.visible = false
	_tile_panel.visible = false

	var unit_type = unit.get("type", "unit").capitalize()
	_unit_name_label.text = unit_type

	var status = unit.get("status", "idle")
	_unit_status_label.text = "Status: " + status.capitalize()

	if status == "moving" and unit.get("travel_target") != null:
		var progress = unit.get("travel_progress", 0.0)
		var total    = unit.get("travel_total", 1.0)
		var pct      = int(clamp(progress / max(total, 0.001), 0.0, 1.0) * 100)
		var target   = unit["travel_target"]
		_unit_travel_label.text = "Traveling to (" + str(target["x"]) + \
			"," + str(target["y"]) + ") " + str(pct) + "%"
		_unit_travel_label.visible = true
	else:
		_unit_travel_label.visible = false


func update_unit_panel(unit: Dictionary) -> void:
	if _unit_panel.visible:
		show_unit_panel(unit)


func show_found_city_button(show: bool) -> void:
	_found_city_btn.visible = show
	_found_city_name_edit.visible = show
	if show:
		_found_city_name_edit.grab_focus()


func show_city_panel(city: Dictionary) -> void:
	_city_panel.visible = true
	_unit_panel.visible = false
	_tile_panel.visible = false
	_shown_city_id = city.get("id", -1)
	update_city_panel(city)


func update_city_panel(city: Dictionary) -> void:
	if not _city_panel.visible:
		return

	_city_name_label.text = city.get("name", "City")

	var pop     = city.get("population", 0)
	var pop_cap = city.get("pop_cap",    0)
	_city_pop_label.text = "Population: " + str(pop) + " / " + str(pop_cap)

	var food  = snappedf(city.get("food",  0.0), 0.1)
	var wood  = snappedf(city.get("wood",  0.0), 0.1)
	var stone = snappedf(city.get("stone", 0.0), 0.1)
	var water = snappedf(city.get("water", 0.0), 0.1)
	var water_cap    = snappedf(city.get("water_cap", 100.0), 0.1)
	var water_status = city.get("water_status", "normal")
	var water_suffix = ""
	if water_status == "low":      water_suffix = " [LOW]"
	elif water_status == "critical": water_suffix = " [CRITICAL!]"
	_city_resources_label.text = "Food: "  + str(food)  + "\n" + \
		"Wood: "  + str(wood)  + "\n" + \
		"Stone: " + str(stone) + "\n" + \
		"Water: " + str(water) + "/" + str(water_cap) + water_suffix

	_farmer_spin.value     = city.get("farmers",     0)
	_woodcutter_spin.value = city.get("woodcutters", 0)
	_miner_spin.value      = city.get("miners",      0)
	_researcher_spin.value = city.get("researchers", 0)


func show_tile_info(x: int, y: int, tile: Dictionary) -> void:
	if tile.is_empty():
		_tile_panel.visible = false
		return

	_tile_panel.visible = true
	_unit_panel.visible = false

	var tile_type = int(tile.get("type", TileTypes.Type.GRASSLAND))
	_tile_type_label.text = TileTypes.TILE_NAMES.get(tile_type, "Unknown") + \
		"  (" + str(x) + "," + str(y) + ")"

	var res_text = ""
	var resources = tile.get("resources", {})
	for key in resources:
		if key.ends_with("_max"):
			continue
		var val     = snappedf(resources[key], 0.1)
		var max_key = key + "_max"
		var max_val = snappedf(resources.get(max_key, 0.0), 0.1)
		res_text   += key.capitalize() + ": " + str(val) + "/" + str(max_val) + "\n"
	_tile_resources_label.text = res_text.strip_edges()

	var owner = tile.get("owner", -1)
	_tile_owner_label.text = "Owner: " + ("Unclaimed" if owner < 0 else "Player " + str(owner))

	var improvement = int(tile.get("improvement", TileTypes.Improvement.NONE))
	var imp_name    = TileTypes.IMPROVEMENT_NAMES.get(improvement, "None")
	_tile_improvement_label.text = "Improvement: " + imp_name

	# Show water yield from this tile type
	var tile_data    = TileTypes.TILE_RESOURCES.get(tile_type, {})
	var water_yield  = tile_data.get("water_yield", 0.0)
	if water_yield > 0:
		_tile_improvement_label.text += "\nWater yield: " + str(snappedf(water_yield, 0.1)) + "/tick"
		if improvement == TileTypes.Improvement.WELL:
			var well_mult = TileTypes.IMPROVEMENT_EFFECTS.get(TileTypes.Improvement.WELL, {}).get("water_yield_multiplier", 1.0)
			_tile_improvement_label.text += " (Well: x" + str(well_mult) + ")"

	# Elevation — shown as a level with a combat hint
	var elev = tile.get("elevation", -1)
	if elev >= 0:
		var elev_desc: String
		if elev <= 1:
			elev_desc = "lowland"
		elif elev <= 3:
			elev_desc = "plains"
		elif elev <= 5:
			elev_desc = "highland"
		elif elev <= 7:
			elev_desc = "mountain"
		else:
			elev_desc = "peak"
		_tile_improvement_label.text += "\nElevation: " + str(elev) + "  (" + elev_desc + ")"

	# Show build progress if under construction
	var build_prog = tile.get("build_progress", 0.0)
	if build_prog > 0:
		var building = TileTypes.IMPROVEMENT_NAMES.get(
			tile.get("building_improvement", TileTypes.Improvement.NONE), "")
		_tile_improvement_label.text += "\nBuilding " + building + \
			" (" + str(int(build_prog)) + " ticks left)"


func show_foreign_unit_info(unit: Dictionary) -> void:
	_unit_panel.visible = true
	_unit_name_label.text = "Enemy " + unit.get("type", "Unit").capitalize()
	_unit_status_label.text = "Owner: Player " + str(unit.get("owner", "?"))
	_unit_travel_label.visible = false
	_found_city_btn.visible    = false
	_found_city_name_edit.visible = false


func show_event(event: Dictionary) -> void:
	_current_event = event
	_event_panel.visible = true

	_event_title_label.text = event.get("title", "Event")
	_event_desc_label.text  = event.get("description", "")

	var days = snappedf(event.get("days_remaining", 0.0), 0.1)
	_event_timer_label.text = str(days) + " days to decide"

	var choices = event.get("choices", [])
	for i in range(_event_choice_btns.size()):
		if i < choices.size():
			_event_choice_btns[i].text    = choices[i].get("text", "Option " + str(i + 1))
			_event_choice_btns[i].visible = true
		else:
			_event_choice_btns[i].visible = false

	# If no choices, add a single dismiss button
	if choices.size() == 0:
		_event_choice_btns[0].text    = "Dismiss"
		_event_choice_btns[0].visible = true


# -------------------------------------------------------------
# BUTTON HANDLERS
# -------------------------------------------------------------
func _on_found_city_pressed() -> void:
	var city_name = _found_city_name_edit.text.strip_edges()
	if city_name == "":
		city_name = "New City"
	emit_signal("found_city_requested", city_name)
	_found_city_btn.visible       = false
	_found_city_name_edit.visible = false
	_unit_panel.visible           = false


func _on_assign_workers_pressed() -> void:
	if _shown_city_id < 0:
		return
	emit_signal("assign_workers_requested",
		_shown_city_id,
		int(_farmer_spin.value),
		int(_woodcutter_spin.value),
		int(_miner_spin.value),
		int(_researcher_spin.value)
	)
	show_status("Workers assigned")


func _on_event_choice_pressed(choice_index: int) -> void:
	var event_id = _current_event.get("id", "")
	emit_signal("event_choice_made", event_id, choice_index)
	_event_panel.visible = false
	_current_event = {}
