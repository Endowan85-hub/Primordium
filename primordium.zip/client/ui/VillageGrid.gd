class_name VillageGrid
extends Control

# =============================================================
# VILLAGE GRID  —  top-down grid renderer
# =============================================================

signal cell_clicked(gx: int, gy: int)
signal cell_hovered(gx: int, gy: int)

const CELL_SIZE: int  = 48
const GRID_SIZE: int  = 10   # VillageConstants.VILLAGE_GRID_SIZE

# "x,y" -> { type, state, build_ticks_left, is_origin, origin_x, origin_y }
var _grid: Dictionary = {}

var _ghost_type:  int  = 0
var _ghost_gx:    int  = -1
var _ghost_gy:    int  = -1
var _ghost_valid: bool = false

const COL_GROUND    := Color(0.35, 0.55, 0.25)
const COL_GRIDLINE  := Color(0.0,  0.0,  0.0,  0.18)
const COL_HOVER     := Color(1.0,  1.0,  1.0,  0.15)
const COL_GHOST_OK  := Color(0.3,  1.0,  0.3,  0.45)
const COL_GHOST_BAD := Color(1.0,  0.2,  0.2,  0.45)
const COL_CONSTRUCT := Color(0.9,  0.75, 0.2,  0.7)
const COL_ROAD      := Color(0.6,  0.55, 0.48)


func _ready() -> void:
	custom_minimum_size = Vector2(GRID_SIZE * CELL_SIZE, GRID_SIZE * CELL_SIZE)
	mouse_filter = Control.MOUSE_FILTER_STOP
	set_process(true)


func _process(_delta: float) -> void:
	queue_redraw()


func load_grid(buildings: Array) -> void:
	_grid.clear()
	for b in buildings:
		var bx: int   = b.get("gx", 0)
		var by: int   = b.get("gy", 0)
		var bt: int   = b.get("type", 0)
		var bsz: Array = _bsize(bt)
		for dy in range(bsz[1]):
			for dx in range(bsz[0]):
				var key = str(bx + dx) + "," + str(by + dy)
				_grid[key] = {
					"type":             bt,
					"state":            b.get("state", "active"),
					"build_ticks_left": b.get("build_ticks_left", 0),
					"origin_x":         bx,
					"origin_y":         by,
					"is_origin":        (dx == 0 and dy == 0),
				}
	queue_redraw()


func set_ghost(building_type: int) -> void:
	_ghost_type = building_type
	queue_redraw()


func clear_ghost() -> void:
	_ghost_type = 0
	_ghost_gx   = -1
	_ghost_gy   = -1
	queue_redraw()


func is_placement_valid(gx: int, gy: int, building_type: int) -> bool:
	var bsz = _bsize(building_type)
	for dy in range(bsz[1]):
		for dx in range(bsz[0]):
			var cx = gx + dx
			var cy = gy + dy
			if cx < 0 or cy < 0 or cx >= GRID_SIZE or cy >= GRID_SIZE:
				return false
			if _grid.has(str(cx) + "," + str(cy)):
				return false
	return true


func _draw() -> void:
	draw_rect(Rect2(Vector2.ZERO, size), COL_GROUND)

	for gy in range(GRID_SIZE):
		for gx in range(GRID_SIZE):
			var rect = _crect(gx, gy)
			var key  = str(gx) + "," + str(gy)
			var cell = _grid.get(key, null)
			if cell:
				_draw_cell(rect, cell)
			else:
				draw_rect(rect, COL_GRIDLINE, false, 0.5)
			if gx == _ghost_gx and gy == _ghost_gy and _ghost_type == 0:
				draw_rect(rect, COL_HOVER, true)

	if _ghost_type != 0 and _ghost_gx >= 0:
		var bsz = _bsize(_ghost_type)
		var col = COL_GHOST_OK if _ghost_valid else COL_GHOST_BAD
		for dy in range(bsz[1]):
			for dx in range(bsz[0]):
				var gx = _ghost_gx + dx
				var gy = _ghost_gy + dy
				if gx >= 0 and gx < GRID_SIZE and gy >= 0 and gy < GRID_SIZE:
					draw_rect(_crect(gx, gy), col, true)
					draw_rect(_crect(gx, gy), Color(col.r, col.g, col.b, 0.9), false, 1.5)

	# Grid lines on top
	for i in range(GRID_SIZE + 1):
		var p = float(i * CELL_SIZE)
		draw_line(Vector2(p, 0),      Vector2(p, size.y), COL_GRIDLINE, 0.5)
		draw_line(Vector2(0, p),      Vector2(size.x, p), COL_GRIDLINE, 0.5)


func _draw_cell(rect: Rect2, cell: Dictionary) -> void:
	var bt    = cell["type"]
	var state = cell["state"]
	var is_og = cell["is_origin"]
	var col   = VillageConstants.BUILDING_COLORS.get(bt, Color(0.5, 0.5, 0.5))

	if bt == 5:   # Road
		draw_rect(rect, COL_ROAD, true)
		var mid_y = rect.position + Vector2(0, rect.size.y * 0.5)
		var mid_x = rect.position + Vector2(rect.size.x * 0.5, 0)
		draw_line(mid_y, mid_y + Vector2(rect.size.x, 0), col.darkened(0.3), 1.0)
		draw_line(mid_x, mid_x + Vector2(0, rect.size.y), col.darkened(0.3), 1.0)
		return

	draw_rect(rect, col, true)

	if state == "building":
		draw_rect(rect, COL_CONSTRUCT, true)
		var tl   = cell.get("build_ticks_left", 1)
		var tot  = VillageConstants.BUILDING_BUILD_TICKS.get(bt, 1)
		var prog = 1.0 - clamp(float(tl) / float(max(tot, 1)), 0.0, 1.0)
		var bar  = Rect2(rect.position + Vector2(2, rect.size.y - 6),
			Vector2((rect.size.x - 4) * prog, 4))
		draw_rect(bar, Color(0.2, 0.9, 0.2), true)

	if is_og:
		var label = VillageConstants.BUILDING_NAMES.get(bt, "?")
		if label.length() > 6:
			label = label.left(4) + "."
		draw_string(ThemeDB.fallback_font, rect.position + Vector2(3, 13),
			label, HORIZONTAL_ALIGNMENT_LEFT, -1, 10, Color.WHITE)

	draw_rect(rect, col.darkened(0.3), false, 1.0)


func _crect(gx: int, gy: int) -> Rect2:
	return Rect2(Vector2(gx * CELL_SIZE, gy * CELL_SIZE), Vector2(CELL_SIZE, CELL_SIZE))


func _bsize(bt: int) -> Array:
	if bt == 1 or bt == 6: return [2, 2]
	if bt == 3:            return [2, 1]
	return [1, 1]


func _gui_input(event: InputEvent) -> void:
	if event is InputEventMouseMotion:
		var gx = clampi(int(event.position.x / CELL_SIZE), 0, GRID_SIZE - 1)
		var gy = clampi(int(event.position.y / CELL_SIZE), 0, GRID_SIZE - 1)
		if gx != _ghost_gx or gy != _ghost_gy:
			_ghost_gx = gx
			_ghost_gy = gy
			if _ghost_type != 0:
				_ghost_valid = is_placement_valid(gx, gy, _ghost_type)
			emit_signal("cell_hovered", gx, gy)

	elif event is InputEventMouseButton:
		if event.button_index == MOUSE_BUTTON_LEFT and event.pressed:
			var gx = clampi(int(event.position.x / CELL_SIZE), 0, GRID_SIZE - 1)
			var gy = clampi(int(event.position.y / CELL_SIZE), 0, GRID_SIZE - 1)
			emit_signal("cell_clicked", gx, gy)
