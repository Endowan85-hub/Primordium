class_name GrassLayer
extends RefCounted

# =============================================================
# GRASS LAYER  v5
# Not a Node — draws directly into IsometricMap's canvas so
# grass is always behind units and cities in the draw order.
# IsometricMap calls draw_into(self, half_vp) from _draw().
# =============================================================

@export var wind_speed:    float = 0.18
@export var wind_strength: float = 2.2

var _map: Node2D = null
var _blade_cache: Dictionary = {}   # Vector2i -> Array of blade dicts

const C0 = Color(0x1a/255.0, 0x33/255.0, 0x18/255.0)
const C1 = Color(0x2d/255.0, 0x52/255.0, 0x24/255.0)
const C2 = Color(0x4a/255.0, 0x7a/255.0, 0x3c/255.0)
const C3 = Color(0x6e/255.0, 0xa0/255.0, 0x50/255.0)
const C4 = Color(0x9c/255.0, 0xc8/255.0, 0x70/255.0)
const SHADOW_COL = Color(0.05, 0.14, 0.03, 0.35)
const COLORS = [C0, C1, C2, C3, C4]


func set_grass_tiles(tiles: Array[Vector2i]) -> void:
	_blade_cache.clear()
	for tile_pos in tiles:
		_blade_cache[tile_pos] = _build_blades(tile_pos)


static func _hash2(a: int, b: int) -> int:
	var v = (a * 374761393 + b * 668265263) ^ ((a ^ b) * 2246822519)
	v = (v ^ (v >> 13)) * 1274126177
	return abs(v) & 0x7FFFFFFF


func _build_blades(tile_pos: Vector2i) -> Array:
	var tx = tile_pos.x
	var ty = tile_pos.y
	var count = 1 + (_hash2(tx * 7, ty * 13) % 10)
	var blades: Array = []

	for i in range(count):
		var h1 = _hash2(tx + i * 3,  ty + i * 5)
		var h2 = _hash2(tx + i * 11, ty - i * 7)
		var h3 = _hash2(tx - i * 17, ty + i * 13)
		var h4 = _hash2(tx + i * 23, ty + i * 19 + tx)

		var u = (float(h1 % 10000) / 10000.0) * 2.0 - 1.0
		var v = (float(h2 % 10000) / 10000.0) * 2.0 - 1.0
		if abs(u) + abs(v) > 0.88:
			continue
		v = v * 0.55 + 0.08

		var height_n = 0.30 + (float(h3 % 10000) / 10000.0) * 0.70
		var width_n  = 0.50 + (float(h4 % 10000) / 10000.0) * 0.50
		var lean     = (float((h1 ^ h3) % 10000) / 10000.0 - 0.5) * 2.0
		var phase    = float(_hash2(h2, h4)) / float(0x7FFFFFFF) * TAU
		var freq_var = 0.55 + float((h3 ^ h1) % 10000) / 10000.0 * 0.90
		var style    = _hash2(h1 + 1, h3 + 1) % 3
		var gust_phase   = float(_hash2(h2 + 7, h1 + 3)) / float(0x7FFFFFFF) * TAU
		var flutter_freq = 3.0 + float(_hash2(h4 + 5, h2 + 9) % 10000) / 10000.0 * 4.0

		blades.append({
			"u": u, "v": v,
			"height": height_n, "width": width_n,
			"lean": lean, "phase": phase, "freq": freq_var,
			"style": style,
			"gust_phase": gust_phase,
			"flutter_freq": flutter_freq,
			"shade": int(height_n * 2.9),
		})
	return blades


func _blade_sway(blade: Dictionary, t: float) -> float:
	var f  = blade["freq"] * wind_speed
	var ph = blade["phase"]
	match blade["style"]:
		0:
			return (
				sin(t * f * TAU + ph)                * 0.60
				+ sin(t * f * TAU * 2.1 + ph * 1.3) * 0.25
				+ sin(t * f * TAU * 3.7 + ph * 0.7) * 0.15
			)
		1:
			var env = pow(sin(t * f * TAU * 0.4 + blade["gust_phase"]) * 0.5 + 0.5, 2.0)
			return sin(t * f * TAU * 1.8 + ph) * env * 1.4 \
				+ sin(t * f * TAU * 0.9 + ph * 1.8) * 0.2
		2:
			var ff = blade["flutter_freq"]
			return (
				sin(t * f * TAU * ff         + ph)       * 0.35
				+ sin(t * f * TAU * ff * 1.6 + ph * 2.1) * 0.25
				+ sin(t * f * TAU * 0.8      + ph * 0.5) * 0.40
			)
	return 0.0


# Called from IsometricMap._draw() — draws into the map's own canvas item.
# This puts grass in the correct depth layer: after tiles, before units.
func draw_into(canvas: CanvasItem, half_vp: Vector2) -> void:
	if _map == null or _blade_cache.is_empty():
		return

	var zoom    = _map._zoom
	var cam     = _map._camera_pos
	var vpw     = canvas.get_viewport_rect().size.x
	var vph     = canvas.get_viewport_rect().size.y
	var t       = Time.get_ticks_msec() / 1000.0
	var tw_half = float(_map.TILE_W) / 2.0
	var th_half = float(_map.TILE_H) / 2.0

	for tile_pos in _blade_cache:
		var blades = _blade_cache[tile_pos]
		if blades.is_empty():
			continue

		var world = _map.tile_to_screen(tile_pos.x, tile_pos.y)
		var key   = str(tile_pos.x) + "," + str(tile_pos.y)
		var tile  = _map._tiles.get(key, {})
		var lift  = _map._get_tile_lift(tile) * zoom
		var sp    = (world - cam + half_vp) * zoom
		sp.y -= lift

		if sp.x < -120 * zoom or sp.x > vpw + 120 * zoom: continue
		if sp.y < -120 * zoom or sp.y > vph + 120 * zoom: continue

		for blade in blades:
			var rx = sp.x + blade["u"] * tw_half * zoom
			var ry = sp.y + blade["v"] * th_half * zoom
			var bh = (3.5 + blade["height"] * 7.0) * zoom
			var bw = (0.8 + blade["width"]  * 1.2) * zoom

			var sway     = _blade_sway(blade, t)
			var tip_sway = (sway * wind_strength + blade["lean"] * 1.2) * zoom

			# Shadow
			canvas.draw_line(
				Vector2(rx + 1.5 * zoom, ry + 1.0 * zoom),
				Vector2(rx + tip_sway * 0.7 + 1.5 * zoom, ry - bh * 0.68 + 1.0 * zoom),
				SHADOW_COL, bw * 0.65
			)

			# 4-segment blade
			var prev = Vector2(rx, ry)
			for s in range(4):
				var frac     = float(s + 1) / 4.0
				var seg_sway = tip_sway * frac * frac
				var col      = COLORS[clamp(blade["shade"] + s, 0, 4)]
				var nx       = rx + seg_sway
				var ny       = ry - bh * frac
				canvas.draw_line(prev, Vector2(nx, ny), col, bw * (1.0 - frac * 0.25))
				prev = Vector2(nx, ny)

			canvas.draw_circle(prev, bw * 0.45, C4)
