class_name UnitPicker
extends Control

# =============================================================
# UNIT PICKER
# Shown when right-clicking a tile with multiple units.
# Renders a compact dropdown list of units on that tile.
# Emits unit_selected(unit_id) when the player clicks one.
# Auto-selects and skips display if only one unit on tile.
# =============================================================

signal unit_selected(unit_id: int)

const BG_COLOR      = Color(0.08, 0.08, 0.12, 0.95)
const BORDER_COLOR  = Color(0.4, 0.4, 0.6, 1.0)
const HOVER_COLOR   = Color(0.2, 0.3, 0.5, 0.9)
const TEXT_COLOR    = Color(0.9, 0.9, 0.9, 1.0)
const HEADER_COLOR  = Color(0.6, 0.7, 0.9, 1.0)
const ROW_HEIGHT    = 32
const PANEL_WIDTH   = 200
const PADDING       = 8

var _units: Array = []       # [{unit_id, label, type}]
var _hovered_idx: int = -1
var _panel: PanelContainer
var _vbox: VBoxContainer


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_STOP
	visible = false
	_build_panel()


func _build_panel() -> void:
	_panel = PanelContainer.new()
	_panel.size = Vector2(PANEL_WIDTH, 0)

	var style = StyleBoxFlat.new()
	style.bg_color          = BG_COLOR
	style.border_color      = BORDER_COLOR
	style.set_border_width_all(1)
	style.set_corner_radius_all(4)
	style.content_margin_left   = PADDING
	style.content_margin_right  = PADDING
	style.content_margin_top    = PADDING / 2
	style.content_margin_bottom = PADDING / 2
	_panel.add_theme_stylebox_override("panel", style)

	_vbox = VBoxContainer.new()
	_vbox.add_theme_constant_override("separation", 2)
	_panel.add_child(_vbox)
	add_child(_panel)


# Show picker at screen position with given units list.
# units_data = [{unit_id, label, type, status}]
func show_at(screen_pos: Vector2, units_data: Array) -> void:
	_units = units_data

	# Clear old buttons
	for child in _vbox.get_children():
		child.queue_free()

	# Header
	var header = Label.new()
	header.text = "Units (%d)" % _units.size()
	header.add_theme_color_override("font_color", HEADER_COLOR)
	header.add_theme_font_size_override("font_size", 11)
	_vbox.add_child(header)

	var sep = HSeparator.new()
	_vbox.add_child(sep)

	# One button per unit
	for i in range(_units.size()):
		var data = _units[i]
		var btn  = Button.new()
		btn.text              = data["label"]
		btn.flat              = true
		btn.alignment         = HORIZONTAL_ALIGNMENT_LEFT
		btn.custom_minimum_size = Vector2(PANEL_WIDTH - PADDING * 2, ROW_HEIGHT)
		btn.add_theme_color_override("font_color", TEXT_COLOR)
		btn.add_theme_font_size_override("font_size", 13)

		var uid = data["unit_id"]
		btn.pressed.connect(func(): _on_unit_pressed(uid))
		_vbox.add_child(btn)

	# Position — nudge away from screen edges
	var viewport_size = get_viewport_rect().size
	var panel_h       = PADDING + (ROW_HEIGHT + 2) * _units.size() + 40
	var pos           = screen_pos
	if pos.x + PANEL_WIDTH > viewport_size.x:
		pos.x = viewport_size.x - PANEL_WIDTH - 4
	if pos.y + panel_h > viewport_size.y:
		pos.y = screen_pos.y - panel_h

	_panel.position = pos
	visible = true


func hide_picker() -> void:
	visible = false
	_units  = []


func _on_unit_pressed(unit_id: int) -> void:
	hide_picker()
	emit_signal("unit_selected", unit_id)


# Clicking outside dismisses
func _unhandled_input(event: InputEvent) -> void:
	if not visible:
		return
	if event is InputEventMouseButton and event.pressed:
		if not _panel.get_global_rect().has_point(event.position):
			hide_picker()
			get_viewport().set_input_as_handled()
