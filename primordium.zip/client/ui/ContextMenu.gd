class_name ContextMenu
extends Node

# =============================================================
# CONTEXT MENU — uses a separate AcceptDialog for text input
# =============================================================

signal action_chosen(action_id: String, text_input: String)

const PANEL_WIDTH := 220
const BTN_HEIGHT  := 34
const PADDING     := 8
const BG_COLOR     := Color(0.08, 0.08, 0.12, 0.95)
const BORDER_COLOR := Color(0.4,  0.6,  0.4,  1.0)
const CATEGORY_COLORS := {
	"move":    Color(0.7,  0.85, 1.0),
	"build":   Color(0.85, 0.75, 0.5),
	"special": Color(0.8,  0.7,  1.0),
	"combat":  Color(1.0,  0.6,  0.6),
}

var _pending_id: String = ""
var _btn_data:   Array  = []

# The floating panel (plain Control, not PanelContainer so we control everything)
var _panel:       Control
var _bg:          ColorRect
var _root_vbox:   VBoxContainer
var _action_vbox: VBoxContainer

# Separate name-input dialog
var _name_dialog:  AcceptDialog
var _name_field:   LineEdit

var visible: bool:
	get: return _panel.visible if _panel else false


func _ready() -> void:
	_build_panel()
	_build_dialog()


func _build_panel() -> void:
	_panel = Control.new()
	_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_panel.visible = false
	add_child(_panel)

	_bg = ColorRect.new()
	_bg.color = BG_COLOR
	_bg.mouse_filter = Control.MOUSE_FILTER_STOP
	_panel.add_child(_bg)

	_root_vbox = VBoxContainer.new()
	_root_vbox.add_theme_constant_override("separation", 2)
	_root_vbox.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_panel.add_child(_root_vbox)

	_action_vbox = VBoxContainer.new()
	_action_vbox.add_theme_constant_override("separation", 2)
	_action_vbox.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_root_vbox.add_child(_action_vbox)


func _build_dialog() -> void:
	_name_dialog = AcceptDialog.new()
	_name_dialog.title           = "Found City"
	_name_dialog.ok_button_text  = "Found City"
	_name_dialog.confirmed.connect(_on_dialog_confirmed)
	_name_dialog.canceled.connect(_on_dialog_canceled)
	add_child(_name_dialog)

	_name_field = LineEdit.new()
	_name_field.placeholder_text    = "Enter city name..."
	_name_field.custom_minimum_size = Vector2(200, 0)
	_name_field.text_submitted.connect(_on_name_submitted)
	_name_dialog.add_child(_name_field)


func show_at(screen_pos: Vector2, actions: Array,
		_tile_x: int, _tile_y: int) -> void:
	_pending_id = ""
	_btn_data   = []

	for c in _action_vbox.get_children():
		c.queue_free()

	var cats: Dictionary = {}
	for a in actions:
		var c = a.get("category", "move")
		if not cats.has(c): cats[c] = []
		cats[c].append(a)

	var content_width  = PADDING * 2
	var content_height = PADDING

	var first = true
	for cat in ["move", "build", "special", "combat"]:
		if not cats.has(cat): continue
		if not first:
			var sep = HSeparator.new()
			_action_vbox.add_child(sep)
			content_height += 6
		first = false

		var hdr = Label.new()
		hdr.text = cat.capitalize()
		hdr.add_theme_color_override("font_color",
			CATEGORY_COLORS.get(cat, Color(0.6, 0.8, 0.6)))
		hdr.add_theme_font_size_override("font_size", 10)
		_action_vbox.add_child(hdr)
		content_height += 16

		for action in cats[cat]:
			var btn = Button.new()
			btn.text = action.get("label", action["id"])
			btn.flat = false
			btn.alignment = HORIZONTAL_ALIGNMENT_LEFT
			btn.custom_minimum_size = Vector2(PANEL_WIDTH - PADDING * 2, BTN_HEIGHT)
			btn.add_theme_color_override("font_color",
				CATEGORY_COLORS.get(action.get("category", "move"), Color.WHITE))
			btn.add_theme_font_size_override("font_size", 13)
			var idx = _btn_data.size()
			_btn_data.append({
				"id":          action["id"],
				"needs_input": action.get("needs_input", false),
				"prompt":      action.get("input_prompt", "City name"),
			})
			btn.pressed.connect(_on_btn_pressed.bind(idx))
			_action_vbox.add_child(btn)
			content_height += BTN_HEIGHT + 2

	content_height += PADDING
	var w = PANEL_WIDTH
	var h = content_height

	var vp  = get_viewport().get_visible_rect().size
	var pos = screen_pos
	if pos.x + w > vp.x: pos.x = vp.x - w - 4
	if pos.y + h > vp.y: pos.y = pos.y - h
	pos.x = max(0, pos.x)
	pos.y = max(0, pos.y)

	_bg.position          = pos
	_bg.size              = Vector2(w, h)
	_root_vbox.position   = pos + Vector2(PADDING, PADDING / 2)
	_root_vbox.size       = Vector2(w - PADDING * 2, h - PADDING)

	_panel.visible = true


func _on_btn_pressed(idx: int) -> void:
	if idx < 0 or idx >= _btn_data.size(): return
	var d = _btn_data[idx]
	print("Menu btn: ", d["id"], " needs_input=", d["needs_input"])
	hide_menu()
	if d["needs_input"]:
		_pending_id       = d["id"]
		_name_field.text  = ""
		_name_field.placeholder_text = d["prompt"]
		_name_dialog.popup_centered()
		_name_field.grab_focus()
	else:
		_fire(d["id"], "")


func _on_dialog_confirmed() -> void:
	var t = _name_field.text.strip_edges()
	if t == "": t = "New Village"
	print("Dialog confirmed: '", t, "'")
	_fire(_pending_id, t)
	_pending_id = ""


func _on_dialog_canceled() -> void:
	_pending_id = ""


func _on_name_submitted(txt: String) -> void:
	var t = txt.strip_edges()
	if t == "": t = "New Village"
	_name_dialog.hide()
	_fire(_pending_id, t)
	_pending_id = ""


func _fire(action_id: String, text: String) -> void:
	print("ContextMenu FIRE: ", action_id, " -> '", text, "'")
	emit_signal("action_chosen", action_id, text)


func hide_menu() -> void:
	_panel.visible = false
	_pending_id    = ""


func _input(event: InputEvent) -> void:
	if not _panel.visible: return
	if event is InputEventMouseButton and event.pressed:
		var mpos = event.position
		var rect = Rect2(_bg.position, _bg.size)
		if not rect.has_point(mpos):
			hide_menu()
