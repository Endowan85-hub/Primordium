class_name VillageView
extends Control

# =============================================================
# VILLAGE VIEW  —  fullscreen overlay for the village interior
# Layout: [Left: pop panel] [Center: grid] [Right: build palette]
#         [Top: resource bar + name + exit button]
# =============================================================

signal closed()
signal build_requested(city_id: int, building_type: int, gx: int, gy: int)
signal role_changed(city_id: int, role: String, delta: int)

var _city_id:   int        = -1
var _city_data: Dictionary = {}

var _grid:      VillageGrid
var _villagers: Array = []

# Top bar
var _name_label:  Label
var _food_label:  Label
var _wood_label:  Label
var _stone_label: Label
var _water_label: Label

# Left panel
var _pop_label:   Label
var _idle_label:  Label
var _role_rows:   Dictionary = {}   # role -> {label, minus, plus}

# Right panel
var _sel_building:  int  = 0
var _build_buttons: Dictionary = {}
var _info_label:    Label
var _placing:       bool = false


func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP

	var bg = ColorRect.new()
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	bg.color = Color(0.08, 0.10, 0.08, 0.97)
	add_child(bg)

	_build_top_bar()
	_build_main_area()
	set_process(true)
	hide()


func _process(delta: float) -> void:
	for v in _villagers:
		v.update(delta, _grid._grid)
	if not _villagers.is_empty():
		_grid.queue_redraw()


# ── PUBLIC ────────────────────────────────────────────────────

func open_village(city_id: int, city_data: Dictionary) -> void:
	_city_id   = city_id
	_city_data = city_data
	_refresh()
	show()


func update_city_data(city_data: Dictionary) -> void:
	_city_data = city_data
	_refresh()


# ── TOP BAR ───────────────────────────────────────────────────

func _build_top_bar() -> void:
	var bar   = PanelContainer.new()
	bar.set_anchors_and_offsets_preset(Control.PRESET_TOP_WIDE)
	bar.custom_minimum_size = Vector2(0, 44)
	var sty   = StyleBoxFlat.new()
	sty.bg_color = Color(0.10, 0.12, 0.10, 0.95)
	bar.add_theme_stylebox_override("panel", sty)
	add_child(bar)

	var hb = HBoxContainer.new()
	hb.add_theme_constant_override("separation", 16)
	bar.add_child(hb)

	var exit_btn = Button.new()
	exit_btn.text = "◀  Exit Village"
	exit_btn.custom_minimum_size = Vector2(130, 0)
	exit_btn.pressed.connect(_on_exit)
	hb.add_child(exit_btn)

	_name_label = Label.new()
	_name_label.text = "Village"
	_name_label.add_theme_color_override("font_color", Color(0.95, 0.85, 0.5))
	_name_label.add_theme_font_size_override("font_size", 16)
	hb.add_child(_name_label)

	var sp1 = Control.new()
	sp1.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	hb.add_child(sp1)

	_food_label  = _res_label("🌾 --")
	_wood_label  = _res_label("🪵 --")
	_stone_label = _res_label("🪨 --")
	_water_label = _res_label("💧 --")
	for l in [_food_label, _wood_label, _stone_label, _water_label]:
		hb.add_child(l)

	var sp2 = Control.new()
	sp2.custom_minimum_size = Vector2(12, 0)
	hb.add_child(sp2)


func _res_label(t: String) -> Label:
	var l = Label.new()
	l.text = t
	l.add_theme_color_override("font_color", Color(0.9, 0.9, 0.8))
	l.add_theme_font_size_override("font_size", 14)
	l.custom_minimum_size = Vector2(80, 0)
	return l


# ── MAIN AREA ─────────────────────────────────────────────────

func _build_main_area() -> void:
	var hb = HBoxContainer.new()
	hb.set_anchors_preset(Control.PRESET_FULL_RECT)
	hb.offset_top = 44
	hb.add_theme_constant_override("separation", 0)
	add_child(hb)

	hb.add_child(_make_left_panel())

	var center = CenterContainer.new()
	center.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	center.size_flags_vertical   = Control.SIZE_EXPAND_FILL

	_grid = VillageGrid.new()
	_grid.cell_clicked.connect(_on_cell_clicked)
	_grid.cell_hovered.connect(_on_cell_hovered)
	center.add_child(_grid)
	hb.add_child(center)

	hb.add_child(_make_right_panel())


func _make_left_panel() -> Control:
	var panel = PanelContainer.new()
	panel.custom_minimum_size = Vector2(200, 0)
	var sty = StyleBoxFlat.new()
	sty.bg_color = Color(0.08, 0.11, 0.08, 0.90)
	sty.border_width_right = 1
	sty.border_color = Color(0.2, 0.25, 0.2)
	panel.add_theme_stylebox_override("panel", sty)

	var vb = VBoxContainer.new()
	vb.add_theme_constant_override("separation", 6)
	panel.add_child(vb)

	var hdr = Label.new()
	hdr.text = "POPULATION"
	hdr.add_theme_color_override("font_color", Color(0.7, 0.9, 0.6))
	hdr.add_theme_font_size_override("font_size", 13)
	vb.add_child(hdr)
	vb.add_child(HSeparator.new())

	_pop_label  = _info_lbl("Total: 0 / 0")
	_idle_label = _info_lbl("Idle: 0")
	vb.add_child(_pop_label)
	vb.add_child(_idle_label)
	vb.add_child(HSeparator.new())

	var roles = ["farmers","hunters","woodcutters","miners",
				 "builders","researchers","healers","traders","soldiers"]
	for r in roles:
		vb.add_child(_make_role_row(r))

	var sp = Control.new()
	sp.size_flags_vertical = Control.SIZE_EXPAND_FILL
	vb.add_child(sp)
	return panel


func _make_role_row(role: String) -> HBoxContainer:
	var hb = HBoxContainer.new()
	hb.add_theme_constant_override("separation", 4)

	var lbl = Label.new()
	lbl.text = role.capitalize() + ": 0"
	lbl.custom_minimum_size = Vector2(110, 0)
	lbl.add_theme_font_size_override("font_size", 12)
	hb.add_child(lbl)

	var minus = Button.new()
	minus.text = "-"
	minus.custom_minimum_size = Vector2(24, 24)
	minus.pressed.connect(_on_role_delta.bind(role, -1))
	hb.add_child(minus)

	var plus = Button.new()
	plus.text = "+"
	plus.custom_minimum_size = Vector2(24, 24)
	plus.pressed.connect(_on_role_delta.bind(role, 1))
	hb.add_child(plus)

	_role_rows[role] = {"label": lbl, "minus": minus, "plus": plus}
	return hb


func _make_right_panel() -> Control:
	var panel = PanelContainer.new()
	panel.custom_minimum_size = Vector2(200, 0)
	var sty = StyleBoxFlat.new()
	sty.bg_color = Color(0.08, 0.10, 0.11, 0.90)
	sty.border_width_left = 1
	sty.border_color = Color(0.2, 0.22, 0.25)
	panel.add_theme_stylebox_override("panel", sty)

	var vb = VBoxContainer.new()
	vb.add_theme_constant_override("separation", 6)
	panel.add_child(vb)

	var hdr = Label.new()
	hdr.text = "BUILD"
	hdr.add_theme_color_override("font_color", Color(0.6, 0.8, 0.9))
	hdr.add_theme_font_size_override("font_size", 13)
	vb.add_child(hdr)
	vb.add_child(HSeparator.new())

	for bt in [2, 3, 4, 5, 6]:   # Hut, Farm, Well, Road, Storehouse
		var btn = _make_build_btn(bt)
		vb.add_child(btn)
		_build_buttons[bt] = btn

	vb.add_child(HSeparator.new())

	_info_label = Label.new()
	_info_label.text = "Select a building\nto see details."
	_info_label.add_theme_color_override("font_color", Color(0.75, 0.8, 0.75))
	_info_label.add_theme_font_size_override("font_size", 12)
	_info_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	vb.add_child(_info_label)

	var cancel = Button.new()
	cancel.text = "Cancel (Esc)"
	cancel.pressed.connect(_cancel_build)
	vb.add_child(cancel)

	var sp = Control.new()
	sp.size_flags_vertical = Control.SIZE_EXPAND_FILL
	vb.add_child(sp)
	return panel


func _make_build_btn(bt: int) -> Button:
	var n    = VillageConstants.BUILDING_NAMES.get(bt, "?")
	var cost = VillageConstants.BUILDING_COSTS.get(bt, {})
	var cs   = ""
	if cost.get("wood",  0) > 0: cs += "🪵%d " % cost["wood"]
	if cost.get("stone", 0) > 0: cs += "🪨%d"  % cost["stone"]
	if cs.is_empty():            cs  = "Free"

	var btn = Button.new()
	btn.text = n + "  " + cs
	btn.toggle_mode = true
	btn.custom_minimum_size = Vector2(0, 32)
	btn.pressed.connect(_on_build_btn.bind(bt))
	return btn


# ── REFRESH ───────────────────────────────────────────────────

func _refresh() -> void:
	if _city_data.is_empty():
		return

	_name_label.text  = _city_data.get("name", "Village")
	_food_label.text  = "🌾 %d" % int(_city_data.get("food",  0.0))
	_wood_label.text  = "🪵 %d" % int(_city_data.get("wood",  0.0))
	_stone_label.text = "🪨 %d" % int(_city_data.get("stone", 0.0))
	_water_label.text = "💧 %d" % int(_city_data.get("water", 0.0))

	var pop     = int(_city_data.get("population", 0))
	var pop_cap = int(_city_data.get("pop_cap",    0))
	_pop_label.text  = "Total: %d / %d" % [pop, pop_cap]
	_idle_label.text = "Idle: %d" % int(_city_data.get("idle", 0))

	for role in _role_rows:
		var cnt = _city_data.get(role, 0)
		_role_rows[role]["label"].text = role.capitalize() + ": " + str(cnt)

	_grid.load_grid(_city_data.get("village_grid", []))
	_sync_villagers()


func _sync_villagers() -> void:
	var pop   = int(_city_data.get("population", 0))
	var roles = ["farmers","hunters","woodcutters","miners",
				 "builders","researchers","healers","traders","soldiers","idle"]

	var role_list: Array = []
	for r in roles:
		for i in range(_city_data.get(r, 0)):
			role_list.append(r)
	while role_list.size() < pop:
		role_list.append("idle")

	while _villagers.size() < pop:
		var v = VillageVillager.new()
		v.villager_id = _villagers.size()
		v.pos = Vector2(4.5 + randf() * 1.5, 4.5 + randf() * 1.5)
		_villagers.append(v)
	while _villagers.size() > pop:
		_villagers.pop_back()

	for i in range(_villagers.size()):
		_villagers[i].role = role_list[i] if i < role_list.size() else "idle"


# ── HANDLERS ──────────────────────────────────────────────────

func _on_exit() -> void:
	_cancel_build()
	hide()
	emit_signal("closed")


func _on_build_btn(bt: int) -> void:
	for b in _build_buttons:
		if b != bt:
			_build_buttons[b].button_pressed = false

	if _sel_building == bt:
		_sel_building = 0
		_placing = false
		_grid.clear_ghost()
		_set_info(0)
		return

	_sel_building = bt
	_placing = true
	_grid.set_ghost(bt)
	_set_info(bt)


func _cancel_build() -> void:
	_sel_building = 0
	_placing = false
	_grid.clear_ghost()
	for b in _build_buttons:
		_build_buttons[b].button_pressed = false
	_set_info(0)


func _on_cell_clicked(gx: int, gy: int) -> void:
	if not _placing or _sel_building == 0:
		return
	if not _grid.is_placement_valid(gx, gy, _sel_building):
		return
	emit_signal("build_requested", _city_id, _sel_building, gx, gy)
	_cancel_build()


func _on_cell_hovered(_gx: int, _gy: int) -> void:
	pass


func _on_role_delta(role: String, delta: int) -> void:
	emit_signal("role_changed", _city_id, role, delta)


func _set_info(bt: int) -> void:
	if bt == 0:
		_info_label.text = "Select a building\nto see details."
		return
	var n    = VillageConstants.BUILDING_NAMES.get(bt, "?")
	var cost = VillageConstants.BUILDING_COSTS.get(bt, {})
	var sz   = VillageConstants.BUILDING_SIZE.get(bt, [1, 1])
	var tks  = VillageConstants.BUILDING_BUILD_TICKS.get(bt, 0)
	var txt  = "%s\nSize: %dx%d\n" % [n, sz[0], sz[1]]
	if cost.get("wood",  0) > 0: txt += "🪵 Wood: %d\n"  % cost["wood"]
	if cost.get("stone", 0) > 0: txt += "🪨 Stone: %d\n" % cost["stone"]
	if tks > 0: txt += "Build: %d ticks (needs Builder)\n" % tks
	var pc = VillageConstants.BUILDING_POP_CAP.get(bt, 0)
	if pc > 0: txt += "+%d pop cap\n" % pc
	_info_label.text = txt.strip_edges()


func _info_lbl(t: String) -> Label:
	var l = Label.new()
	l.text = t
	l.add_theme_font_size_override("font_size", 12)
	l.add_theme_color_override("font_color", Color(0.85, 0.85, 0.85))
	return l


func _input(event: InputEvent) -> void:
	if not visible:
		return
	if event is InputEventKey and event.pressed:
		if event.keycode == KEY_ESCAPE:
			if _placing:
				_cancel_build()
			else:
				_on_exit()
