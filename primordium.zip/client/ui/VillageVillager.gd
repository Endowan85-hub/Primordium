class_name VillageVillager
extends RefCounted

# =============================================================
# VILLAGE VILLAGER  —  client-side walking dot, purely visual
# =============================================================

const CELL_SIZE:  float = 48.0
const WALK_SPEED: float = 1.8    # grid cells per second
const DOT_RADIUS: float = 5.0

var role:        String  = "idle"
var villager_id: int     = 0
var pos:         Vector2 = Vector2(5.0, 5.0)

var _path:       Array   = []
var _wait_timer: float   = 0.0

const ROLE_COLORS: Dictionary = {
	"farmers":     Color(0.4,  0.85, 0.3),
	"hunters":     Color(0.7,  0.5,  0.2),
	"woodcutters": Color(0.55, 0.35, 0.15),
	"miners":      Color(0.6,  0.6,  0.6),
	"builders":    Color(0.85, 0.7,  0.2),
	"researchers": Color(0.3,  0.7,  0.9),
	"healers":     Color(0.9,  0.3,  0.5),
	"traders":     Color(0.9,  0.8,  0.2),
	"soldiers":    Color(0.8,  0.2,  0.2),
	"idle":        Color(0.7,  0.7,  0.7),
}


func update(delta: float, grid: Dictionary) -> void:
	if _wait_timer > 0.0:
		_wait_timer -= delta
		if _wait_timer <= 0.0:
			_pick_target(grid)
		return

	if _path.is_empty():
		_pick_target(grid)
		return

	var target_cell = _path[0]
	var target_pos  = Vector2(target_cell.x + 0.5, target_cell.y + 0.5)
	var diff        = target_pos - pos
	var dist        = diff.length()
	var step        = WALK_SPEED * delta

	if step >= dist:
		pos = target_pos
		_path.remove_at(0)
		if _path.is_empty():
			_wait_timer = 0.5 + randf() * 1.5
	else:
		pos += diff.normalized() * step


func _pick_target(grid: Dictionary) -> void:
	var candidates: Array = []

	if role == "builders":
		for key in grid:
			var cell = grid[key]
			if cell.get("state", "") == "building" and cell.get("is_origin", false):
				var parts = key.split(",")
				candidates.append(Vector2i(int(parts[0]), int(parts[1])))
	elif role == "farmers":
		for key in grid:
			var cell = grid[key]
			if cell.get("type", 0) == 3 and cell.get("is_origin", false):
				var parts = key.split(",")
				candidates.append(Vector2i(int(parts[0]), int(parts[1])))
	else:
		# Wander near center
		candidates.append(Vector2i(
			4 + randi() % 3 - 1,
			4 + randi() % 3 - 1
		))

	if candidates.is_empty():
		_wait_timer = 1.0 + randf() * 2.0
		return

	_path = [candidates[randi() % candidates.size()]]


func draw_on(canvas: CanvasItem, grid_origin: Vector2) -> void:
	var sp  = grid_origin + pos * CELL_SIZE
	var col = ROLE_COLORS.get(role, Color.WHITE)
	canvas.draw_circle(sp + Vector2(1, 2), DOT_RADIUS * 0.7, Color(0, 0, 0, 0.3))
	canvas.draw_circle(sp, DOT_RADIUS, col)
	canvas.draw_arc(sp, DOT_RADIUS, 0, TAU, 8, col.darkened(0.4), 1.0)
	canvas.draw_circle(sp, DOT_RADIUS * 0.35, Color(1, 1, 1, 0.7))
