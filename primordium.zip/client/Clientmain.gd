class_name ClientMain
extends Node2D

# =============================================================
# CLIENT MAIN
# Entry point for the game client.
# Holds all local game state received from the server.
# Connects network signals to UI and renderer.
# Never simulates - only displays and sends input.
# =============================================================


# -------------------------------------------------------------
# LOCAL STATE
# Mirror of server state for this player only
# -------------------------------------------------------------
var player_id: int       = -1
var player_name: String  = "Player"
var player_data: Dictionary = {}

var current_tick: int    = 0
var current_day: int     = 0
var current_season: String = "spring"
var current_year: int    = 1

var my_cities: Dictionary  = {}   # city_id -> city data
var my_units: Dictionary   = {}   # unit_id -> unit data
var visible_tiles: Dictionary = {} # "x,y" -> tile data
var active_events: Array   = []

# Other players' visible data
var other_cities: Dictionary = {}  # city_id -> public city data
var other_units: Dictionary  = {}  # unit_id -> public unit data

# Selected unit/city for UI
var selected_unit_id: int  = -1
var selected_city_id: int  = -1

# Tracks all unit_ids known to be on each tile key "x,y"
var units_by_tile: Dictionary = {}


# -------------------------------------------------------------
# CHILD NODES (instantiated in _ready)
# -------------------------------------------------------------
var network: NetworkClient
var iso_map: IsometricMap
var hud: GameHUD
var dev_console: DevConsole
var unit_picker: UnitPicker
var context_menu: ContextMenu
var village_view: VillageView
var _context_city_id: int = -1

# Pending context state: waiting for server action list
var _context_unit_id: int  = -1
var _context_tile_x:  int  = -1
var _context_tile_y:  int  = -1
var _context_screen:  Vector2 = Vector2.ZERO

# Block tile clicks briefly after a context menu action fires
# to prevent click-through onto the tile under the menu button
var _action_cooldown: float = 0.0
const ACTION_COOLDOWN_SEC: float = 0.15


# -------------------------------------------------------------
# READY
# -------------------------------------------------------------
func _ready() -> void:
	_setup_network()
	_setup_renderer()
	_setup_hud()

	if GameConstants.DEV_MODE:
		_setup_dev_console()
	_setup_context_ui()

	# Auto connect in dev mode to local server
	if GameConstants.DEV_MODE:
		player_name = "DevPlayer"
		network.connect_to_server("ws://localhost:" + str(GameConstants.SERVER_PORT), player_name)


# -------------------------------------------------------------
# SETUP
# -------------------------------------------------------------
func _setup_network() -> void:
	network = NetworkClient.new()
	network.name = "NetworkClient"
	add_child(network)

	network.connected_to_server.connect(_on_connected)
	network.disconnected_from_server.connect(_on_disconnected)
	network.handshake_complete.connect(_on_handshake_complete)
	network.init_received.connect(_on_init_received)
	network.tick_received.connect(_on_tick_received)
	network.day_changed.connect(_on_day_changed)
	network.season_changed.connect(_on_season_changed)
	network.city_updated.connect(_on_city_updated)
	network.unit_updated.connect(_on_unit_updated)
	network.unit_removed.connect(_on_unit_removed)
	network.tile_chunk_received.connect(_on_tile_chunk_received)
	network.tile_updated.connect(_on_tile_updated)
	network.event_received.connect(_on_event_received)
	network.actions_received.connect(_on_actions_received)


func _setup_renderer() -> void:
	iso_map = IsometricMap.new()
	iso_map.name = "IsometricMap"
	add_child(iso_map)
	iso_map.tile_clicked.connect(_on_tile_clicked)
	iso_map.tile_right_clicked.connect(_on_tile_right_clicked)
	iso_map.unit_clicked.connect(_on_unit_clicked)
	iso_map.unit_right_clicked.connect(_on_unit_right_clicked)
	iso_map.city_right_clicked.connect(_on_city_right_clicked)


func _setup_hud() -> void:
	hud = GameHUD.new()
	hud.name = "GameHUD"
	add_child(hud)

	hud.found_city_requested.connect(_on_found_city_requested)
	hud.assign_workers_requested.connect(_on_assign_workers_requested)
	hud.move_unit_requested.connect(_on_move_unit_requested)
	hud.event_choice_made.connect(_on_event_choice_made)
	hud.dev_command.connect(_on_dev_command)


func _setup_dev_console() -> void:
	dev_console = DevConsole.new()
	dev_console.name = "DevConsole"
	add_child(dev_console)
	dev_console.command_entered.connect(_on_dev_command)


func _process(delta: float) -> void:
	if _action_cooldown > 0.0:
		_action_cooldown -= delta


func _setup_context_ui() -> void:
	unit_picker = UnitPicker.new()
	unit_picker.name = "UnitPicker"
	unit_picker.z_index = 10
	add_child(unit_picker)
	unit_picker.unit_selected.connect(_on_unit_picker_selected)

	# ContextMenu extends Node (not CanvasItem), so z_index is not valid on it.
	# The inner _panel Control handles its own rendering order.
	context_menu = ContextMenu.new()
	context_menu.name = "ContextMenu"
	add_child(context_menu)
	context_menu.action_chosen.connect(_on_context_action_chosen)

	# Village interior view
	village_view = VillageView.new()
	village_view.name = "VillageView"
	village_view.z_index = 20
	add_child(village_view)
	village_view.closed.connect(_on_village_view_closed)
	village_view.build_requested.connect(_on_village_build_requested)
	village_view.role_changed.connect(_on_village_role_changed)


# -------------------------------------------------------------
# INPUT
# -------------------------------------------------------------
func _input(event: InputEvent) -> void:
	# Toggle dev console with backtick
	if GameConstants.DEV_MODE and event is InputEventKey:
		if event.pressed and event.keycode == KEY_QUOTELEFT:
			if dev_console:
				dev_console.toggle()

	# ESC closes menus or deselects
	if event is InputEventKey and event.pressed and event.keycode == KEY_ESCAPE:
		if context_menu and context_menu.visible:
			context_menu.hide_menu()
			return
		if unit_picker and unit_picker.visible:
			unit_picker.hide_picker()
			return
		_deselect_all()


func _deselect_all() -> void:
	selected_unit_id = -1
	selected_city_id = -1
	iso_map.set_selected_unit(-1)
	if hud:
		hud._unit_panel.visible = false
		hud._city_panel.visible = false
		hud._tile_panel.visible = false


# -------------------------------------------------------------
# NETWORK SIGNAL HANDLERS
# -------------------------------------------------------------
func _on_connected() -> void:
	print("Connected to server.")
	if hud:
		hud.show_status("Connected")


func _on_disconnected() -> void:
	print("Disconnected from server.")
	if hud:
		hud.show_status("Disconnected - reconnecting...")


func _on_handshake_complete(pid: int) -> void:
	player_id = pid
	print("Playing as ID: ", player_id)


func _on_init_received(data: Dictionary) -> void:
	player_data    = data.get("player", {})
	current_tick   = data.get("tick",   0)
	current_day    = data.get("day",    0)
	current_season = data.get("season", "spring")
	current_year   = data.get("year",   1)

	if hud:
		hud.update_time(current_day, current_season, current_year, current_tick)
		hud.show_status("Connected")

	print("World initialized. ", data.get("time", ""))


func _on_tick_received(tick: int, day: int, season: String, year: int) -> void:
	current_tick   = tick
	current_day    = day
	current_season = season
	current_year   = year

	# Update clock every tick so time of day advances smoothly
	if hud:
		hud.update_time(current_day, current_season, current_year, current_tick)

	# Update unit travel progress visually each tick
	for unit_id in my_units:
		iso_map.update_unit_position(unit_id, my_units[unit_id])


func _on_day_changed(day: int, season: String, year: int) -> void:
	current_day    = day
	current_season = season
	current_year   = year
	if hud:
		hud.update_time(day, season, year, current_tick)


func _on_season_changed(season: String) -> void:
	current_season = season
	iso_map.update_season(season)


func _on_city_updated(city_id: int, city: Dictionary) -> void:
	my_cities[city_id] = city
	# Keep village view in sync if it's open for this city
	if village_view and village_view.visible and village_view._city_id == city_id:
		village_view.update_city_data(city)
	iso_map.update_city(city_id, city)
	if hud and selected_city_id == city_id:
		hud.update_city_panel(city)


func _on_unit_removed(unit_id: int) -> void:
	my_units.erase(unit_id)
	iso_map.remove_unit(unit_id)
	if selected_unit_id == unit_id:
		_deselect_all()


func _on_unit_updated(unit_id: int, unit: Dictionary) -> void:
	var is_new = not my_units.has(unit_id)
	my_units[unit_id] = unit
	iso_map.update_unit(unit_id, unit)
	if hud and selected_unit_id == unit_id:
		hud.update_unit_panel(unit)
	# Center camera on first unit received
	if is_new and my_units.size() == 1:
		print("Centering camera on starting unit at ", unit.get("x"), ",", unit.get("y"))
		iso_map.center_on_tile(unit.get("x", 100), unit.get("y", 100))


func _on_tile_chunk_received(tiles: Dictionary) -> void:
	for key in tiles:
		visible_tiles[key] = tiles[key]
	iso_map.receive_tile_chunk(tiles)
	print("Tile chunk received: ", tiles.size(), " tiles. Total visible: ", visible_tiles.size())


func _on_tile_updated(x: int, y: int, tile: Dictionary) -> void:
	visible_tiles[str(x) + "," + str(y)] = tile
	iso_map.update_tile(x, y, tile)


func _on_event_received(event: Dictionary) -> void:
	active_events.append(event)
	if hud:
		hud.show_event(event)


# -------------------------------------------------------------
# UI SIGNAL HANDLERS
# -------------------------------------------------------------
func _on_tile_clicked(x: int, y: int) -> void:
	# Block click-through from context menu / confirm button releases
	if _action_cooldown > 0.0:
		return

	# If menus are open, close them and eat the click
	if context_menu and context_menu.visible:
		context_menu.hide_menu()
		return
	if unit_picker and unit_picker.visible:
		unit_picker.hide_picker()
		return

	# Left-click: move selected unit or show tile info
	var key  = str(x) + "," + str(y)
	var tile = visible_tiles.get(key, {})

	if selected_unit_id >= 0 and my_units.has(selected_unit_id):
		network.send_move_unit(selected_unit_id, x, y)
		if hud:
			hud.show_status("Moving...")
		_deselect_all()
		return

	if hud:
		hud.show_tile_info(x, y, tile)


func _on_tile_right_clicked(x: int, y: int) -> void:
	if _action_cooldown > 0.0:
		return
	var screen_pos = get_viewport().get_mouse_position()
	var key        = str(x) + "," + str(y)

	# Close any open menus first
	if context_menu:  context_menu.hide_menu()
	if unit_picker:   unit_picker.hide_picker()

	# Get all units on this tile
	var tile_units = _get_units_on_tile(x, y)

	if selected_unit_id >= 0 and my_units.has(selected_unit_id):
		# Unit already selected — right-clicking opens action menu for that unit
		_request_actions_for_tile(selected_unit_id, x, y, screen_pos)
	elif tile_units.size() == 1:
		# One unit on tile — auto-select it and open its action menu immediately
		var uid = tile_units[0]["unit_id"]
		_select_unit(uid)
		_request_actions_for_tile(uid, x, y, screen_pos)
	elif tile_units.size() > 1:
		# Multiple units — let player pick which one
		unit_picker.show_at(screen_pos, tile_units)
	else:
		# Empty tile right-click — show tile info
		var tile = visible_tiles.get(key, {})
		if hud:
			hud.show_tile_info(x, y, tile)


func _request_actions_for_tile(unit_id: int, tx: int, ty: int, screen_pos: Vector2) -> void:
	_context_unit_id = unit_id
	_context_tile_x  = tx
	_context_tile_y  = ty
	_context_screen  = screen_pos
	network.send_get_actions(unit_id, tx, ty)


func _get_units_on_tile(x: int, y: int) -> Array:
	var result: Array = []
	var key = str(x) + "," + str(y)
	for unit_id in my_units:
		var unit = my_units[unit_id]
		if unit.get("x", -1) == x and unit.get("y", -1) == y:
			var type_str = unit.get("type", "unit")
			result.append({
				"unit_id": unit_id,
				"label":   type_str.capitalize() + " #" + str(unit_id),
				"type":    type_str,
				"status":  unit.get("status", "idle")
			})
	return result


func _on_unit_clicked(unit_id: int) -> void:
	_select_unit(unit_id)


func _on_unit_right_clicked(unit_id: int) -> void:
	# Select the unit then open its action menu on its own tile
	_select_unit(unit_id)
	if my_units.has(unit_id):
		var unit       = my_units[unit_id]
		var screen_pos = get_viewport().get_mouse_position()
		_request_actions_for_tile(unit_id, unit.get("x", 0), unit.get("y", 0), screen_pos)


func _select_unit(unit_id: int) -> void:
	selected_unit_id = unit_id
	selected_city_id = -1
	if context_menu:  context_menu.hide_menu()
	if unit_picker:   unit_picker.hide_picker()
	iso_map.set_selected_unit(unit_id)

	if my_units.has(unit_id):
		var unit = my_units[unit_id]
		if hud:
			hud.show_unit_panel(unit)
			# Settlers no longer show found_city button here —
			# it appears via right-click context menu instead
			hud.show_found_city_button(false)
	elif other_units.has(unit_id):
		if hud:
			hud.show_foreign_unit_info(other_units[unit_id])


func _on_found_city_requested(city_name: String) -> void:
	if selected_unit_id < 0:
		return
	network.send_found_city(selected_unit_id, city_name)
	selected_unit_id = -1
	if hud:
		hud.show_found_city_button(false)


func _on_actions_received(unit_id: int, tile_x: int, tile_y: int, actions: Array) -> void:
	# Ignore if context changed since request was sent
	if unit_id != _context_unit_id:
		return
	if actions.is_empty():
		if hud:
			hud.show_status("No actions available here")
		return
	context_menu.show_at(_context_screen, actions, tile_x, tile_y)


func _on_village_view_closed() -> void:
	iso_map.show()


func _on_village_build_requested(city_id: int, building_type: int, gx: int, gy: int) -> void:
	network.send_village_build(city_id, building_type, gx, gy)


func _on_village_role_changed(city_id: int, role: String, delta: int) -> void:
	network.send_village_role(city_id, role, delta)


func _on_city_right_clicked(city_id: int) -> void:
	_context_city_id = city_id
	var screen_pos   = get_viewport().get_mouse_position()
	if context_menu:
		context_menu.show_at(screen_pos, [
			{"id": "view_village", "label": "View Village"}
		], -1, -1)


func _on_context_action_chosen(action_id: String, text_input: String) -> void:
	# Village view action
	if action_id == "view_village":
		var city_id = _context_city_id
		if city_id >= 0 and my_cities.has(city_id):
			village_view.open_village(city_id, my_cities[city_id])
			iso_map.hide()
		return

	if _context_unit_id < 0:
		return

	# Block tile-click click-through — set cooldown before any signals fire
	_action_cooldown = ACTION_COOLDOWN_SEC

	network.send_do_action(action_id, _context_unit_id,
		_context_tile_x, _context_tile_y, text_input)
	if hud:
		hud.show_status(ActionRegistry.get_label(action_id) + "...")
	# Deselect after giving an order so map feels clean
	selected_unit_id = -1
	_context_unit_id = -1
	iso_map.set_selected_unit(-1)


func _on_unit_picker_selected(unit_id: int) -> void:
	_select_unit(unit_id)
	# Show unit panel and status
	if hud and my_units.has(unit_id):
		hud.show_status("Selected: " + my_units[unit_id].get("type", "unit").capitalize())


func _on_assign_workers_requested(city_id: int, farmers: int,
		woodcutters: int, miners: int, researchers: int) -> void:
	network.send_assign_workers(city_id, farmers, woodcutters, miners, researchers)


func _on_move_unit_requested(unit_id: int, tx: int, ty: int) -> void:
	network.send_move_unit(unit_id, tx, ty)


func _on_event_choice_made(event_id: String, choice_index: int) -> void:
	network.send_resolve_event(event_id, choice_index)
	# Remove from local active events
	for i in range(active_events.size()):
		if active_events[i].get("id", "") == event_id:
			active_events.remove_at(i)
			break


# -------------------------------------------------------------
# DEV COMMANDS
# Parses console input like "/timescale 10" or "/give food 500"
# -------------------------------------------------------------
func _on_dev_command(command: String) -> void:
	if not GameConstants.DEV_MODE:
		return

	var parts = command.strip_edges().split(" ")
	if parts.size() == 0:
		return

	match parts[0]:
		"/timescale":
			if parts.size() >= 2:
				var scale = float(parts[1])
				network.dev_set_timescale(scale)
				_log_dev("Timescale -> " + str(scale))

		"/give":
			# /give food 500  or  /give wood 200  or  /give stone 100
			if parts.size() >= 3 and my_cities.size() > 0:
				var city_id = my_cities.keys()[0]
				var amount  = float(parts[2])
				match parts[1]:
					"food":  network.dev_give_resources(city_id, amount, 0, 0)
					"wood":  network.dev_give_resources(city_id, 0, amount, 0)
					"stone": network.dev_give_resources(city_id, 0, 0, amount)
					"all":   network.dev_give_resources(city_id, amount, amount, amount)
				_log_dev("Gave " + parts[1] + " x" + str(amount))

		"/reveal":
			network.dev_reveal_map()
			_log_dev("Map revealed")

		"/day":
			if parts.size() >= 2:
				var day = int(parts[1])
				network.dev_set_day(day)
				_log_dev("Jumped to day " + str(day))

		"/spawn":
			# /spawn settler 10 15
			if parts.size() >= 4:
				var unit_type = parts[1]
				var sx        = int(parts[2])
				var sy        = int(parts[3])
				network.dev_spawn_unit(unit_type, sx, sy)
				_log_dev("Spawned " + unit_type + " at " + str(sx) + "," + str(sy))

		"/help":
			_log_dev("/timescale [n]  - set time speed")
			_log_dev("/give [food|wood|stone|all] [n]  - add resources")
			_log_dev("/reveal  - remove fog of war")
			_log_dev("/day [n]  - jump to day")
			_log_dev("/spawn [type] [x] [y]  - spawn unit")

		_:
			_log_dev("Unknown command. Type /help for list.")


func _log_dev(msg: String) -> void:
	print("[DEV] ", msg)
	if dev_console:
		dev_console.log_line(msg)


# -------------------------------------------------------------
# HELPERS
# -------------------------------------------------------------
func get_selected_unit() -> Dictionary:
	if selected_unit_id >= 0 and my_units.has(selected_unit_id):
		return my_units[selected_unit_id]
	return {}


func get_selected_city() -> Dictionary:
	if selected_city_id >= 0 and my_cities.has(selected_city_id):
		return my_cities[selected_city_id]
	return {}


func get_tile(x: int, y: int) -> Dictionary:
	return visible_tiles.get(str(x) + "," + str(y), {})


func request_visible_tiles(center_x: int, center_y: int, radius: int) -> void:
	var coords: Array = []
	for dy in range(-radius, radius + 1):
		for dx in range(-radius, radius + 1):
			if dx * dx + dy * dy <= radius * radius:
				var tx = center_x + dx
				var ty = center_y + dy
				if tx >= 0 and tx < GameConstants.MAP_WIDTH and \
				   ty >= 0 and ty < GameConstants.MAP_HEIGHT:
					var key = str(tx) + "," + str(ty)
					if not visible_tiles.has(key):
						coords.append(Vector2i(tx, ty))
	if coords.size() > 0:
		network.send_request_tiles(coords)
