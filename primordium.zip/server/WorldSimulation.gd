class_name WorldSimulation
extends Node

# =============================================================
# WORLD SIMULATION
# Server-side tick engine. Drives all game state.
# Never runs on the client.
# =============================================================


# -------------------------------------------------------------
# SIGNALS
# -------------------------------------------------------------
signal tick_completed(tick: int, day: int, season: String, year: int)
signal day_changed(day: int, season: String, year: int)
signal season_changed(season: String)
signal year_changed(year: int)
signal player_event_fired(player_id: int, event: Dictionary)
signal city_updated(player_id: int, city_id: int, city_data: Dictionary)
signal unit_updated(player_id: int, unit_id: int, unit_data: Dictionary)
signal unit_removed(player_id: int, unit_id: int)
signal tile_updated(x: int, y: int, tile_data: Dictionary)


# -------------------------------------------------------------
# STATE
# -------------------------------------------------------------
var world_map: WorldMap

var current_tick: int   = 0
var current_day: int    = 0
var current_season: int = 0   # Index into GameConstants.SEASON_NAMES
var current_year: int   = 1

var _tick_timer: float  = 0.0
var _running: bool      = false

# All players: player_id -> PlayerState dictionary
var players: Dictionary = {}

# All cities: city_id -> CityState dictionary
var cities: Dictionary  = {}

# All units: unit_id -> UnitState dictionary
var units: Dictionary   = {}

var _next_city_id: int  = 0
var _next_unit_id: int  = 0

# Dev timescale multiplier (1.0 = normal)
var dev_timescale: float = 1.0


# -------------------------------------------------------------
# INIT
# -------------------------------------------------------------
func initialize(world_seed: int) -> void:
	world_map = WorldMap.new()
	add_child(world_map)
	world_map.tile_changed.connect(_on_tile_changed)
	world_map.initialize(world_seed)
	_running = true
	print("WorldSimulation initialized. Seed: ", world_seed)


# -------------------------------------------------------------
# PROCESS - drives the tick timer
# -------------------------------------------------------------
func _process(delta: float) -> void:
	if not _running:
		return

	_tick_timer += delta * dev_timescale
	var interval = GameConstants.TICK_INTERVAL_SECONDS

	while _tick_timer >= interval:
		_tick_timer -= interval
		_run_tick()


# -------------------------------------------------------------
# TICK
# -------------------------------------------------------------
func _run_tick() -> void:
	current_tick += 1

	# Advance time
	var prev_day    = current_day
	var prev_season = current_season
	var prev_year   = current_year

	current_day = int(current_tick / GameConstants.TICKS_PER_DAY)
	current_season = int(current_day / GameConstants.DAYS_PER_SEASON) % GameConstants.SEASONS_PER_YEAR
	current_year   = int(current_day / GameConstants.DAYS_PER_YEAR) + 1

	var season_name = GameConstants.SEASON_NAMES[current_season]

	# Tick the world map (resource recovery)
	world_map.tick(season_name)

	# Tick all cities
	for city_id in cities:
		_tick_city(city_id, season_name)

	# Tick all units
	for unit_id in units:
		_tick_unit(unit_id)

	# Tick all players (events, research, etc)
	for player_id in players:
		_tick_player(player_id, season_name)

	# Auto-save periodically
	if current_tick % GameConstants.SAVE_INTERVAL_TICKS == 0:
		save_world()

	# Emit signals for changed time values
	if current_day != prev_day:
		emit_signal("day_changed", current_day, season_name, current_year)
	if current_season != prev_season:
		emit_signal("season_changed", season_name)
	if current_year != prev_year:
		emit_signal("year_changed", current_year)

	emit_signal("tick_completed", current_tick, current_day, season_name, current_year)


# -------------------------------------------------------------
# PLAYER
# -------------------------------------------------------------
func add_player(player_id: int, player_name: String) -> void:
	if players.has(player_id):
		print("Player ", player_id, " already exists.")
		return

	players[player_id] = {
		"id":            player_id,
		"name":          player_name,
		"online":        true,
		"civ_name":      player_name + "'s Civilization",
		"color":         _assign_player_color(player_id),
		"founded":       false,   # Has the player placed their first city yet
		"research":      0.0,
		"research_goal": GameConstants.RESEARCH_BASE_GOAL,
		"unlocked_techs": [],
		"pending_techs":  [],
		"competency": {
			"agricultural": 0.1,
			"engineering":  0.1,
			"military":     0.1,
			"governance":   0.1,
			"spiritual":    0.1,
			"medical":      0.1
		},
		"active_events":    [],
		"event_history":    [],
		"diplomacy":        {},   # player_id -> relation score
		"fog_of_war":       {},   # "x,y" -> true if revealed
		"online_since":     0,
		"last_seen_tick":   current_tick
	}

	# Spawn a settler unit for the new player
	var spawn = world_map.find_spawn_tile(_get_all_city_positions())
	_spawn_unit(player_id, "settler", spawn.x, spawn.y)

	# Reveal tiles around starting position
	_reveal_fog(player_id, spawn.x, spawn.y, GameConstants.VISION_SETTLER)

	print("Player added: ", player_name, " (id:", player_id, ") at ", spawn)


func remove_player(player_id: int) -> void:
	if players.has(player_id):
		players[player_id]["online"] = false
		players[player_id]["last_seen_tick"] = current_tick
		print("Player ", player_id, " went offline.")


func set_player_online(player_id: int, online: bool) -> void:
	if players.has(player_id):
		players[player_id]["online"] = online
		if online:
			players[player_id]["online_since"] = current_tick


func _tick_player(player_id: int, _season: String) -> void:
	var player = players[player_id]

	# Tick research
	var research_rate = _calculate_research_rate(player_id)
	player["research"] += research_rate

	if player["research"] >= player["research_goal"]:
		player["research"] = 0.0
		player["research_goal"] *= GameConstants.RESEARCH_GOAL_SCALING
		_trigger_breakthrough(player_id)

	# Tick events
	_tick_player_events(player_id)

	# Tick competency decay (very slow - keeps values meaningful)
	for comp in player["competency"]:
		player["competency"][comp] = clamp(
			player["competency"][comp] - 0.00001, 0.05, 1.0
		)


func _calculate_research_rate(player_id: int) -> float:
	var rate = 0.0
	for city_id in cities:
		var city = cities[city_id]
		if city["owner"] == player_id:
			rate += city["researchers"] * 0.5
	return rate


func _assign_player_color(player_id: int) -> Color:
	var colors = [
		Color(0.8, 0.2, 0.2),   # Red
		Color(0.2, 0.4, 0.8),   # Blue
		Color(0.2, 0.7, 0.2),   # Green
		Color(0.8, 0.8, 0.2),   # Yellow
		Color(0.7, 0.2, 0.7),   # Purple
		Color(0.2, 0.7, 0.7),   # Cyan
		Color(0.9, 0.5, 0.1),   # Orange
		Color(0.5, 0.3, 0.1),   # Brown
	]
	return colors[player_id % colors.size()]


# -------------------------------------------------------------
# CITY
# -------------------------------------------------------------
func found_city(player_id: int, unit_id: int, city_name: String) -> bool:
	if not players.has(player_id):
		return false
	if not units.has(unit_id):
		return false

	var unit = units[unit_id]
	if unit["type"] != "settler" or unit["owner"] != player_id:
		return false

	var x = unit["x"]
	var y = unit["y"]
	var tile = world_map.get_tile(x, y)

	if tile.is_empty():
		return false

	# Can't found on ocean or mountain
	if tile["type"] == TileTypes.Type.OCEAN or tile["type"] == TileTypes.Type.MOUNTAIN:
		return false

	var city_id = _next_city_id
	_next_city_id += 1

	cities[city_id] = {
		"id":           city_id,
		"owner":        player_id,
		"name":         city_name,
		"x":            x,
		"y":            y,
		"population":   GameConstants.CITY_STARTING_POP,
		"pop_cap":      GameConstants.CITY_STARTING_POP_CAP,
		# Village roles — players assign their population to these
		"farmers":      2,   # Work farmland/grassland for food
		"hunters":      1,   # Hunt/forage for bonus food & hides
		"woodcutters":  1,   # Harvest wood from forest tiles
		"miners":       0,   # Extract stone/ore from hill/mountain tiles
		"builders":     0,   # Construct buildings faster
		"researchers":  0,   # Generate research points for tech
		"healers":      0,   # Reduce illness/injury, boost pop growth
		"traders":      0,   # Generate gold/trade with other cities
		"soldiers":     1,   # City defense, attack rating
		"idle":         0,   # Unassigned — consume food, do nothing
		"happiness":    70.0,
		"stability":    70.0,
		"food":         GameConstants.STARTING_FOOD,
		"wood":         GameConstants.STARTING_WOOD,
		"stone":        GameConstants.STARTING_STONE,
		"water":        50.0,
		"food_cap":     500.0,
		"wood_cap":     300.0,
		"stone_cap":    300.0,
		"water_cap":    GameConstants.WATER_STORAGE_BASE,
		"water_status": "normal",  # "normal", "low", "critical"
		"territory_radius": GameConstants.CITY_TERRITORY_RADIUS,
		"buildings":    [],        # Village grid buildings list
		"production_queue": [],
		# Village interior grid — starts with village center placed
		"village_grid": [
			{
				"gx":    4, "gy": 4,
				"type":  1,   # VILLAGE_CENTER
				"state": "active",
				"build_ticks_left": 0,
			}
		],
		"culture":      0.0,
		"defense":      1.0,
		"worked_tiles": []   # List of {x, y, resource} being actively worked
	}

	# Claim territory around the city
	world_map.claim_territory(x, y, GameConstants.CITY_TERRITORY_RADIUS,
		player_id, city_id)

	# Mark player as founded
	players[player_id]["founded"] = true

	# Remove the settler unit and notify clients
	var settler_owner = unit["owner"]
	units.erase(unit_id)
	emit_signal("unit_removed", settler_owner, unit_id)

	# Reveal fog around city
	_reveal_fog(player_id, x, y, GameConstants.VISION_CITY)

	emit_signal("city_updated", player_id, city_id, cities[city_id])
	print("City founded: ", city_name, " by player ", player_id, " at (", x, ",", y, ")")
	return true


# ─── VILLAGE BUILD ───────────────────────────────────────────

func village_build(player_id: int, city_id: int,
		building_type: int, gx: int, gy: int) -> Dictionary:
	if not cities.has(city_id):
		return {"ok": false, "error": "city_not_found"}
	var city = cities[city_id]
	if city["owner"] != player_id:
		return {"ok": false, "error": "not_owner"}

	# Validate grid bounds
	var grid_size = 10   # VillageConstants.VILLAGE_GRID_SIZE
	var bsize     = _building_size(building_type)
	if gx < 0 or gy < 0 or gx + bsize[0] > grid_size or gy + bsize[1] > grid_size:
		return {"ok": false, "error": "out_of_bounds"}

	# Check no overlap with existing buildings
	var grid = city["village_grid"]
	for b in grid:
		var bs = _building_size(b["type"])
		for dy in range(bs[1]):
			for dx in range(bs[0]):
				for ndy in range(bsize[1]):
					for ndx in range(bsize[0]):
						if b["gx"] + dx == gx + ndx and b["gy"] + dy == gy + ndy:
							return {"ok": false, "error": "occupied"}

	# Check resources
	var costs = _building_cost(building_type)
	if city.get("wood", 0.0) < costs.get("wood", 0):
		return {"ok": false, "error": "not_enough_wood"}
	if city.get("stone", 0.0) < costs.get("stone", 0):
		return {"ok": false, "error": "not_enough_stone"}

	# Deduct resources
	city["wood"]  = city.get("wood",  0.0) - costs.get("wood",  0)
	city["stone"] = city.get("stone", 0.0) - costs.get("stone", 0)

	# Add building in construction state
	var build_ticks = _building_build_ticks(building_type)
	var new_building = {
		"gx":              gx,
		"gy":              gy,
		"type":            building_type,
		"state":           "active" if build_ticks == 0 else "building",
		"build_ticks_left": build_ticks,
	}
	city["village_grid"].append(new_building)

	emit_signal("city_updated", player_id, city_id, city)
	return {"ok": true}


func village_assign_role(player_id: int, city_id: int,
		role: String, delta: int) -> Dictionary:
	if not cities.has(city_id):
		return {"ok": false, "error": "city_not_found"}
	var city = cities[city_id]
	if city["owner"] != player_id:
		return {"ok": false, "error": "not_owner"}

	var valid_roles = ["farmers", "hunters", "woodcutters", "miners",
		"builders", "researchers", "healers", "traders", "soldiers", "idle"]
	if not valid_roles.has(role):
		return {"ok": false, "error": "invalid_role"}

	var current   = city.get(role, 0)
	var idle      = city.get("idle", 0)
	var new_count = current + delta

	if new_count < 0:
		return {"ok": false, "error": "already_zero"}

	if delta > 0:
		# Moving from idle to role
		if idle < delta:
			return {"ok": false, "error": "no_idle_villagers"}
		city[role]   = current + delta
		city["idle"] = idle - delta
	else:
		# Moving from role to idle
		city[role]   = max(0, current + delta)
		city["idle"] = idle + min(current, abs(delta))

	emit_signal("city_updated", player_id, city_id, city)
	return {"ok": true}


# Advance construction on all village buildings each tick
func _tick_village_construction(city: Dictionary) -> void:
	var has_builder = city.get("builders", 0) > 0
	var any_finished = false
	for b in city["village_grid"]:
		if b["state"] == "building":
			if has_builder:
				b["build_ticks_left"] = max(0, b["build_ticks_left"] - 1)
				if b["build_ticks_left"] == 0:
					b["state"] = "active"
					any_finished = true
	if any_finished:
		emit_signal("city_updated", city["owner"], city["id"], city)


# Static cost/size lookups (mirrors VillageConstants without needing the class)
static func _building_cost(btype: int) -> Dictionary:
	match btype:
		2: return {"wood": 5,  "stone": 0}   # Hut
		3: return {"wood": 3,  "stone": 0}   # Farm
		4: return {"wood": 0,  "stone": 4}   # Well
		5: return {"wood": 1,  "stone": 1}   # Road
		6: return {"wood": 10, "stone": 5}   # Storehouse
	return {}

static func _building_size(btype: int) -> Array:
	match btype:
		1: return [2, 2]   # Village Center
		2: return [1, 1]   # Hut
		3: return [2, 1]   # Farm
		4: return [1, 1]   # Well
		5: return [1, 1]   # Road
		6: return [2, 2]   # Storehouse
	return [1, 1]

static func _building_build_ticks(btype: int) -> int:
	match btype:
		2: return 30   # Hut
		3: return 40   # Farm
		4: return 50   # Well
		5: return 10   # Road
		6: return 80   # Storehouse
	return 0


func _tick_city(city_id: int, season: String) -> void:
	var city = cities[city_id]
	var player_id = city["owner"]
	_tick_village_construction(city)
	var season_mods = GameConstants.SEASON_MODIFIERS.get(season, {})

	# Harvest from worked tiles
	_process_city_harvesting(city, season)

	# Food consumption
	var food_consumed = city["population"] * 0.01
	city["food"] = max(0.0, city["food"] - food_consumed)

	# Water - draw from worked tiles then consume
	_process_city_water(city, season)

	# Population growth/loss
	_process_city_population(city, season_mods)

	# Happiness and stability drift
	_process_city_morale(city, season)

	# Production queue
	_process_production_queue(city)

	emit_signal("city_updated", player_id, city_id, city)


func _process_city_harvesting(city: Dictionary, season: String) -> void:
	var season_mods = GameConstants.SEASON_MODIFIERS.get(season, {})

	# Apply water penalty to food if supply is critical
	var water_food_mult = 1.0
	if city.get("water_status", "normal") == "critical":
		water_food_mult = 1.0 - GameConstants.WATER_CRITICAL_FOOD_PENALTY

	var food_yield  = city["farmers"]     * 0.4 * season_mods.get("food", 1.0) * water_food_mult
	var wood_yield  = city["woodcutters"] * 0.3 * season_mods.get("wood", 1.0)
	var stone_yield = city["miners"]      * 0.25

	city["food"]  = min(city["food"]  + food_yield,  city["food_cap"])
	city["wood"]  = min(city["wood"]  + wood_yield,  city["wood_cap"])
	city["stone"] = min(city["stone"] + stone_yield, city["stone_cap"])


func _process_city_water(city: Dictionary, season: String) -> void:
	# Draw water from worked tiles within range
	var water_season_mult = GameConstants.WATER_SEASON_MULTIPLIER.get(season, 1.0)
	var water_gained = 0.0

	for tile_ref in city.get("worked_tiles", []):
		var tx = tile_ref.get("x", -1)
		var ty = tile_ref.get("y", -1)
		if tx < 0:
			continue
		var tile = world_map.get_tile(tx, ty)
		if tile.is_empty():
			continue
		var tile_type = tile.get("type", TileTypes.Type.GRASSLAND)
		var tile_data = TileTypes.TILE_RESOURCES.get(tile_type, {})
		var base_yield = tile_data.get("water_yield", 0.0)

		# Well improvement multiplies yield
		var improvement = tile.get("improvement", TileTypes.Improvement.NONE)
		var imp_effects = TileTypes.IMPROVEMENT_EFFECTS.get(improvement, {})
		var well_mult = imp_effects.get("water_yield_multiplier", 1.0)

		water_gained += base_yield * well_mult * water_season_mult

	# If no worked tiles yet, give a tiny baseline from city location itself
	if city["worked_tiles"].size() == 0:
		var city_tile = world_map.get_tile(city["x"], city["y"])
		if not city_tile.is_empty():
			var tile_type = city_tile.get("type", TileTypes.Type.GRASSLAND)
			var tile_data = TileTypes.TILE_RESOURCES.get(tile_type, {})
			water_gained = tile_data.get("water_yield", 1.0) * water_season_mult * 0.5

	# Fill storage
	city["water"] = min(city.get("water", 0.0) + water_gained, city.get("water_cap", GameConstants.WATER_STORAGE_BASE))

	# Consume water based on population
	var water_consumed = city["population"] * GameConstants.WATER_CONSUMPTION_PER_POP
	city["water"] = max(0.0, city["water"] - water_consumed)

	# Update status
	var water_pct = city["water"] / max(city.get("water_cap", GameConstants.WATER_STORAGE_BASE), 1.0)
	if water_pct <= GameConstants.WATER_CRITICAL_THRESHOLD:
		city["water_status"] = "critical"
	elif water_pct <= GameConstants.WATER_LOW_THRESHOLD:
		city["water_status"] = "low"
	else:
		city["water_status"] = "normal"


func _process_city_population(city: Dictionary, season_mods: Dictionary) -> void:
	var food_pct  = city["food"]  / max(city["food_cap"],  1.0)
	var happy_pct = city["happiness"]  / 100.0
	var stable_pct = city["stability"] / 100.0

	# Hard blocks on growth
	if food_pct < 0.2 or stable_pct < 0.3 or city["population"] >= city["pop_cap"]:
		# Check for population loss
		if city["happiness"] < GameConstants.POP_LOSS_HAPPINESS_THRESHOLD and \
		   city["stability"] < GameConstants.POP_LOSS_STABILITY_THRESHOLD:
			city["population"] = max(1, city["population"] - 1)
		return

	var growth_chance = GameConstants.POP_GROWTH_BASE_CHANCE * \
		(food_pct * 2.0) * (happy_pct * 2.0) * (stable_pct * 1.5) * \
		season_mods.get("pop_growth", 1.0)

	if randf() < growth_chance:
		city["population"] += 1
		city["pop_cap"] = max(city["pop_cap"], city["population"])
		# New citizen needs assignment - fire event to player
		_queue_worker_assignment(city["owner"], city["id"])


func _process_city_morale(city: Dictionary, season: String) -> void:
	# Happiness drifts toward 50 slowly unless influenced
	var happy_drift = (50.0 - city["happiness"]) * 0.001
	city["happiness"] = clamp(city["happiness"] + happy_drift, 0.0, 100.0)

	# Winter hits happiness
	if season == "winter":
		city["happiness"] = clamp(city["happiness"] - 0.05, 0.0, 100.0)

	# Water shortage hits happiness
	var water_status = city.get("water_status", "normal")
	if water_status == "low":
		city["happiness"] = clamp(city["happiness"] - GameConstants.WATER_LOW_HAPPINESS_PENALTY, 0.0, 100.0)
	elif water_status == "critical":
		city["happiness"] = clamp(city["happiness"] - GameConstants.WATER_CRITICAL_HAPPINESS_PENALTY, 0.0, 100.0)
		city["stability"] = clamp(city["stability"] - 1.0, 0.0, 100.0)

	# Stability drifts toward 60
	var stable_drift = (60.0 - city["stability"]) * 0.001
	city["stability"] = clamp(city["stability"] + stable_drift, 0.0, 100.0)


func _process_production_queue(city: Dictionary) -> void:
	if city["production_queue"].size() == 0:
		return
	var item = city["production_queue"][0]
	item["progress"] = item.get("progress", 0.0) + 1.0
	if item["progress"] >= item["cost"]:
		city["production_queue"].remove_at(0)
		_complete_production(city, item)


func _complete_production(city: Dictionary, item: Dictionary) -> void:
	match item["type"]:
		"settler":
			_spawn_unit(city["owner"], "settler", city["x"], city["y"])
		"worker":
			_spawn_unit(city["owner"], "worker", city["x"], city["y"])
		"scout":
			_spawn_unit(city["owner"], "scout", city["x"], city["y"])
		"soldier":
			_spawn_unit(city["owner"], "soldier", city["x"], city["y"])


func _queue_worker_assignment(player_id: int, city_id: int) -> void:
	# Fire an event to the player to assign the new worker
	var event = {
		"id":          "new_citizen",
		"type":        "worker_assignment",
		"city_id":     city_id,
		"title":       "New Citizen",
		"description": "A new member has joined your city. Assign them a role.",
		"urgency":     "low",
		"days_remaining": GameConstants.EVENT_EXPIRY_LOW,
		"auto_resolve_after": 3
	}
	if players.has(player_id):
		players[player_id]["active_events"].append(event)
		emit_signal("player_event_fired", player_id, event)


# -------------------------------------------------------------
# UNITS
# -------------------------------------------------------------
func _spawn_unit(player_id: int, unit_type: String, x: int, y: int) -> int:
	var unit_id = _next_unit_id
	_next_unit_id += 1

	units[unit_id] = {
		"id":           unit_id,
		"owner":        player_id,
		"type":         unit_type,
		"x":            x,
		"y":            y,
		"speed":        GameConstants.UNIT_SPEED_MILES_PER_TICK.get(unit_type, 1.0),
		"health":       100.0,
		"status":       "idle",     # idle, moving, working, fortified
		"path":          [],        # Queued movement path [{x,y}, ...]
		"travel_progress": 0.0,    # Miles covered toward next tile
		"travel_total":    0.0,    # Total miles for current leg
		"travel_target":   null,   # {x, y} the tile currently being traveled to
		"travel_from_x":   0.0,    # Interpolated start position for smooth redirect
		"travel_from_y":   0.0,    # Interpolated start position for smooth redirect
		"queued_action":   null,   # Action to execute on arrival {action_id, data}
		"working_tile":    null    # {x, y, resource} if currently working a tile
	}

	emit_signal("unit_updated", player_id, unit_id, units[unit_id])
	return unit_id


# Set a unit's destination - movement happens over time via ticks
func move_unit(player_id: int, unit_id: int, target_x: int, target_y: int) -> bool:
	if not units.has(unit_id):
		return false
	var unit = units[unit_id]
	if unit["owner"] != player_id:
		return false

	var tile = world_map.get_tile(target_x, target_y)
	if tile.is_empty() or not tile["passable"]:
		return false

	# Calculate interpolated position to use as new travel origin
	# so redirecting mid-move doesn't snap or skip
	var from_x: float = float(unit["x"])
	var from_y: float = float(unit["y"])
	if unit["status"] == "moving" and unit.get("travel_target") != null:
		var tt       = unit["travel_target"]
		var progress = unit.get("travel_progress", 0.0)
		var total    = unit.get("travel_total", 1.0)
		var t        = clamp(progress / max(total, 0.001), 0.0, 1.0)
		from_x = lerp(from_x, float(tt["x"]), t)
		from_y = lerp(from_y, float(tt["y"]), t)

	unit["path"]            = []
	unit["travel_progress"] = 0.0
	unit["travel_from_x"]   = from_x
	unit["travel_from_y"]   = from_y

	var season = GameConstants.SEASON_NAMES[current_season]
	var miles  = TileTypes.get_tile_miles(tile["type"], tile["improvement"], season)

	# Scale miles by actual distance from interpolated position
	# so a redirect mid-tile doesn't take a full tile worth of time
	var dx        = float(target_x) - from_x
	var dy        = float(target_y) - from_y
	var tile_dist = sqrt(dx * dx + dy * dy)   # 0.0 - ~1.41 tile widths
	var adj_miles = miles * clamp(tile_dist, 0.05, 2.0)

	unit["status"]        = "moving"
	unit["travel_target"] = {"x": target_x, "y": target_y}
	unit["travel_total"]  = adj_miles

	emit_signal("unit_updated", player_id, unit_id, _unit_to_dict(unit))
	return true


func start_build_improvement(player_id: int, unit_id: int,
		tx: int, ty: int, improvement: int) -> bool:
	if not units.has(unit_id):
		return false
	var unit = units[unit_id]
	if unit.get("owner", -1) != player_id:
		return false

	var tile = world_map.get_tile(tx, ty)
	if tile.is_empty():
		return false

	# Move unit to tile first if not already there
	if unit["x"] != tx or unit["y"] != ty:
		move_unit(player_id, unit_id, tx, ty)
		# Queue the build to start on arrival
		unit["queued_build"] = {"improvement": improvement, "x": tx, "y": ty}
		return true

	# Start building
	world_map.start_improvement(tx, ty, improvement)
	unit["status"] = "building"
	unit["build_target"] = {"x": tx, "y": ty, "improvement": improvement}
	emit_signal("unit_updated", player_id, unit_id, _unit_to_dict(unit))
	return true


# Queue an action to execute when the unit arrives at its destination.
# Also moves the unit to target_x/y if not already there.
func move_and_queue_action(player_id: int, unit_id: int,
		target_x: int, target_y: int, action_id: String, data: Dictionary) -> bool:
	if not units.has(unit_id):
		return false
	var unit = units[unit_id]
	if unit["owner"] != player_id:
		return false
	unit["queued_action"] = {"action_id": action_id, "data": data}
	data["city_name"] = data.get("city_name", "New City")  # copy up for arrival handler
	unit["queued_action"]["city_name"] = data.get("city_name", "New City")
	if unit["x"] == target_x and unit["y"] == target_y:
		# Already there — execute immediately
		unit["queued_action"] = null
		if action_id == "found_city":
			return found_city(player_id, unit_id, data.get("city_name", "New City"))
	return move_unit(player_id, unit_id, target_x, target_y)


func cancel_unit_movement(player_id: int, unit_id: int) -> void:
	if not units.has(unit_id):
		return
	var unit = units[unit_id]
	if unit["owner"] != player_id:
		return
	unit["status"]          = "idle"
	unit["travel_target"]   = null
	unit["travel_progress"] = 0.0
	unit["travel_total"]    = 0.0
	unit["path"]            = []
	unit["queued_action"]   = null
	emit_signal("unit_updated", player_id, unit_id, _unit_to_dict(unit))


# Set a multi-tile path for a unit to follow
func set_unit_path(player_id: int, unit_id: int, path: Array) -> bool:
	if not units.has(unit_id):
		return false
	var unit = units[unit_id]
	if unit["owner"] != player_id:
		return false
	unit["path"] = path.duplicate()
	# Start moving toward first tile immediately
	if path.size() > 0:
		var next = unit["path"][0]
		unit["path"].remove_at(0)
		return move_unit(player_id, unit_id, next.x, next.y)
	return true


func _tick_unit(unit_id: int) -> void:
	var unit = units[unit_id]

	if unit["status"] != "moving" or unit["travel_target"] == null:
		return

	# Advance travel progress by unit speed this tick
	unit["travel_progress"] += unit["speed"] * dev_timescale

	# Arrived?
	if unit["travel_progress"] >= unit["travel_total"]:
		var target = unit["travel_target"]
		unit["x"]               = target["x"]
		unit["y"]               = target["y"]
		unit["travel_target"]   = null
		unit["travel_progress"] = 0.0
		unit["travel_total"]    = 0.0

		# Handle queued action on arrival
		if unit.get("queued_action") != null:
			var qa = unit["queued_action"]
			unit["queued_action"] = null
			if qa["action_id"] == "found_city":
				found_city(unit["owner"], unit_id, qa.get("city_name", "New City"))
				return  # unit is consumed, no further processing

		# Start queued build if one was pending
		if unit.has("queued_build") and unit["queued_build"] != null:
			var qb = unit["queued_build"]
			if qb["x"] == unit["x"] and qb["y"] == unit["y"]:
				world_map.start_improvement(qb["x"], qb["y"], qb["improvement"])
				unit["status"]       = "building"
				unit["build_target"] = qb
			unit["queued_build"] = null
		unit["status"]          = "idle"

		# Reveal fog around new position
		var vision = GameConstants.VISION_WORKER
		match unit["type"]:
			"settler":  vision = GameConstants.VISION_SETTLER
			"scout":    vision = GameConstants.VISION_SCOUT
			"soldier":  vision = GameConstants.VISION_SOLDIER
		_reveal_fog(unit["owner"], unit["x"], unit["y"], vision)

		# Continue along path if more tiles queued
		if unit["path"].size() > 0:
			var next = unit["path"][0]
			unit["path"].remove_at(0)
			move_unit(unit["owner"], unit_id, next.x, next.y)

	emit_signal("unit_updated", unit["owner"], unit_id, _unit_to_dict(unit))


# -------------------------------------------------------------
# FOG OF WAR
# -------------------------------------------------------------
func _reveal_fog(player_id: int, cx: int, cy: int, radius: int) -> void:
	if not players.has(player_id):
		return
	var fog = players[player_id]["fog_of_war"]
	var tiles = world_map.get_tiles_in_radius(cx, cy, radius)
	for coord in tiles:
		fog[str(coord.x) + "," + str(coord.y)] = true


func is_tile_visible(player_id: int, x: int, y: int) -> bool:
	if not players.has(player_id):
		return false
	return players[player_id]["fog_of_war"].has(str(x) + "," + str(y))


# -------------------------------------------------------------
# EVENTS
# -------------------------------------------------------------
func _tick_player_events(player_id: int) -> void:
	var player = players[player_id]
	var events = player["active_events"]
	var to_remove: Array = []

	for event in events:
		event["days_remaining"] = event.get("days_remaining", 7) - (1.0 / GameConstants.TICKS_PER_DAY)

		if event["days_remaining"] <= 0:
			_auto_resolve_event(player_id, event)
			to_remove.append(event)

	for event in to_remove:
		events.erase(event)
		player["event_history"].append(event)
		if player["event_history"].size() > GameConstants.EVENT_HISTORY_CAP:
			player["event_history"].remove_at(0)


func _auto_resolve_event(player_id: int, event: Dictionary) -> void:
	var player = players[player_id]
	# Use relevant competency to determine outcome
	var comp_type = event.get("competency_type", "governance")
	var comp_score = player["competency"].get(comp_type, 0.1)
	var roll = randf()
	var outcome = "bad"
	if roll < comp_score:
		outcome = "good"
	elif roll < comp_score + 0.3:
		outcome = "neutral"

	event["resolved_by"]  = "auto"
	event["outcome"]      = outcome
	event["resolved_tick"] = current_tick


func resolve_event(player_id: int, event_id: String, choice_index: int) -> bool:
	if not players.has(player_id):
		return false
	var player = players[player_id]
	for i in range(player["active_events"].size()):
		var event = player["active_events"][i]
		if event.get("id", "") == event_id:
			event["resolved_by"]   = "player"
			event["choice_index"]  = choice_index
			event["resolved_tick"] = current_tick
			player["active_events"].remove_at(i)
			player["event_history"].append(event)
			return true
	return false


# -------------------------------------------------------------
# RESEARCH / TECH
# -------------------------------------------------------------
func _trigger_breakthrough(player_id: int) -> void:
	var event = {
		"id":          "breakthrough_" + str(current_tick),
		"type":        "breakthrough",
		"title":       "Research Breakthrough",
		"description": "Your researchers have made a breakthrough. Choose a new technology.",
		"urgency":     "high",
		"days_remaining": GameConstants.EVENT_EXPIRY_HIGH
	}
	if players.has(player_id):
		players[player_id]["active_events"].append(event)
		emit_signal("player_event_fired", player_id, event)


# -------------------------------------------------------------
# DEV COMMANDS
# Only available when GameConstants.DEV_MODE is true
# -------------------------------------------------------------
func dev_set_timescale(scale: float) -> void:
	if not GameConstants.DEV_MODE:
		return
	dev_timescale = clamp(scale, 0.1, 1000.0)
	print("[DEV] Timescale set to ", dev_timescale)


func dev_give_resources(player_id: int, city_id: int,
		food: float, wood: float, stone: float) -> void:
	if not GameConstants.DEV_MODE:
		return
	if not cities.has(city_id):
		return
	var city = cities[city_id]
	if city["owner"] != player_id:
		return
	city["food"]  = min(city["food"]  + food,  city["food_cap"])
	city["wood"]  = min(city["wood"]  + wood,  city["wood_cap"])
	city["stone"] = min(city["stone"] + stone, city["stone_cap"])
	print("[DEV] Gave resources to city ", city_id)


func dev_reveal_map(player_id: int) -> void:
	if not GameConstants.DEV_MODE:
		return
	if not players.has(player_id):
		return
	var fog = players[player_id]["fog_of_war"]
	for y in range(GameConstants.MAP_HEIGHT):
		for x in range(GameConstants.MAP_WIDTH):
			fog[str(x) + "," + str(y)] = true
	print("[DEV] Map revealed for player ", player_id)


func dev_set_day(day: int) -> void:
	if not GameConstants.DEV_MODE:
		return
	current_day    = day
	current_tick   = day * GameConstants.TICKS_PER_DAY
	current_season = int(current_day / GameConstants.DAYS_PER_SEASON) % GameConstants.SEASONS_PER_YEAR
	current_year   = int(current_day / GameConstants.DAYS_PER_YEAR) + 1
	print("[DEV] Jumped to day ", day)


func dev_spawn_unit(player_id: int, unit_type: String, x: int, y: int) -> void:
	if not GameConstants.DEV_MODE:
		return
	_spawn_unit(player_id, unit_type, x, y)
	print("[DEV] Spawned ", unit_type, " for player ", player_id, " at (", x, ",", y, ")")


# -------------------------------------------------------------
# HELPERS
# -------------------------------------------------------------
func _get_all_city_positions() -> Array:
	var positions: Array = []
	for city_id in cities:
		var city = cities[city_id]
		positions.append(Vector2i(city["x"], city["y"]))
	return positions


func get_time_string() -> String:
	var season = GameConstants.SEASON_NAMES[current_season].capitalize()
	return "Day " + str(current_day % GameConstants.DAYS_PER_YEAR) + \
		" | " + season + " | Year " + str(current_year)


func _on_tile_changed(x: int, y: int, tile_data: Dictionary) -> void:
	emit_signal("tile_updated", x, y, tile_data)




# Convert unit data to JSON-safe dictionary
func _unit_to_dict(unit: Dictionary) -> Dictionary:
	var out = unit.duplicate()
	# Convert path Vector2i array to plain dicts
	var safe_path: Array = []
	for p in unit.get("path", []):
		if p is Vector2i:
			safe_path.append({"x": p.x, "y": p.y})
		else:
			safe_path.append(p)
	out["path"]          = safe_path
	out["travel_from_x"] = unit.get("travel_from_x", float(unit.get("x", 0)))
	out["travel_from_y"] = unit.get("travel_from_y", float(unit.get("y", 0)))
	# Convert travel_target Vector2i
	if unit.get("travel_target") != null and unit["travel_target"] is Vector2i:
		var t = unit["travel_target"]
		out["travel_target"] = {"x": t.x, "y": t.y}
	return out

# -------------------------------------------------------------
# SAVE / LOAD
# -------------------------------------------------------------
func save_world() -> void:
	var data = {
		"tick":    current_tick,
		"day":     current_day,
		"season":  current_season,
		"year":    current_year,
		"players": players,
		"cities":  cities,
		"units":   units,
		"map":     world_map.serialize()
	}

	# Backup previous save
	if FileAccess.file_exists(GameConstants.SAVE_PATH):
		var src = FileAccess.open(GameConstants.SAVE_PATH, FileAccess.READ)
		var backup = FileAccess.open(GameConstants.SAVE_BACKUP_PATH, FileAccess.WRITE)
		if src and backup:
			backup.store_string(src.get_as_text())

	var file = FileAccess.open(GameConstants.SAVE_PATH, FileAccess.WRITE)
	if file:
		file.store_string(JSON.stringify(data))
		print("World saved at tick ", current_tick)
	else:
		push_error("Failed to save world!")


func load_world() -> bool:
	if not FileAccess.file_exists(GameConstants.SAVE_PATH):
		return false

	var file = FileAccess.open(GameConstants.SAVE_PATH, FileAccess.READ)
	if not file:
		return false

	var json = JSON.new()
	var err  = json.parse(file.get_as_text())
	if err != OK:
		push_error("Failed to parse save file!")
		return false

	var data = json.get_data()
	current_tick   = data.get("tick",   0)
	current_day    = data.get("day",    0)
	current_season = data.get("season", 0)
	current_year   = data.get("year",   1)
	players        = data.get("players", {})
	cities         = data.get("cities",  {})
	units          = data.get("units",   {})

	if data.has("map"):
		world_map = WorldMap.new()
		add_child(world_map)
		world_map.tile_changed.connect(_on_tile_changed)
		world_map.deserialize(data["map"])

	print("World loaded. Tick: ", current_tick, " Day: ", current_day)
	return true
