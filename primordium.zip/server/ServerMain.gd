class_name ServerMain
extends Node

# =============================================================
# SERVER MAIN
# Entry point for the headless server.
# Launch with:
#   godot --headless --script server/ServerMain.gd
# Or via the server.tscn scene.
#
# Command line args:
#   --port 7777       Override default port
#   --seed 12345      Set world seed
#   --load            Load existing save instead of new world
#   --timescale 10    Start at 10x speed (dev only)
# =============================================================


const VERSION: String = "0.1.0"

var simulation: WorldSimulation
var network: NetworkServer

var _port: int       = GameConstants.SERVER_PORT
var _seed: int       = 0
var _load_save: bool = false


# -------------------------------------------------------------
# ENTRY
# -------------------------------------------------------------
func _ready() -> void:
	print("===========================================")
	print("  PRIMORDIUM SERVER v", VERSION)
	print("===========================================")

	_parse_args()
	_start_simulation()
	_start_network()

	print("Server running on port ", _port)
	print("Tick interval: ", GameConstants.get_tick_interval(), "s")
	print("1 game day = ", GameConstants.TICKS_PER_DAY * GameConstants.get_tick_interval() / 60.0, " real minutes")
	print("Dev mode: ", GameConstants.DEV_MODE)
	print("===========================================")


# -------------------------------------------------------------
# COMMAND LINE ARGS
# -------------------------------------------------------------
func _parse_args() -> void:
	var args = OS.get_cmdline_args()
	var i = 0
	while i < args.size():
		match args[i]:
			"--port":
				if i + 1 < args.size():
					_port = int(args[i + 1])
					i += 1
			"--seed":
				if i + 1 < args.size():
					_seed = int(args[i + 1])
					i += 1
			"--load":
				_load_save = true
			"--timescale":
				if i + 1 < args.size() and GameConstants.DEV_MODE:
					var scale = float(args[i + 1])
					# Applied after simulation starts
					_pending_timescale = scale
					i += 1
		i += 1

	# Random seed if none provided
	if _seed == 0:
		_seed = randi()

	print("Args parsed - port:", _port, " seed:", _seed, " load:", _load_save)


var _pending_timescale: float = 1.0


# -------------------------------------------------------------
# SIMULATION
# -------------------------------------------------------------
func _start_simulation() -> void:
	simulation = WorldSimulation.new()
	simulation.name = "WorldSimulation"
	add_child(simulation)

	# Connect simulation signals to server relay
	simulation.tick_completed.connect(_on_tick_completed)
	simulation.player_event_fired.connect(_on_player_event)
	simulation.city_updated.connect(_on_city_updated)
	simulation.unit_updated.connect(_on_unit_updated)
	simulation.unit_removed.connect(_on_unit_removed)
	simulation.tile_updated.connect(_on_tile_updated)
	simulation.day_changed.connect(_on_day_changed)
	simulation.season_changed.connect(_on_season_changed)

	# Load or generate world
	var loaded = false
	if _load_save:
		loaded = simulation.load_world()
		if loaded:
			print("World loaded from save.")
		else:
			print("No save found, generating new world.")

	if not loaded:
		simulation.initialize(_seed)

	# Apply dev timescale if set via args
	if _pending_timescale != 1.0:
		simulation.dev_set_timescale(_pending_timescale)


# -------------------------------------------------------------
# NETWORK
# -------------------------------------------------------------
func _start_network() -> void:
	network = NetworkServer.new()
	network.name = "NetworkServer"
	add_child(network)

	network.player_connected.connect(_on_player_connected)
	network.player_disconnected.connect(_on_player_disconnected)
	network.message_received.connect(_on_message_received)

	network.start(_port)


# -------------------------------------------------------------
# SIMULATION SIGNAL HANDLERS
# Relay game state changes to relevant connected clients
# -------------------------------------------------------------
func _on_tick_completed(tick: int, day: int, season: String, year: int) -> void:
	# Send lightweight tick heartbeat to all clients
	_safe_broadcast({
		"type":   "tick",
		"tick":   tick,
		"day":    day,
		"season": season,
		"year":   year,
		"time":   simulation.get_time_string()
	})


func _on_day_changed(day: int, season: String, year: int) -> void:
	print("[Day ", day, "] ", season.capitalize(), " Year ", year)
	_safe_broadcast({
		"type":   "day_changed",
		"day":    day,
		"season": season,
		"year":   year
	})


func _on_season_changed(season: String) -> void:
	print("[Season changed] ", season.capitalize())
	_safe_broadcast({
		"type":   "season_changed",
		"season": season
	})


func _on_player_event(player_id: int, event: Dictionary) -> void:
	_safe_send(player_id, {
		"type":  "event",
		"event": event
	})


func _on_city_updated(player_id: int, city_id: int, city_data: Dictionary) -> void:
	# Send city update to owner
	_safe_send(player_id, {
		"type":    "city_update",
		"city_id": city_id,
		"city":    city_data
	})
	# Send partial update to nearby players (they can see the city exists but not internals)
	var public_data = {
		"id":    city_data["id"],
		"name":  city_data["name"],
		"owner": city_data["owner"],
		"x":     city_data["x"],
		"y":     city_data["y"]
	}
	_safe_broadcast_except(player_id, {
		"type":    "city_visible",
		"city_id": city_id,
		"city":    public_data
	})


func _on_unit_removed(player_id: int, unit_id: int) -> void:
	_safe_broadcast({
		"type":    "unit_removed",
		"unit_id": unit_id
	})


func _on_unit_updated(player_id: int, unit_id: int, unit_data: Dictionary) -> void:
	# Send full unit data to owner
	_safe_send(player_id, {
		"type":    "unit_update",
		"unit_id": unit_id,
		"unit":    unit_data
	})
	# Send position only to other players (they see the unit but not its stats)
	var public_data = {
		"id":    unit_data["id"],
		"owner": unit_data["owner"],
		"type":  unit_data["type"],
		"x":     unit_data["x"],
		"y":     unit_data["y"]
	}
	_safe_broadcast_except(player_id, {
		"type":    "unit_visible",
		"unit_id": unit_id,
		"unit":    public_data
	})


func _on_tile_updated(x: int, y: int, tile_data: Dictionary) -> void:
	# Send tile update to all players who have this tile revealed
	for player_id in simulation.players:
		if simulation.is_tile_visible(player_id, x, y):
			_safe_send(player_id, {
				"type": "tile_update",
				"x":    x,
				"y":    y,
				"tile": tile_data
			})


# -------------------------------------------------------------
# NETWORK SIGNAL HANDLERS
# Handle incoming client messages
# -------------------------------------------------------------
func _on_player_connected(player_id: int, player_name: String) -> void:
	print("Player connected: ", player_name, " (id:", player_id, ")")

	if simulation.players.has(player_id):
		# Returning player
		simulation.set_player_online(player_id, true)
		_send_full_state(player_id)
	else:
		# New player
		simulation.add_player(player_id, player_name)
		_send_full_state(player_id)


func _on_player_disconnected(player_id: int) -> void:
	print("Player disconnected: id:", player_id)
	simulation.remove_player(player_id)


func _on_message_received(player_id: int, message: Dictionary) -> void:
	var msg_type = message.get("type", "")

	match msg_type:
		"move_unit":
			var unit_id = int(message.get("unit_id", -1))
			var tx      = int(message.get("x", 0))
			var ty      = int(message.get("y", 0))
			simulation.move_unit(player_id, unit_id, tx, ty)

		"set_path":
			var unit_id = message.get("unit_id", -1)
			var path    = message.get("path", [])
			var vec_path: Array = []
			for p in path:
				vec_path.append(Vector2i(p["x"], p["y"]))
			simulation.set_unit_path(player_id, unit_id, vec_path)

		"cancel_move":
			var unit_id = int(message.get("unit_id", -1))
			simulation.cancel_unit_movement(player_id, unit_id)

		"get_actions":
			_handle_get_actions(player_id, message)

		"do_action":
			_handle_do_action(player_id, message)

		"found_city":
			var unit_id   = message.get("unit_id", -1)
			var city_name = message.get("name", "New City")
			var success   = simulation.found_city(player_id, unit_id, city_name)
			_safe_send(player_id, {
				"type":    "found_city_result",
				"success": success
			})

		"village_build":
			var city_id  = int(message.get("city_id", -1))
			var btype    = int(message.get("building_type", 0))
			var gx       = int(message.get("gx", 0))
			var gy       = int(message.get("gy", 0))
			var result   = simulation.village_build(player_id, city_id, btype, gx, gy)
			if not result["ok"]:
				_safe_send(player_id, {
					"type":  "village_build_error",
					"error": result.get("error", "unknown")
				})

		"village_role":
			var city_id = int(message.get("city_id", -1))
			var role    = message.get("role", "")
			var delta   = int(message.get("delta", 0))
			var result  = simulation.village_assign_role(player_id, city_id, role, delta)
			if not result["ok"]:
				_safe_send(player_id, {
					"type":  "village_role_error",
					"error": result.get("error", "unknown")
				})

		"assign_workers":
			var city_id      = message.get("city_id", -1)
			var farmers      = message.get("farmers", 0)
			var woodcutters  = message.get("woodcutters", 0)
			var miners       = message.get("miners", 0)
			var researchers  = message.get("researchers", 0)
			_handle_assign_workers(player_id, city_id,
				farmers, woodcutters, miners, researchers)

		"resolve_event":
			var event_id     = message.get("event_id", "")
			var choice_index = message.get("choice", 0)
			simulation.resolve_event(player_id, event_id, choice_index)

		"request_tiles":
			# Client requesting tile data for visible area
			var coords_raw = message.get("coords", [])
			var coords: Array = []
			for c in coords_raw:
				coords.append(Vector2i(c["x"], c["y"]))
			var chunk = simulation.world_map.get_tile_chunk(coords)
			_safe_send(player_id, {
				"type":  "tile_chunk",
				"tiles": chunk
			})

		# DEV COMMANDS - only processed if DEV_MODE is on
		"dev_timescale":
			if GameConstants.DEV_MODE:
				simulation.dev_set_timescale(message.get("scale", 1.0))
				_safe_send(player_id, {
					"type": "dev_ack",
					"msg":  "Timescale set to " + str(message.get("scale", 1.0))
				})

		"dev_give":
			if GameConstants.DEV_MODE:
				simulation.dev_give_resources(
					player_id,
					message.get("city_id", -1),
					message.get("food",  0.0),
					message.get("wood",  0.0),
					message.get("stone", 0.0)
				)

		"dev_reveal":
			if GameConstants.DEV_MODE:
				simulation.dev_reveal_map(player_id)
				_send_revealed_tiles(player_id)

		"dev_day":
			if GameConstants.DEV_MODE:
				simulation.dev_set_day(message.get("day", 0))

		"dev_spawn":
			if GameConstants.DEV_MODE:
				simulation.dev_spawn_unit(
					player_id,
					message.get("unit_type", "settler"),
					message.get("x", 0),
					message.get("y", 0)
				)


# -------------------------------------------------------------
# STATE SYNC
# Send a full state snapshot to a connecting/reconnecting player
# -------------------------------------------------------------
func _send_full_state(player_id: int) -> void:
	var player = simulation.players.get(player_id, {})

	# Send lightweight player summary (exclude heavy fog_of_war dict)
	var player_summary = {}
	for k in player:
		if k != "fog_of_war" and k != "event_history":
			player_summary[k] = player[k]

	# Send player's own data
	_safe_send(player_id, {
		"type":   "init",
		"player": player_summary,
		"tick":   simulation.current_tick,
		"day":    simulation.current_day,
		"season": GameConstants.SEASON_NAMES[simulation.current_season],
		"year":   simulation.current_year,
		"time":   simulation.get_time_string()
	})

	# Send all cities this player owns
	for city_id in simulation.cities:
		var city = simulation.cities[city_id]
		if city["owner"] == player_id:
			_safe_send(player_id, {
				"type":    "city_update",
				"city_id": city_id,
				"city":    city
			})

	# Send all units this player owns
	for unit_id in simulation.units:
		var unit = simulation.units[unit_id]
		if unit["owner"] == player_id:
			_safe_send(player_id, {
				"type":    "unit_update",
				"unit_id": unit_id,
				"unit":    unit
			})

	# Send pending events
	for event in player.get("active_events", []):
		_safe_send(player_id, {
			"type":  "event",
			"event": event
		})

	# Send visible tile data
	_send_revealed_tiles(player_id)


func _send_revealed_tiles(player_id: int) -> void:
	var fog = simulation.players[player_id].get("fog_of_war", {})
	var coords: Array = []
	for key in fog:
		var parts = key.split(",")
		if parts.size() == 2:
			coords.append(Vector2i(int(parts[0]), int(parts[1])))

	# Send in chunks of 500 tiles to avoid huge packets
	var chunk_size = 50
	var i = 0
	print("Sending ", coords.size(), " revealed tiles in chunks of ", chunk_size)
	while i < coords.size():
		var batch = coords.slice(i, min(i + chunk_size, coords.size()))
		var chunk = simulation.world_map.get_tile_chunk(batch)
		print("  Chunk ", i, ": ", chunk.size(), " tiles")
		_safe_send(player_id, {
			"type":  "tile_chunk",
			"tiles": chunk
		})
		i += chunk_size


func _handle_assign_workers(player_id: int, city_id: int,
		farmers: int, woodcutters: int, miners: int, researchers: int) -> void:
	if not simulation.cities.has(city_id):
		return
	var city = simulation.cities[city_id]
	if city["owner"] != player_id:
		return

	var total = farmers + woodcutters + miners + researchers
	if total > city["population"]:
		return

	city["farmers"]     = farmers
	city["woodcutters"] = woodcutters
	city["miners"]      = miners
	city["researchers"] = researchers


# -------------------------------------------------------------
# ACTION SYSTEM
# -------------------------------------------------------------
func _handle_get_actions(player_id: int, message: Dictionary) -> void:
	var unit_id  = int(message.get("unit_id", -1))
	var target_x = int(message.get("x", -1))
	var target_y = int(message.get("y", -1))

	if not simulation.units.has(unit_id):
		return
	var unit = simulation.units[unit_id]
	if unit.get("owner", -1) != player_id:
		return

	var player      = simulation.players.get(player_id, {})
	var target_tile = simulation.world_map.get_tile(target_x, target_y)

	var valid_ids = ActionFilter.get_valid_actions(
		unit, target_tile, target_x, target_y,
		player, simulation.cities, simulation.world_map)

	# Build response list with labels
	var actions: Array = []
	for action_id in valid_ids:
		actions.append({
			"id":       action_id,
			"label":    ActionRegistry.get_label(action_id),
			"category": ActionRegistry.get_category(action_id),
			"needs_input": ActionRegistry.needs_confirm_text(action_id),
			"input_prompt": ActionRegistry.get_confirm_prompt(action_id),
		})

	_safe_send(player_id, {
		"type":    "actions_response",
		"unit_id": unit_id,
		"tile_x":  target_x,
		"tile_y":  target_y,
		"actions": actions
	})


func _handle_do_action(player_id: int, message: Dictionary) -> void:
	var action_id  = message.get("action_id", "")
	var unit_id    = int(message.get("unit_id", -1))
	var target_x   = int(message.get("x", -1))
	var target_y   = int(message.get("y", -1))
	var text_input = message.get("text_input", "")

	if not simulation.units.has(unit_id):
		return
	var unit = simulation.units[unit_id]
	if unit.get("owner", -1) != player_id:
		return

	match action_id:
		"move":
			simulation.move_unit(player_id, unit_id, target_x, target_y)
		"cancel_move":
			simulation.cancel_unit_movement(player_id, unit_id)
		"found_city":
			var city_name = text_input if text_input != "" else "New City"
			# If target tile differs from unit's current tile, move there first then found
			if unit.get("x") != target_x or unit.get("y") != target_y:
				simulation.move_and_queue_action(player_id, unit_id,
					target_x, target_y, "found_city", {"city_name": city_name})
			else:
				var success = simulation.found_city(player_id, unit_id, city_name)
				_safe_send(player_id, {"type": "found_city_result", "success": success, "name": city_name})
		"build_farm":
			_handle_build_improvement(player_id, unit_id, target_x, target_y, TileTypes.Improvement.FARM)
		"build_lumber_camp":
			_handle_build_improvement(player_id, unit_id, target_x, target_y, TileTypes.Improvement.LUMBER_CAMP)
		"build_mine":
			_handle_build_improvement(player_id, unit_id, target_x, target_y, TileTypes.Improvement.MINE)
		"build_well":
			_handle_build_improvement(player_id, unit_id, target_x, target_y, TileTypes.Improvement.WELL)
		"build_fishing_hut":
			_handle_build_improvement(player_id, unit_id, target_x, target_y, TileTypes.Improvement.FISHING_HUT)
		"build_irrigation":
			_handle_build_improvement(player_id, unit_id, target_x, target_y, TileTypes.Improvement.IRRIGATION)
		"build_road":
			_handle_build_improvement(player_id, unit_id, target_x, target_y, TileTypes.Improvement.ROAD)
		"build_fort":
			_handle_build_improvement(player_id, unit_id, target_x, target_y, TileTypes.Improvement.FORT)
		"build_watchtower":
			_handle_build_improvement(player_id, unit_id, target_x, target_y, TileTypes.Improvement.WATCHTOWER)
		"fortify":
			simulation.units[unit_id]["status"] = "fortified"
			simulation.emit_signal("unit_updated", player_id, unit_id,
				simulation._unit_to_dict(simulation.units[unit_id]))
		"scout_area":
			simulation.move_unit(player_id, unit_id, target_x, target_y)


func _handle_build_improvement(player_id: int, unit_id: int,
		tx: int, ty: int, improvement: int) -> void:
	var result = simulation.start_build_improvement(player_id, unit_id, tx, ty, improvement)
	_safe_send(player_id, {
		"type":    "build_started",
		"success": result,
		"x": tx, "y": ty,
		"improvement": improvement
	})


# -------------------------------------------------------------
# SANITIZE
# Recursively convert all Dictionary/Array values to JSON-safe types
# -------------------------------------------------------------
# Non-recursive sanitize - converts one level at a time
func _sanitize_value(value) -> Variant:
	if value is int or value is float or value is bool or value is String:
		return value
	if value is Vector2i or value is Vector2:
		return str(int(value.x)) + "," + str(int(value.y))
	if value is Color:
		return str(value.r) + "," + str(value.g) + "," + str(value.b)
	if value is Dictionary:
		return "[dict]"  # placeholder, handled by _sanitize_dict
	if value is Array:
		return "[arr]"   # placeholder, handled below
	return str(value)


func _sanitize(value, depth: int = 0) -> Variant:
	if depth > 6:
		return null
	if value is int or value is float or value is bool or value is String:
		return value
	if value is Vector2i or value is Vector2:
		return {"x": int(value.x), "y": int(value.y)}
	if value is Color:
		return {"r": value.r, "g": value.g, "b": value.b}
	if value is Dictionary:
		var out: Dictionary = {}
		for k in value:
			var v = value[k]
			if v is Dictionary or v is Array:
				out[str(k)] = _sanitize(v, depth + 1)
			else:
				out[str(k)] = _sanitize_value(v)
		return out
	if value is Array:
		var out: Array = []
		for item in value:
			if item is Dictionary or item is Array:
				out.append(_sanitize(item, depth + 1))
			else:
				out.append(_sanitize_value(item))
		return out
	return str(value)


# Override network send to sanitize all outgoing messages
func _safe_send(player_id: int, message: Dictionary) -> void:
	network.send_to_player(player_id, message)


func _safe_broadcast(message: Dictionary) -> void:
	network.broadcast(message)


func _safe_broadcast_except(exclude_id: int, message: Dictionary) -> void:
	network.broadcast_except(exclude_id, message)


# -------------------------------------------------------------
# PROCESS - handle graceful shutdown
# -------------------------------------------------------------
func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_CLOSE_REQUEST or what == NOTIFICATION_CRASH:
		print("Server shutting down - saving world...")
		if simulation:
			simulation.save_world()
		print("Goodbye.")
