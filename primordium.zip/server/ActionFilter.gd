class_name ActionFilter

# =============================================================
# ACTION FILTER
# Server-side. Given a unit, a target tile, and the player's
# current state, returns the list of valid action ids.
# This is the authoritative check — client never decides validity.
# =============================================================


# Main entry point.
# unit        - full unit dictionary from WorldSimulation.units
# target_tile - full tile dictionary from WorldMap (the tile being right-clicked)
# target_x/y  - coordinates of target tile
# player      - full player dictionary from WorldSimulation.players
# cities      - WorldSimulation.cities (for building checks)
# world_map   - WorldMap node (for adjacency checks)
# Returns Array of action id strings.
static func get_valid_actions(
		unit: Dictionary,
		target_tile: Dictionary,
		target_x: int,
		target_y: int,
		player: Dictionary,
		cities: Dictionary,
		world_map: Object) -> Array:

	var valid: Array = []
	var unit_type   = unit.get("type", "")
	var unit_status = unit.get("status", "idle")
	var unit_x      = unit.get("x", -1)
	var unit_y      = unit.get("y", -1)

	for action_id in ActionRegistry.ACTIONS:
		var action = ActionRegistry.ACTIONS[action_id]

		# Unit type check
		if unit_type not in action["unit_types"]:
			continue

		# Status block check — skip if unit is in a blocked status
		# Exception: cancel_move only valid WHEN moving
		# Exception: found_city always shows (settler walks there then founds)
		if action_id == "cancel_move":
			if unit_status != "moving":
				continue
		elif action_id != "found_city":
			if unit_status in action.get("not_if_status", []):
				continue

		# Tech requirement
		var req_tech = action.get("requires_tech", "")
		if req_tech != "" and not _player_has_tech(player, req_tech):
			continue

		# Building requirement — check nearest owned city
		var req_building = action.get("requires_building", "")
		if req_building != "" and not _player_has_building(player, cities, unit_x, unit_y, req_building):
			continue

		# Tile conditions
		var target = action.get("target", "tile")
		var check_tile: Dictionary
		var check_x: int
		var check_y: int

		if target == "self":
			# "self" actions check the CLICKED tile (settler walks there to execute)
			# If clicking the unit's own tile, check that tile; otherwise check target
			check_tile = target_tile
			check_x    = target_x
			check_y    = target_y
		else:
			check_tile = target_tile
			check_x    = target_x
			check_y    = target_y

		if not _check_tile_conditions(action["tile_conditions"], check_tile,
				check_x, check_y, player, world_map):
			continue

		valid.append(action_id)

	return valid


# ------------------------------------------------------------------
# CONDITION CHECKERS
# ------------------------------------------------------------------
static func _check_tile_conditions(
		conditions: Array,
		tile: Dictionary,
		tx: int, ty: int,
		player: Dictionary,
		world_map: Object) -> bool:

	if tile.is_empty() and conditions.size() > 0:
		return false

	for cond in conditions:
		if not _check_condition(cond, tile, tx, ty, player, world_map):
			return false
	return true


static func _check_condition(
		cond: int,
		tile: Dictionary,
		tx: int, ty: int,
		player: Dictionary,
		world_map: Object) -> bool:

	var improvement = int(tile.get("improvement", TileTypes.Improvement.NONE))
	var tile_type   = int(tile.get("type", TileTypes.Type.GRASSLAND))
	var tile_data   = TileTypes.TILE_RESOURCES.get(tile_type, {})
	var allowed     = tile_data.get("improvements_allowed", [])
	var player_id   = player.get("id", -1)

	match cond:
		ActionRegistry.TileCondition.IS_PASSABLE:
			return tile.get("passable", false)

		ActionRegistry.TileCondition.HAS_WATER_YIELD:
			return tile_data.get("water_yield", 0.0) > 0.0

		ActionRegistry.TileCondition.NO_IMPROVEMENT:
			return improvement == TileTypes.Improvement.NONE

		ActionRegistry.TileCondition.NO_WELL:
			return improvement != TileTypes.Improvement.WELL

		ActionRegistry.TileCondition.NO_FARM:
			return improvement != TileTypes.Improvement.FARM

		ActionRegistry.TileCondition.NO_LUMBER_CAMP:
			return improvement != TileTypes.Improvement.LUMBER_CAMP

		ActionRegistry.TileCondition.NO_MINE:
			return improvement != TileTypes.Improvement.MINE

		ActionRegistry.TileCondition.NO_ROAD:
			return improvement != TileTypes.Improvement.ROAD

		ActionRegistry.TileCondition.ALLOWS_FARM:
			return TileTypes.Improvement.FARM in allowed

		ActionRegistry.TileCondition.ALLOWS_LUMBER_CAMP:
			return TileTypes.Improvement.LUMBER_CAMP in allowed

		ActionRegistry.TileCondition.ALLOWS_MINE:
			return TileTypes.Improvement.MINE in allowed

		ActionRegistry.TileCondition.ALLOWS_WELL:
			return TileTypes.Improvement.WELL in allowed

		ActionRegistry.TileCondition.ALLOWS_FISHING_HUT:
			return TileTypes.Improvement.FISHING_HUT in allowed

		ActionRegistry.TileCondition.ALLOWS_ROAD:
			return TileTypes.Improvement.ROAD in allowed

		ActionRegistry.TileCondition.ALLOWS_FORT:
			return TileTypes.Improvement.FORT in allowed

		ActionRegistry.TileCondition.ALLOWS_WATCHTOWER:
			return TileTypes.Improvement.WATCHTOWER in allowed

		ActionRegistry.TileCondition.IS_OWNED_BY_PLAYER:
			return tile.get("owner", -1) == player_id

		ActionRegistry.TileCondition.NOT_CITY_TILE:
			return tile.get("city_id", -1) < 0

		ActionRegistry.TileCondition.ADJACENT_TO_RIVER:
			return _has_adjacent_river(tx, ty, world_map)

	return true


static func _has_adjacent_river(tx: int, ty: int, world_map: Object) -> bool:
	var neighbors = [
		Vector2i(tx + 1, ty), Vector2i(tx - 1, ty),
		Vector2i(tx, ty + 1), Vector2i(tx, ty - 1)
	]
	for n in neighbors:
		var t = world_map.get_tile(n.x, n.y)
		if not t.is_empty() and int(t.get("type", -1)) == TileTypes.Type.RIVER:
			return true
	return false


# ------------------------------------------------------------------
# PLAYER STATE CHECKS
# ------------------------------------------------------------------
static func _player_has_tech(player: Dictionary, tech_id: String) -> bool:
	var techs = player.get("techs", [])
	return tech_id in techs


static func _player_has_building(
		player: Dictionary,
		cities: Dictionary,
		unit_x: int, unit_y: int,
		building_id: String) -> bool:
	# Check if any city owned by the player has this building
	# Prefer nearby cities but accept any (can refine later)
	var player_id = player.get("id", -1)
	for city_id in cities:
		var city = cities[city_id]
		if city.get("owner", -1) != player_id:
			continue
		if building_id in city.get("buildings", []):
			return true
	return false
