class_name NetworkServer
extends Node

# =============================================================
# NETWORK SERVER
# Raw WebSocket server using TCPServer + WebSocketPeer per client.
# Sends and receives plain UTF-8 JSON text frames.
# =============================================================


signal player_connected(player_id: int, player_name: String)
signal player_disconnected(player_id: int)
signal message_received(player_id: int, message: Dictionary)


var _tcp_server: TCPServer
var _peers: Dictionary       = {}  # peer_id -> { ws, player_id, player_name, state }
var _player_to_peer: Dictionary = {} # player_id -> peer_id
var _next_peer_id: int   = 1
var _next_player_id: int = 1
var _port: int           = GameConstants.SERVER_PORT

var _heartbeat_timer: float = 0.0


# -------------------------------------------------------------
# START
# -------------------------------------------------------------
func start(port: int) -> void:
	_port       = port
	_tcp_server = TCPServer.new()
	var err     = _tcp_server.listen(port)
	if err != OK:
		push_error("Failed to start TCP server on port " + str(port))
		return
	print("NetworkServer listening on port ", port)


# -------------------------------------------------------------
# PROCESS
# -------------------------------------------------------------
func _process(delta: float) -> void:
	if not _tcp_server:
		return

	# Accept new TCP connections and wrap as WebSocket peers
	while _tcp_server.is_connection_available():
		var tcp  = _tcp_server.take_connection()
		var ws   = WebSocketPeer.new()
		var err  = ws.accept_stream(tcp)
		if err != OK:
			push_warning("Failed to accept WebSocket connection")
			continue
		var peer_id = _next_peer_id
		_next_peer_id += 1
		_peers[peer_id] = {
			"ws":          ws,
			"player_id":   -1,
			"player_name": "",
			"state":       WebSocketPeer.STATE_CONNECTING
		}

	# Poll all peers and read packets
	var to_remove: Array = []
	for peer_id in _peers:
		var entry = _peers[peer_id]
		var ws: WebSocketPeer = entry["ws"]
		ws.poll()

		var new_state = ws.get_ready_state()
		if new_state != entry["state"]:
			entry["state"] = new_state
			if new_state == WebSocketPeer.STATE_OPEN:
				print("Peer connected: ", peer_id)
			elif new_state == WebSocketPeer.STATE_CLOSED:
				to_remove.append(peer_id)
				continue

		while ws.get_available_packet_count() > 0:
			var packet = ws.get_packet()
			var text   = packet.get_string_from_utf8()
			if text.is_empty():
				continue
			_handle_text(peer_id, text)

	for peer_id in to_remove:
		_handle_peer_closed(peer_id)

	# Heartbeat
	_heartbeat_timer += delta
	if _heartbeat_timer >= GameConstants.HEARTBEAT_INTERVAL:
		_heartbeat_timer = 0.0
		_send_heartbeat()


# -------------------------------------------------------------
# PEER EVENTS
# -------------------------------------------------------------
func _handle_peer_closed(peer_id: int) -> void:
	print("Peer disconnected: ", peer_id)
	if _peers.has(peer_id):
		var player_id = _peers[peer_id]["player_id"]
		_peers.erase(peer_id)
		if player_id >= 0:
			_player_to_peer.erase(player_id)
			emit_signal("player_disconnected", player_id)


# -------------------------------------------------------------
# PACKET HANDLING
# -------------------------------------------------------------
func _handle_text(peer_id: int, text: String) -> void:
	var json = JSON.new()
	var err  = json.parse(text)
	if err != OK:
		push_warning("Malformed packet from peer ", peer_id)
		return

	var message = json.get_data()
	if not message is Dictionary:
		return

	var msg_type = message.get("type", "")

	if msg_type == "handshake":
		_handle_handshake(peer_id, message)
		return

	if _peers[peer_id]["player_id"] < 0:
		return

	var player_id = _peers[peer_id]["player_id"]
	emit_signal("message_received", player_id, message)


func _handle_handshake(peer_id: int, message: Dictionary) -> void:
	var player_name  = message.get("name", "Player")
	var reconnect_id = message.get("player_id", -1)

	var player_id: int
	if reconnect_id > 0 and reconnect_id < _next_player_id:
		player_id = reconnect_id
	else:
		player_id = _next_player_id
		_next_player_id += 1

	_peers[peer_id]["player_id"]   = player_id
	_peers[peer_id]["player_name"] = player_name
	_player_to_peer[player_id]     = peer_id

	_send_to_peer(peer_id, {
		"type":      "handshake_ack",
		"player_id": player_id,
		"name":      player_name
	})

	emit_signal("player_connected", player_id, player_name)


# -------------------------------------------------------------
# SENDING
# -------------------------------------------------------------
func send_to_player(player_id: int, message: Dictionary) -> void:
	if not _player_to_peer.has(player_id):
		return
	var text = JSON.stringify(message)
	if not text.is_empty():
		_send_text_to_peer(_player_to_peer[player_id], text)


func broadcast(message: Dictionary) -> void:
	var text = JSON.stringify(message)
	if text.is_empty():
		return
	for peer_id in _peers:
		_send_text_to_peer(peer_id, text)


func broadcast_except(exclude_player_id: int, message: Dictionary) -> void:
	var text = JSON.stringify(message)
	if text.is_empty():
		return
	for peer_id in _peers:
		if _peers[peer_id]["player_id"] != exclude_player_id:
			_send_text_to_peer(peer_id, text)


func _send_to_peer(peer_id: int, message: Dictionary) -> void:
	var text = JSON.stringify(message)
	if not text.is_empty():
		_send_text_to_peer(peer_id, text)


func _send_text_to_peer(peer_id: int, text: String) -> void:
	if not _peers.has(peer_id):
		return
	var ws: WebSocketPeer = _peers[peer_id]["ws"]
	if ws.get_ready_state() != WebSocketPeer.STATE_OPEN:
		return
	ws.send_text(text)


func _dict_to_text(message: Dictionary) -> String:
	# Use var_to_str as fallback if JSON fails
	var text = JSON.stringify(message)
	if text.is_empty():
		push_warning("JSON.stringify returned empty string")
		return ""
	return text


func _send_heartbeat() -> void:
	if _peers.size() == 0:
		return
	broadcast({"type": "heartbeat", "t": Time.get_ticks_msec()})


# -------------------------------------------------------------
# INFO
# -------------------------------------------------------------
func get_connected_count() -> int:
	return _peers.size()


func get_peer_info(player_id: int) -> Dictionary:
	if not _player_to_peer.has(player_id):
		return {}
	return _peers.get(_player_to_peer[player_id], {})
