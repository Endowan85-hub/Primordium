class_name ActionRegistry

# =============================================================
# ACTION REGISTRY
# Single source of truth for every action a unit can take.
# The UI and server both reference this — UI for labels/icons,
# server for validity checking.
#
# Adding a new action = add one entry here. Nothing else needed.
# =============================================================


# Tile conditions checked by ActionFilter
enum TileCondition {
	NONE,
	IS_PASSABLE,          # Tile can be entered
	HAS_WATER_YIELD,      # tile water_yield > 0
	NO_IMPROVEMENT,       # Tile has no improvement yet
	NO_WELL,              # Tile has no well
	NO_FARM,              # Tile has no farm
	NO_LUMBER_CAMP,       # Tile has no lumber camp
	NO_MINE,              # Tile has no mine
	NO_ROAD,              # Tile has no road
	ALLOWS_FARM,          # Tile type allows farm improvement
	ALLOWS_LUMBER_CAMP,
	ALLOWS_MINE,
	ALLOWS_WELL,
	ALLOWS_FISHING_HUT,
	ALLOWS_ROAD,
	ALLOWS_FORT,
	ALLOWS_WATCHTOWER,
	IS_OWNED_BY_PLAYER,   # Tile is owned by the acting player
	NOT_CITY_TILE,        # Tile has no city on it
	ADJACENT_TO_RIVER,    # One of the 4 neighbors is a river tile
}


# Every possible unit action
# Fields:
#   label            - display text in context menu
#   unit_types       - which unit types can perform this
#   requires_tech    - tech id string, "" = always available
#   requires_building- building id in player's nearest city, "" = no requirement
#   tile_conditions  - Array of TileCondition that must all be true
#   not_if_status    - unit statuses that block this action (e.g. already moving)
#   target           - "tile" (act on clicked tile) or "self" (act on unit's tile)
#   confirm_text     - if set, shows a text input before executing (e.g. city name)
#   category         - groups actions in menu: "move", "build", "special", "combat"

const ACTIONS: Dictionary = {

	# ----------------------------------------------------------
	# MOVEMENT
	# ----------------------------------------------------------
	"move": {
		"label":             "Move Here",
		"unit_types":        ["settler", "worker", "scout", "soldier", "cavalry"],
		"requires_tech":     "",
		"requires_building": "",
		"tile_conditions":   [TileCondition.IS_PASSABLE],
		"not_if_status":     [],
		"target":            "tile",
		"confirm_text":      "",
		"category":          "move",
	},

	"cancel_move": {
		"label":             "Stop",
		"unit_types":        ["settler", "worker", "scout", "soldier", "cavalry"],
		"requires_tech":     "",
		"requires_building": "",
		"tile_conditions":   [],
		"not_if_status":     ["idle"],   # Only show if actually moving
		"target":            "self",
		"confirm_text":      "",
		"category":          "move",
	},

	# ----------------------------------------------------------
	# SETTLER ACTIONS
	# ----------------------------------------------------------
	"found_city": {
		"label":             "Found City Here",
		"unit_types":        ["settler"],
		"requires_tech":     "",
		"requires_building": "",
		"tile_conditions":   [TileCondition.IS_PASSABLE, TileCondition.NOT_CITY_TILE],
		"not_if_status":     ["moving"],
		"target":            "self",     # Acts on tile settler is currently on
		"confirm_text":      "City name",
		"category":          "special",
	},

	# ----------------------------------------------------------
	# WORKER BUILD ACTIONS
	# ----------------------------------------------------------
	"build_farm": {
		"label":             "Build Farm",
		"unit_types":        ["worker"],
		"requires_tech":     "",
		"requires_building": "",
		"tile_conditions":   [TileCondition.ALLOWS_FARM, TileCondition.NO_FARM,
							  TileCondition.IS_OWNED_BY_PLAYER],
		"not_if_status":     ["moving", "building"],
		"target":            "tile",
		"confirm_text":      "",
		"category":          "build",
	},

	"build_lumber_camp": {
		"label":             "Build Lumber Camp",
		"unit_types":        ["worker"],
		"requires_tech":     "",
		"requires_building": "",
		"tile_conditions":   [TileCondition.ALLOWS_LUMBER_CAMP, TileCondition.NO_LUMBER_CAMP,
							  TileCondition.IS_OWNED_BY_PLAYER],
		"not_if_status":     ["moving", "building"],
		"target":            "tile",
		"confirm_text":      "",
		"category":          "build",
	},

	"build_mine": {
		"label":             "Build Mine",
		"unit_types":        ["worker"],
		"requires_tech":     "",
		"requires_building": "",
		"tile_conditions":   [TileCondition.ALLOWS_MINE, TileCondition.NO_MINE,
							  TileCondition.IS_OWNED_BY_PLAYER],
		"not_if_status":     ["moving", "building"],
		"target":            "tile",
		"confirm_text":      "",
		"category":          "build",
	},

	"build_well": {
		"label":             "Build Well",
		"unit_types":        ["worker"],
		"requires_tech":     "",
		"requires_building": "mason",   # Requires mason building in city
		"tile_conditions":   [TileCondition.ALLOWS_WELL, TileCondition.NO_WELL,
							  TileCondition.HAS_WATER_YIELD, TileCondition.IS_OWNED_BY_PLAYER],
		"not_if_status":     ["moving", "building"],
		"target":            "tile",
		"confirm_text":      "",
		"category":          "build",
	},

	"build_fishing_hut": {
		"label":             "Build Fishing Hut",
		"unit_types":        ["worker"],
		"requires_tech":     "",
		"requires_building": "",
		"tile_conditions":   [TileCondition.ALLOWS_FISHING_HUT, TileCondition.NO_IMPROVEMENT,
							  TileCondition.IS_OWNED_BY_PLAYER],
		"not_if_status":     ["moving", "building"],
		"target":            "tile",
		"confirm_text":      "",
		"category":          "build",
	},

	"build_irrigation": {
		"label":             "Build Irrigation",
		"unit_types":        ["worker"],
		"requires_tech":     "agriculture",
		"requires_building": "",
		"tile_conditions":   [TileCondition.ALLOWS_FARM, TileCondition.IS_OWNED_BY_PLAYER,
							  TileCondition.ADJACENT_TO_RIVER],
		"not_if_status":     ["moving", "building"],
		"target":            "tile",
		"confirm_text":      "",
		"category":          "build",
	},

	"build_road": {
		"label":             "Build Road",
		"unit_types":        ["worker"],
		"requires_tech":     "",
		"requires_building": "",
		"tile_conditions":   [TileCondition.ALLOWS_ROAD, TileCondition.NO_ROAD,
							  TileCondition.IS_OWNED_BY_PLAYER],
		"not_if_status":     ["moving", "building"],
		"target":            "tile",
		"confirm_text":      "",
		"category":          "build",
	},

	"build_fort": {
		"label":             "Build Fort",
		"unit_types":        ["worker", "soldier"],
		"requires_tech":     "military_organization",
		"requires_building": "",
		"tile_conditions":   [TileCondition.ALLOWS_FORT, TileCondition.IS_OWNED_BY_PLAYER],
		"not_if_status":     ["moving", "building"],
		"target":            "tile",
		"confirm_text":      "",
		"category":          "build",
	},

	"build_watchtower": {
		"label":             "Build Watchtower",
		"unit_types":        ["worker"],
		"requires_tech":     "",
		"requires_building": "",
		"tile_conditions":   [TileCondition.ALLOWS_WATCHTOWER, TileCondition.IS_OWNED_BY_PLAYER],
		"not_if_status":     ["moving", "building"],
		"target":            "tile",
		"confirm_text":      "",
		"category":          "build",
	},

	# ----------------------------------------------------------
	# SCOUT ACTIONS
	# ----------------------------------------------------------
	"scout_area": {
		"label":             "Scout Area",
		"unit_types":        ["scout"],
		"requires_tech":     "",
		"requires_building": "",
		"tile_conditions":   [TileCondition.IS_PASSABLE],
		"not_if_status":     ["moving"],
		"target":            "tile",
		"confirm_text":      "",
		"category":          "special",
	},

	# ----------------------------------------------------------
	# SOLDIER ACTIONS
	# ----------------------------------------------------------
	"fortify": {
		"label":             "Fortify",
		"unit_types":        ["soldier", "cavalry"],
		"requires_tech":     "",
		"requires_building": "",
		"tile_conditions":   [],
		"not_if_status":     ["moving", "fortified"],
		"target":            "self",
		"confirm_text":      "",
		"category":          "combat",
	},
}


# Returns the display label for an action id
static func get_label(action_id: String) -> String:
	return ACTIONS.get(action_id, {}).get("label", action_id)


# Returns the category for an action id
static func get_category(action_id: String) -> String:
	return ACTIONS.get(action_id, {}).get("category", "move")


# Returns true if this action requires a text confirmation input
static func needs_confirm_text(action_id: String) -> bool:
	return ACTIONS.get(action_id, {}).get("confirm_text", "") != ""


static func get_confirm_prompt(action_id: String) -> String:
	return ACTIONS.get(action_id, {}).get("confirm_text", "")
