class_name ResourceTypes

# =============================================================
# RESOURCE TYPES
# Defines every resource in the game, how it's used,
# and its progression through the tech eras.
# =============================================================


enum ResType {
	# Basic - available from the start
	FOOD,
	WOOD,
	STONE,
	WATER,        # Stored in wells/cisterns - consumed by population and farms

	# Early game - unlocked via early tech
	ORE,          # Smelted into metal - from hills/mountains
	HERBS,        # Medicine - from forests
	CLAY,         # Pottery, later bricks - from river banks

	# Mid game
	METAL,        # Processed ore - requires forge
	COAL,         # Fuel - from hills/mountains
	LEATHER,      # From hunting - requires hunting grounds
	CLOTH,        # From farming fiber crops - requires loom

	# Late game
	GLASS,        # Processed sand/quartz
	STEEL,        # Processed metal + coal
	GUNPOWDER,    # Coal + minerals
	OIL,          # Rare deposit - late industrial

	# Space era (far future)
	SILICON,
	RARE_EARTH,
	FUEL_CELLS
}

# Display names
const RESOURCE_NAMES: Dictionary = {
	ResType.FOOD:       "Food",
	ResType.WOOD:       "Wood",
	ResType.STONE:      "Stone",
	ResType.WATER:      "Water",
	ResType.ORE:        "Ore",
	ResType.HERBS:      "Herbs",
	ResType.CLAY:       "Clay",
	ResType.METAL:      "Metal",
	ResType.COAL:       "Coal",
	ResType.LEATHER:    "Leather",
	ResType.CLOTH:      "Cloth",
	ResType.GLASS:      "Glass",
	ResType.STEEL:      "Steel",
	ResType.GUNPOWDER:  "Gunpowder",
	ResType.OIL:        "Oil",
	ResType.SILICON:    "Silicon",
	ResType.RARE_EARTH: "Rare Earth",
	ResType.FUEL_CELLS: "Fuel Cells"
}

const RESOURCE_VISIBLE_FROM_START: Array = [
	ResType.FOOD,
	ResType.WOOD,
	ResType.STONE,
	ResType.WATER
]

const RESOURCE_ERA: Dictionary = {
	ResType.FOOD:       0,
	ResType.WOOD:       0,
	ResType.STONE:      0,
	ResType.WATER:      0,
	ResType.HERBS:      1,
	ResType.CLAY:       1,
	ResType.ORE:        1,
	ResType.METAL:      2,
	ResType.LEATHER:    2,
	ResType.CLOTH:      2,
	ResType.COAL:       3,
	ResType.GLASS:      3,
	ResType.STEEL:      4,
	ResType.GUNPOWDER:  4,
	ResType.OIL:        5,
	ResType.SILICON:    6,
	ResType.RARE_EARTH: 6,
	ResType.FUEL_CELLS: 6
}

const DEFAULT_STORAGE_CAP: Dictionary = {
	ResType.FOOD:      500.0,
	ResType.WOOD:      300.0,
	ResType.STONE:     300.0,
	ResType.WATER:     100.0,   # Base well capacity — expanded by cistern
	ResType.ORE:       200.0,
	ResType.HERBS:     100.0,
	ResType.CLAY:      150.0,
	ResType.METAL:     150.0,
	ResType.COAL:      200.0,
	ResType.LEATHER:   100.0,
	ResType.CLOTH:     100.0,
	ResType.GLASS:      80.0,
	ResType.STEEL:     100.0,
	ResType.GUNPOWDER:  50.0,
	ResType.OIL:       100.0,
	ResType.SILICON:    80.0,
	ResType.RARE_EARTH: 50.0,
	ResType.FUEL_CELLS: 50.0
}

const SPOILAGE_RATE: Dictionary = {
	ResType.FOOD:    0.002,
	ResType.HERBS:   0.001,
	ResType.LEATHER: 0.0005
	# Water does NOT spoil - stored water stays stored
}

const TRADE_VALUE: Dictionary = {
	ResType.FOOD:       1.0,
	ResType.WOOD:       1.2,
	ResType.STONE:      1.1,
	ResType.WATER:      1.5,    # Valuable in arid regions
	ResType.ORE:        2.0,
	ResType.HERBS:      2.5,
	ResType.CLAY:       1.3,
	ResType.METAL:      3.5,
	ResType.COAL:       2.8,
	ResType.LEATHER:    2.2,
	ResType.CLOTH:      2.4,
	ResType.GLASS:      3.0,
	ResType.STEEL:      5.0,
	ResType.GUNPOWDER:  6.0,
	ResType.OIL:        7.0,
	ResType.SILICON:    10.0,
	ResType.RARE_EARTH: 12.0,
	ResType.FUEL_CELLS: 15.0
}


static func empty_stockpile() -> Dictionary:
	var stockpile: Dictionary = {}
	for res in ResType.values():
		stockpile[res] = 0.0
	return stockpile


static func starting_stockpile() -> Dictionary:
	var stockpile = empty_stockpile()
	stockpile[ResType.FOOD]  = 50.0
	stockpile[ResType.WOOD]  = 30.0
	stockpile[ResType.STONE] = 20.0
	stockpile[ResType.WATER] = 50.0   # Starting water in the well
	return stockpile


static func get_res_name(resource: ResType) -> String:
	return RESOURCE_NAMES.get(resource, "Unknown")
