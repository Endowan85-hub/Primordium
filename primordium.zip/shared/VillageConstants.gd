class_name VillageConstants

# =============================================================
# VILLAGE CONSTANTS  —  shared between client and server
# =============================================================

const VILLAGE_GRID_SIZE:  int = 10
const CENTER_ORIGIN_X:    int = 4
const CENTER_ORIGIN_Y:    int = 4

# Building type IDs  (keep in sync with server _building_* helpers)
const B_NONE:    int = 0
const B_CENTER:  int = 1   # 2x2 Village Center
const B_HUT:     int = 2   # 1x1
const B_FARM:    int = 3   # 2x1
const B_WELL:    int = 4   # 1x1
const B_ROAD:    int = 5   # 1x1
const B_STORE:   int = 6   # 2x2 Storehouse

const BUILDING_NAMES: Dictionary = {
	0: "Empty",
	1: "Village Center",
	2: "Hut",
	3: "Farm",
	4: "Well",
	5: "Road",
	6: "Storehouse",
}

const BUILDING_COSTS: Dictionary = {
	1: { "wood": 0,  "stone": 0  },
	2: { "wood": 5,  "stone": 0  },
	3: { "wood": 3,  "stone": 0  },
	4: { "wood": 0,  "stone": 4  },
	5: { "wood": 1,  "stone": 1  },
	6: { "wood": 10, "stone": 5  },
}

# [width, height]
const BUILDING_SIZE: Dictionary = {
	1: [2, 2],
	2: [1, 1],
	3: [2, 1],
	4: [1, 1],
	5: [1, 1],
	6: [2, 2],
}

const BUILDING_BUILD_TICKS: Dictionary = {
	1: 0,
	2: 30,
	3: 40,
	4: 50,
	5: 10,
	6: 80,
}

const BUILDING_POP_CAP: Dictionary = {
	2: 2,   # Hut
}

const BUILDING_RESOURCE_CAP: Dictionary = {
	6: { "food": 300, "wood": 200, "stone": 200 },   # Storehouse
}

const BUILDING_COLORS: Dictionary = {
	1: Color(0.6, 0.4, 0.2),
	2: Color(0.7, 0.55, 0.3),
	3: Color(0.5, 0.75, 0.3),
	4: Color(0.3, 0.6, 0.9),
	5: Color(0.55, 0.5, 0.45),
	6: Color(0.6, 0.5, 0.35),
}

const FARM_FOOD_PER_FARMER:  float = 0.8
const WELL_WATER_PER_TICK:   float = 0.5
const FARM_WELL_BONUS:       float = 0.25
const VILLAGER_WALK_SPEED:   float = 1.8
