class_name WorldMap
extends Node

# =============================================================
# WORLD MAP
# 200x200 tile grid. Handles procedural generation, resource
# pools, depletion, recovery, and tile improvements.
# Runs on the server. Clients receive tile data as needed.
# =============================================================


# -------------------------------------------------------------
# TILE DATA STRUCTURE
# Each tile is a Dictionary stored in _tiles array:
# {
#   "type":        TileTypes.Type      - terrain type
#   "resources":   Dictionary          - current resource amounts keyed by resource name
#   "improvement": TileTypes.Improvement
#   "owner":       int                 - player_id or -1 if unclaimed
#   "city_id":     int                 - city_id or -1
#   "worked_by":   int                 - player_id currently harvesting, or -1
#   "build_progress": float            - ticks remaining on improvement under construction
#   "building_improvement": TileTypes.Improvement - what's being built
#   "depletion_state": TileTypes.DepletionState
#   "passable":    bool                - can units move through
# }
# -------------------------------------------------------------

var _tiles: Array = []          # Flat array, index = y * MAP_WIDTH + x
var _width: int = 0
var _height: int = 0
var _seed: int = 0

# Noise generators for procedural generation
var _elevation_noise: FastNoiseLite
var _moisture_noise: FastNoiseLite
var _resource_noise: FastNoiseLite


# -------------------------------------------------------------
# SIGNALS (server emits these, clients listen)
# -------------------------------------------------------------
signal tile_changed(x: int, y: int, tile_data: Dictionary)
signal resource_depleted(x: int, y: int, resource: String)
signal improvement_completed(x: int, y: int, improvement: int)


# -------------------------------------------------------------
# INIT
# -------------------------------------------------------------
func initialize(world_seed: int) -> void:
	_width  = GameConstants.MAP_WIDTH
	_height = GameConstants.MAP_HEIGHT
	_seed   = world_seed

	_setup_noise(world_seed)
	_generate_tiles()
	print("WorldMap initialized: ", _width, "x", _height, " | seed: ", world_seed)


func _setup_noise(world_seed: int) -> void:
	_elevation_noise = FastNoiseLite.new()
	_elevation_noise.seed = world_seed
	_elevation_noise.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
	_elevation_noise.frequency = 0.008
	_elevation_noise.fractal_octaves = 5
	_elevation_noise.fractal_gain = 0.5
	_elevation_noise.fractal_lacunarity = 2.0

	_moisture_noise = FastNoiseLite.new()
	_moisture_noise.seed = world_seed + 1000
	_moisture_noise.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
	_moisture_noise.frequency = 0.012
	_moisture_noise.fractal_octaves = 4

	_resource_noise = FastNoiseLite.new()
	_resource_noise.seed = world_seed + 2000
	_resource_noise.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
	_resource_noise.frequency = 0.02
	_resource_noise.fractal_octaves = 3


# -------------------------------------------------------------
# PROCEDURAL GENERATION
# Uses elevation + moisture to determine tile type, then
# populates resource pools based on tile type.
# Elevation:  -1.0 (deep water) to 1.0 (high mountain)
# Moisture:   -1.0 (dry) to 1.0 (wet)
# -------------------------------------------------------------
func _generate_tiles() -> void:
	_tiles.clear()
	_tiles.resize(_width * _height)

	for y in range(_height):
		for x in range(_width):
			var tile = _generate_tile(x, y)
			_tiles[y * _width + x] = tile

	# Smooth elevation so no two neighbors differ by more than 1.
	# Repeat several passes until stable — prevents staircase cliffs.
	_smooth_elevation(4)

	# Remove isolated biome outliers — any tile whose type disagrees
	# with all 4 neighbors gets replaced by the majority neighbor type.
	# Run 2 passes to catch clusters of 2-3 stray tiles as well.
	_smooth_biomes(2)


func _generate_tile(x: int, y: int) -> Dictionary:
	var elev     = _elevation_noise.get_noise_2d(float(x), float(y))
	var moisture = _moisture_noise.get_noise_2d(float(x), float(y))
	var res_val  = _resource_noise.get_noise_2d(float(x), float(y))

	# Fade edges toward ocean to create natural coastlines
	var edge_fade = _get_edge_fade(x, y)
	elev = elev * edge_fade - (1.0 - edge_fade) * 0.5

	var tile_type = _elevation_moisture_to_type(elev, moisture)
	var resources = _generate_resources(tile_type, res_val)

	# Scale elevation from -1..1 noise to 0..8 integer levels
	# This is stored per-tile and smoothed after generation
	var elev_clamped = clamp(elev, -1.0, 1.0)
	var elev_level   = int((elev_clamped + 1.0) / 2.0 * 8.0)

	return {
		"type":                 tile_type,
		"elevation":            elev_level,
		"resources":            resources,
		"improvement":          TileTypes.Improvement.NONE,
		"owner":                -1,
		"city_id":              -1,
		"worked_by":            -1,
		"build_progress":       0.0,
		"building_improvement": TileTypes.Improvement.NONE,
		"depletion_state":      TileTypes.DepletionState.FULL,
		"passable":             tile_type != TileTypes.Type.OCEAN and tile_type != TileTypes.Type.MOUNTAIN
	}


# Iterative elevation smoothing.
# Each pass: if any neighbor differs by more than 1, lower the higher tile.
# Running multiple passes propagates smoothing across wide cliff bands.
func _smooth_elevation(passes: int) -> void:
	for _pass in range(passes):
		var changed = false
		for y in range(_height):
			for x in range(_width):
				var idx  = y * _width + x
				var tile = _tiles[idx]
				if tile == null:
					continue
				var my_elev: int = tile.get("elevation", 0)
				# Check 4 orthogonal neighbors
				var neighbors = [
					Vector2i(x - 1, y), Vector2i(x + 1, y),
					Vector2i(x, y - 1), Vector2i(x, y + 1)
				]
				for nb in neighbors:
					if nb.x < 0 or nb.x >= _width or nb.y < 0 or nb.y >= _height:
						continue
					var nb_tile = _tiles[nb.y * _width + nb.x]
					if nb_tile == null:
						continue
					var nb_elev: int = nb_tile.get("elevation", 0)
					# If we are more than 1 above a neighbor, drop down to neighbor + 1
					if my_elev - nb_elev > 1:
						my_elev = nb_elev + 1
						changed = true
				tile["elevation"] = my_elev
		if not changed:
			break  # Stable — early exit


# Biome smoothing — removes isolated tile-type outliers.
# Rules:
#   1. If a tile is completely surrounded by a different type, absorb it.
#   2. Cold biomes (tundra, snow) are never allowed next to warm biomes
#      (grassland, forest, desert) without a mountain or hills buffer.
# This runs AFTER elevation smoothing so elevation data is already set.
func _smooth_biomes(passes: int) -> void:
	# Biomes that count as "cold" — only valid near other cold/high tiles
	var cold_types = [
		TileTypes.Type.TUNDRA,
		TileTypes.Type.SNOW,
		TileTypes.Type.MOUNTAIN,
	]
	# Biomes that count as "warm flat"
	var warm_flat = [
		TileTypes.Type.GRASSLAND,
		TileTypes.Type.FOREST,
		TileTypes.Type.DESERT,
		TileTypes.Type.RIVER,
		TileTypes.Type.COASTAL,
		TileTypes.Type.OCEAN,
	]
	var nb_offsets = [Vector2i(-1,0), Vector2i(1,0), Vector2i(0,-1), Vector2i(0,1)]

	for _pass in range(passes):
		for y in range(_height):
			for x in range(_width):
				var idx  = y * _width + x
				var tile = _tiles[idx]
				if tile == null:
					continue
				var my_type: int = tile.get("type", TileTypes.Type.GRASSLAND)

				# Collect neighbor types
				var nb_types: Array[int] = []
				for off in nb_offsets:
					var nx = x + off.x
					var ny = y + off.y
					if nx < 0 or nx >= _width or ny < 0 or ny >= _height:
						continue
					var nb = _tiles[ny * _width + nx]
					if nb != null:
						nb_types.append(int(nb.get("type", TileTypes.Type.GRASSLAND)))

				if nb_types.is_empty():
					continue

				# Rule 1: Cold tile directly adjacent to warm flat — replace cold
				# with hills (transition buffer) unless elevation is genuinely high
				if cold_types.has(my_type):
					var elev: int = tile.get("elevation", 0)
					var warm_neighbor_count = 0
					for nt in nb_types:
						if warm_flat.has(nt):
							warm_neighbor_count += 1
					# If more than half neighbors are warm AND elevation is low,
					# this cold tile is stranded — convert to hills as buffer
					if warm_neighbor_count > nb_types.size() / 2 and elev < 4:
						tile["type"] = TileTypes.Type.HILLS
						continue

				# Rule 2: Majority vote — if all neighbors are the same type
				# and it differs from ours, absorb (removes single-tile specks)
				var type_counts: Dictionary = {}
				for nt in nb_types:
					type_counts[nt] = type_counts.get(nt, 0) + 1
				# Find most common neighbor type
				var dominant_type = my_type
				var dominant_count = 0
				for nt in type_counts:
					if type_counts[nt] > dominant_count:
						dominant_count = type_counts[nt]
						dominant_type = nt
				# If ALL neighbors agree on one type and it isn't ours — absorb
				if dominant_count == nb_types.size() and dominant_type != my_type:
					# Don't absorb water tiles — coastlines should stay sharp
					if my_type != TileTypes.Type.OCEAN and my_type != TileTypes.Type.COASTAL:
						tile["type"] = dominant_type


func _get_edge_fade(x: int, y: int) -> float:
	# Returns 1.0 in the center, fades to 0.0 at edges
	# Creates natural ocean borders
	var margin = 15.0
	var fx = min(x, _width  - 1 - x) / margin
	var fy = min(y, _height - 1 - y) / margin
	return clamp(min(fx, fy), 0.0, 1.0)


func _elevation_moisture_to_type(elev: float, moisture: float) -> TileTypes.Type:
	# ── Water ──────────────────────────────────────────────────
	if elev < -0.3:
		return TileTypes.Type.OCEAN
	if elev < -0.1:
		return TileTypes.Type.COASTAL
	# Rivers only at very low elevation with high moisture
	if elev < 0.05 and moisture > 0.5:
		return TileTypes.Type.RIVER

	# ── High elevation — cold biomes ───────────────────────────
	# Snow only at genuine peaks
	if elev > 0.70:
		return TileTypes.Type.SNOW
	# Mountains just below snow line
	if elev > 0.52:
		return TileTypes.Type.MOUNTAIN
	# Tundra: high elevation AND dry — cold mountain fringe
	# NOT allowed below elev 0.42 so it never appears in flat grassland
	if elev > 0.42 and moisture < -0.15:
		return TileTypes.Type.TUNDRA
	# Hills: medium-high elevation regardless of moisture
	if elev > 0.28:
		return TileTypes.Type.HILLS

	# ── Low/mid elevation — warm biomes ────────────────────────
	# Desert: dry and not mountainous
	if moisture < -0.35 and elev > -0.05:
		return TileTypes.Type.DESERT
	# Forest: moist and above sea level
	if moisture > 0.15 and elev > 0.0:
		return TileTypes.Type.FOREST
	# Default: grassland (flat, moderate moisture)
	return TileTypes.Type.GRASSLAND


func _generate_resources(tile_type: TileTypes.Type, variation: float) -> Dictionary:
	var res: Dictionary = {}
	var data = TileTypes.TILE_RESOURCES.get(tile_type, {})
	var max_vals = data.get("max", {})

	# variation is -1.0 to 1.0, remap to 0.7 to 1.3 for resource scaling
	var scale = 1.0 + (variation * 0.3)

	for resource_key in max_vals:
		var max_val = max_vals[resource_key] * scale
		# Start tiles at 80-100% full
		var start_pct = 0.8 + (randf() * 0.2)
		res[resource_key] = max_val * start_pct
		# Store the scaled max too
		res[resource_key + "_max"] = max_val

	return res


# -------------------------------------------------------------
# TICK
# Called every server tick. Processes resource recovery,
# active harvesting, and improvement construction.
# -------------------------------------------------------------
func tick(season: String) -> void:
	var season_mods = GameConstants.SEASON_MODIFIERS.get(season, {})

	for i in range(_tiles.size()):
		var tile = _tiles[i]
		_tick_tile(tile, season_mods)


func _tick_tile(tile: Dictionary, season_mods: Dictionary) -> void:
	var data = TileTypes.TILE_RESOURCES.get(tile["type"], {})
	var recovery_rates = data.get("recovery_rate", {})
	var improvement = tile["improvement"]
	var imp_effects = TileTypes.IMPROVEMENT_EFFECTS.get(improvement, {})

	for resource_key in tile["resources"]:
		# Skip _max entries
		if resource_key.ends_with("_max"):
			continue

		var max_key = resource_key + "_max"
		var current = tile["resources"][resource_key]
		var max_val  = tile["resources"].get(max_key, 0.0)

		if current >= max_val:
			continue

		# Base recovery rate
		var base_recovery = recovery_rates.get(resource_key, 0.0)

		# Apply improvement recovery multiplier
		var rec_mult = imp_effects.get("recovery_multiplier", {})
		var recovery = base_recovery * rec_mult.get(resource_key, 1.0)

		# Apply season modifier
		if resource_key == "food":
			recovery *= season_mods.get("food", 1.0)
		elif resource_key == "wood":
			recovery *= season_mods.get("wood", 1.0)

		# Only recover if not being actively worked
		if tile["worked_by"] == -1:
			tile["resources"][resource_key] = min(current + recovery, max_val)

	# Update depletion state for primary resource
	var primary = data.get("primary", "")
	if primary != "" and tile["resources"].has(primary):
		var current = tile["resources"][primary]
		var max_val  = tile["resources"].get(primary + "_max", 1.0)
		tile["depletion_state"] = TileTypes.get_depletion_state(current, max_val)

	# Tick improvement construction
	if tile["build_progress"] > 0.0:
		tile["build_progress"] -= 1.0
		if tile["build_progress"] <= 0.0:
			tile["improvement"] = tile["building_improvement"]
			tile["building_improvement"] = TileTypes.Improvement.NONE
			var idx = _tiles.find(tile)
			if idx >= 0:
				var x = idx % _width
				var y: int = idx / _width
				emit_signal("improvement_completed", x, y, tile["improvement"])


# -------------------------------------------------------------
# HARVESTING
# Called when a worker is assigned to a tile.
# Returns the amount harvested this tick.
# -------------------------------------------------------------
func harvest_tile(x: int, y: int, resource_key: String, worker_count: int, season: String) -> float:
	var tile = get_tile(x, y)
	if tile == null:
		return 0.0

	var data = TileTypes.TILE_RESOURCES.get(tile["type"], {})
	var harvest_rates = data.get("harvest_rate", {})
	var base_rate = harvest_rates.get(resource_key, 0.0)

	if base_rate == 0.0:
		return 0.0

	# Apply improvement harvest multiplier
	var imp_effects = TileTypes.IMPROVEMENT_EFFECTS.get(tile["improvement"], {})
	var harv_mult = imp_effects.get("harvest_multiplier", {})
	var rate = base_rate * harv_mult.get(resource_key, 1.0)

	# Apply season modifier
	var season_mods = GameConstants.SEASON_MODIFIERS.get(season, {})
	if resource_key == "food":
		rate *= season_mods.get("food", 1.0)
	elif resource_key == "wood":
		rate *= season_mods.get("wood", 1.0)

	# Scale by worker count (diminishing returns after 3 workers)
	var worker_scale = min(float(worker_count), 3.0) + max(0.0, float(worker_count) - 3.0) * 0.3
	rate *= worker_scale

	# Clamp to what's available
	var available = tile["resources"].get(resource_key, 0.0)
	var harvested  = min(rate, available)

	tile["resources"][resource_key] = available - harvested

	# Check depletion
	var max_val = tile["resources"].get(resource_key + "_max", 1.0)
	var new_state = TileTypes.get_depletion_state(tile["resources"][resource_key], max_val)
	if new_state != tile["depletion_state"]:
		tile["depletion_state"] = new_state
		emit_signal("tile_changed", x, y, tile)
		if new_state == TileTypes.DepletionState.EMPTY:
			emit_signal("resource_depleted", x, y, resource_key)

	return harvested


# -------------------------------------------------------------
# IMPROVEMENTS
# -------------------------------------------------------------
func start_improvement(x: int, y: int, improvement: TileTypes.Improvement) -> bool:
	var tile = get_tile(x, y)
	if tile == null:
		return false
	if not TileTypes.can_build_improvement(tile["type"], improvement):
		return false
	if tile["build_progress"] > 0.0:
		return false  # Already building something

	var effect = TileTypes.IMPROVEMENT_EFFECTS.get(improvement, {})
	tile["building_improvement"] = improvement
	tile["build_progress"] = float(effect.get("build_time_ticks", 10))
	emit_signal("tile_changed", x, y, tile)
	return true


func cancel_improvement(x: int, y: int) -> void:
	var tile = get_tile(x, y)
	if tile == null:
		return
	tile["build_progress"] = 0.0
	tile["building_improvement"] = TileTypes.Improvement.NONE
	emit_signal("tile_changed", x, y, tile)


# -------------------------------------------------------------
# OWNERSHIP
# -------------------------------------------------------------
func claim_tile(x: int, y: int, player_id: int, city_id: int) -> void:
	var tile = get_tile(x, y)
	if tile == null:
		return
	tile["owner"]   = player_id
	tile["city_id"] = city_id
	emit_signal("tile_changed", x, y, tile)


func unclaim_tile(x: int, y: int) -> void:
	var tile = get_tile(x, y)
	if tile == null:
		return
	tile["owner"]   = -1
	tile["city_id"] = -1
	emit_signal("tile_changed", x, y, tile)


func set_worked_by(x: int, y: int, player_id: int) -> void:
	var tile = get_tile(x, y)
	if tile == null:
		return
	tile["worked_by"] = player_id


# -------------------------------------------------------------
# TERRITORY — claim all tiles within radius of a city
# -------------------------------------------------------------
func claim_territory(center_x: int, center_y: int, radius: int,
		player_id: int, city_id: int) -> void:
	for dy in range(-radius, radius + 1):
		for dx in range(-radius, radius + 1):
			if dx * dx + dy * dy <= radius * radius:
				var tx = center_x + dx
				var ty = center_y + dy
				if is_valid(tx, ty):
					var tile = get_tile(tx, ty)
					if tile["owner"] == -1:
						claim_tile(tx, ty, player_id, city_id)


# -------------------------------------------------------------
# VALID SPAWN SEARCH
# Finds a good starting tile for a settler — grassland or
# river, not too close to other players, within margin.
# -------------------------------------------------------------
func find_spawn_tile(existing_cities: Array) -> Vector2i:
	var margin = GameConstants.SPAWN_MARGIN
	var attempts = 0

	while attempts < 500:
		var x: int = margin + randi() % (_width  - margin * 2)
		var y: int = margin + randi() % (_height - margin * 2)
		var tile = get_tile(x, y)

		if tile == null:
			attempts += 1
			continue

		# Must be grassland or river to settle
		var good_type = tile["type"] == TileTypes.Type.GRASSLAND or \
						tile["type"] == TileTypes.Type.RIVER

		if not good_type:
			attempts += 1
			continue

		# Must be unclaimed
		if tile["owner"] != -1:
			attempts += 1
			continue

		# Must be far enough from other cities
		var too_close = false
		for city_pos in existing_cities:
			var dist = abs(x - city_pos.x) + abs(y - city_pos.y)
			if dist < 20:
				too_close = true
				break

		if not too_close:
			return Vector2i(x, y)

		attempts += 1

	# Fallback — return center if nothing found
	return Vector2i(_width / 2, _height / 2)


# -------------------------------------------------------------
# ADJACENCY HELPERS
# -------------------------------------------------------------
func get_neighbors(x: int, y: int) -> Array:
	var neighbors: Array = []
	var offsets = [
		Vector2i(0, -1), Vector2i(0, 1),
		Vector2i(-1, 0), Vector2i(1, 0)
	]
	for offset in offsets:
		var nx = x + offset.x
		var ny = y + offset.y
		if is_valid(nx, ny):
			neighbors.append(Vector2i(nx, ny))
	return neighbors


func has_adjacent_type(x: int, y: int, tile_type: TileTypes.Type) -> bool:
	for neighbor in get_neighbors(x, y):
		var tile = get_tile(neighbor.x, neighbor.y)
		if tile and tile["type"] == tile_type:
			return true
	return false


# -------------------------------------------------------------
# SERIALIZATION — save/load world state
# -------------------------------------------------------------
func serialize() -> Dictionary:
	var data: Array = []
	for tile in _tiles:
		data.append({
			"t":  tile["type"],
			"r":  tile["resources"],
			"i":  tile["improvement"],
			"o":  tile["owner"],
			"c":  tile["city_id"],
			"w":  tile["worked_by"],
			"bp": tile["build_progress"],
			"bi": tile["building_improvement"],
			"ds": tile["depletion_state"],
			"p":  tile["passable"]
		})
	return {
		"width":  _width,
		"height": _height,
		"seed":   _seed,
		"tiles":  data
	}


func deserialize(data: Dictionary) -> void:
	_width  = data.get("width",  GameConstants.MAP_WIDTH)
	_height = data.get("height", GameConstants.MAP_HEIGHT)
	_seed   = data.get("seed",   0)
	_tiles.clear()

	for td in data.get("tiles", []):
		_tiles.append({
			"type":                 td.get("t",  TileTypes.Type.GRASSLAND),
			"resources":            td.get("r",  {}),
			"improvement":          td.get("i",  TileTypes.Improvement.NONE),
			"owner":                td.get("o",  -1),
			"city_id":              td.get("c",  -1),
			"worked_by":            td.get("w",  -1),
			"build_progress":       td.get("bp", 0.0),
			"building_improvement": td.get("bi", TileTypes.Improvement.NONE),
			"depletion_state":      td.get("ds", TileTypes.DepletionState.FULL),
			"passable":             td.get("p",  true)
		})


# -------------------------------------------------------------
# GETTERS
# -------------------------------------------------------------
func get_tile(x: int, y: int) -> Dictionary:
	if not is_valid(x, y):
		return {}
	return _tiles[y * _width + x]


func is_valid(x: int, y: int) -> bool:
	return x >= 0 and x < _width and y >= 0 and y < _height


func get_width() -> int:
	return _width


func get_height() -> int:
	return _height


func get_seed() -> int:
	return _seed


# Returns a chunk of tiles for sending to a client
# Used for fog of war — only send what the player can see
func get_tile_chunk(tiles_coords: Array) -> Dictionary:
	var chunk: Dictionary = {}
	for coord in tiles_coords:
		var key = str(coord.x) + "," + str(coord.y)
		var tile = get_tile(coord.x, coord.y)
		if tile:
			chunk[key] = tile
	return chunk


# Returns all tiles in a radius around a point
func get_tiles_in_radius(cx: int, cy: int, radius: int) -> Array:
	var result: Array = []
	for dy in range(-radius, radius + 1):
		for dx in range(-radius, radius + 1):
			if dx * dx + dy * dy <= radius * radius:
				var x = cx + dx
				var y = cy + dy
				if is_valid(x, y):
					result.append(Vector2i(x, y))
	return result
