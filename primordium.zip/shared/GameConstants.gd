class_name GameConstants

# =============================================================
# GAME CONSTANTS
# Single source of truth for all tunable values.
# Change values here during development without hunting
# through multiple files.
# =============================================================


# -------------------------------------------------------------
# DEV MODE
# Set DEV_MODE = true during development to unlock the
# in-game console and dev overlay.
# Set to false before any public release.
# -------------------------------------------------------------
const DEV_MODE: bool = true
const DEV_PASSWORD: String = ""  # Optional: require password to open dev console in non-dev builds


# -------------------------------------------------------------
# TIME
# 1 real hour = 1 game day at normal speed.
# TICK_INTERVAL_SECONDS controls how often the server
# simulates. Lower = more frequent updates, more CPU.
# TICKS_PER_DAY must equal (3600 / TICK_INTERVAL_SECONDS).
# -------------------------------------------------------------
const TICK_INTERVAL_SECONDS: float = 6.0   # 1 real second = 10 game ticks... wait, see below
const TICKS_PER_DAY: int = 600             # 600 ticks * 6 seconds = 3600 seconds = 1 hour real time = 1 game day
const DAYS_PER_SEASON: int = 30
const SEASONS_PER_YEAR: int = 4
const DAYS_PER_YEAR: int = DAYS_PER_SEASON * SEASONS_PER_YEAR  # 120 game days = 5 real days

# Dev time multiplier - multiply tick speed for testing
# 1.0 = normal, 10.0 = 10x speed, 60.0 = 1 game day per minute
const DEV_TIMESCALE: float = 1.0  # Change this to speed up during testing


# -------------------------------------------------------------
# MAP
# -------------------------------------------------------------
const MAP_WIDTH: int = 200
const MAP_HEIGHT: int = 200
const TILE_WIDTH: int = 64   # Isometric tile width in pixels
const TILE_HEIGHT: int = 32  # Isometric tile height in pixels (2:1 ratio)

# How far from the map edge players can spawn
const SPAWN_MARGIN: int = 10

# Fog of war vision radius per unit type (in tiles)
const VISION_SETTLER: int = 6
const VISION_WORKER: int = 4
const VISION_SCOUT: int = 10
const VISION_SOLDIER: int = 6
const VISION_CITY: int = 8


# -------------------------------------------------------------
# PLAYERS
# -------------------------------------------------------------
const MAX_PLAYERS: int = 20
const STARTING_FOOD: float = 50.0
const STARTING_WOOD: float = 30.0
const STARTING_STONE: float = 20.0


# -------------------------------------------------------------
# RESOURCES
# Per-tile resource pool sizes and recovery rates.
# All values are per tick unless noted.
# -------------------------------------------------------------

# Forest tile
const FOREST_MAX_WOOD: float = 500.0
const FOREST_HARVEST_RATE: float = 0.5       # Wood harvested per woodcutter per tick
const FOREST_RECOVERY_RATE: float = 0.02     # Wood recovered per tick when not harvested
const FOREST_DEPLETED_THRESHOLD: float = 50.0  # Below this, tile looks sparse
const FOREST_BARREN_THRESHOLD: float = 10.0    # Below this, tile looks barren

# Grassland tile
const GRASSLAND_MAX_FOOD: float = 300.0
const GRASSLAND_HARVEST_RATE: float = 0.4
const GRASSLAND_RECOVERY_RATE: float = 0.03
const GRASSLAND_FERTILITY_BONUS: float = 1.5  # Multiplier when irrigated

# Hills tile
const HILLS_MAX_STONE: float = 800.0
const HILLS_HARVEST_RATE: float = 0.3
const HILLS_RECOVERY_RATE: float = 0.005     # Stone recovers very slowly
const HILLS_MAX_ORE: float = 400.0           # Future: metal ore

# Mountain tile
const MOUNTAIN_MAX_STONE: float = 2000.0
const MOUNTAIN_HARVEST_RATE: float = 0.2     # Harder to mine
const MOUNTAIN_RECOVERY_RATE: float = 0.001
const MOUNTAIN_MAX_ORE: float = 1000.0

# River tile
const RIVER_MAX_FOOD: float = 200.0          # Fish
const RIVER_HARVEST_RATE: float = 0.3
const RIVER_RECOVERY_RATE: float = 0.05      # Fish recover faster than forests
const RIVER_FRESH_WATER_BONUS: float = 1.3   # Adjacent tiles get a food bonus

# Coastal tile
const COASTAL_MAX_FOOD: float = 250.0
const COASTAL_HARVEST_RATE: float = 0.35
const COASTAL_RECOVERY_RATE: float = 0.04


# -------------------------------------------------------------
# POPULATION
# -------------------------------------------------------------
const CITY_STARTING_POP: int = 5
const CITY_STARTING_POP_CAP: int = 10
const POP_GROWTH_BASE_CHANCE: float = 0.05   # Per tick chance of growth when conditions are good
const POP_LOSS_HAPPINESS_THRESHOLD: float = 15.0
const POP_LOSS_STABILITY_THRESHOLD: float = 20.0


# -------------------------------------------------------------
# CITY
# -------------------------------------------------------------
const CITY_TERRITORY_RADIUS: int = 3         # Tiles a new city claims around it
const CITY_MAX_TERRITORY_RADIUS: int = 6     # Max expansion via growth
const CITY_CULTURE_EXPANSION_COST: float = 100.0  # Culture needed to expand territory by 1 ring


# -------------------------------------------------------------
# UNITS
# -------------------------------------------------------------
const SETTLER_FOOD_COST: int = 40
const SETTLER_PRODUCTION_COST: int = 60      # Production points to build
const WORKER_FOOD_COST: int = 20
const WORKER_PRODUCTION_COST: int = 30
const SOLDIER_FOOD_COST: int = 10            # Per turn upkeep
const SOLDIER_PRODUCTION_COST: int = 50
const SCOUT_FOOD_COST: int = 5
const SCOUT_PRODUCTION_COST: int = 20

# Unit speed in miles per tick at normal timescale
# Higher = faster. Adjust these to tune game pacing.
const UNIT_SPEED_MILES_PER_TICK: Dictionary = {
	"settler":  0.8,
	"worker":   1.0,
	"scout":    2.0,
	"soldier":  1.2,
	"cavalry":  2.5,
	"ship":     1.5
}

# Road multiplier - reduces effective tile miles
const ROAD_TRAVEL_MULTIPLIER: float = 0.6   # Roads cut travel distance by 40%

# Season travel penalties
const SEASON_TRAVEL_MULTIPLIER: Dictionary = {
	"spring":  1.0,
	"summer":  1.0,
	"autumn":  0.9,   # Mud slows movement slightly
	"winter":  0.6    # Snow and cold significantly slow movement
}


# -------------------------------------------------------------
# EVENTS
# -------------------------------------------------------------
const EVENT_FIRE_CHANCE_PER_TICK: float = 0.004   # ~2-3 events per game day
const EVENT_COOLDOWN_DAYS: int = 3                 # Min days between same event
const EVENT_EXPIRY_CRITICAL: int = 3               # Days before auto-resolve
const EVENT_EXPIRY_HIGH: int = 7
const EVENT_EXPIRY_MEDIUM: int = 14
const EVENT_EXPIRY_LOW: int = 30
const EVENT_HISTORY_CAP: int = 50


# -------------------------------------------------------------
# NETWORKING
# -------------------------------------------------------------
const SERVER_PORT: int = 7777
const MAX_CONNECTIONS: int = MAX_PLAYERS
const HEARTBEAT_INTERVAL: float = 5.0        # Seconds between server->client state pushes

# =============================================================
# WATER SYSTEM
# =============================================================
# City water storage
const WATER_STORAGE_BASE: float     = 100.0   # Starting well capacity
const WATER_STORAGE_CISTERN: float  = 400.0   # Added by cistern improvement
const WATER_STORAGE_MAX: float      = 2000.0  # Hard cap even with many cisterns

# Consumption per tick per population unit
const WATER_CONSUMPTION_PER_POP: float = 0.15

# How many tiles away a worked tile can feed water to city (without aqueduct)
const WATER_DRAW_RADIUS: int = 4

# Season water yield multipliers (rivers freeze, snowmelt varies)
const WATER_SEASON_MULTIPLIER: Dictionary = {
	"spring": 1.4,   # Snowmelt bonus
	"summer": 0.9,   # Dry season
	"autumn": 1.0,
	"winter": 0.3    # Frozen — rivers yield almost nothing
}

# Penalties when water is low
const WATER_LOW_THRESHOLD: float      = 0.25  # Below 25% storage = low
const WATER_CRITICAL_THRESHOLD: float = 0.05  # Below 5% = critical

# Food yield penalty when water is critical (crops wither)
const WATER_CRITICAL_FOOD_PENALTY: float = 0.60  # 60% reduction

# Happiness penalty per tick when water is low/critical
const WATER_LOW_HAPPINESS_PENALTY: float      = 0.5
const WATER_CRITICAL_HAPPINESS_PENALTY: float = 2.0
const RECONNECT_TIMEOUT: float = 30.0        # Seconds before disconnected player is considered offline


# -------------------------------------------------------------
# SAVING
# -------------------------------------------------------------
const SAVE_INTERVAL_TICKS: int = 100         # Auto-save every 100 ticks (~10 real minutes)
const SAVE_PATH: String = "user://world_save.json"
const SAVE_BACKUP_PATH: String = "user://world_save_backup.json"


# -------------------------------------------------------------
# TECH TREE
# -------------------------------------------------------------
const RESEARCH_BASE_GOAL: float = 100.0
const RESEARCH_GOAL_SCALING: float = 1.6     # Each tech costs 60% more than the last


# -------------------------------------------------------------
# SEASONS
# Effect multipliers applied to resource yields each season
# -------------------------------------------------------------
const SEASON_MODIFIERS: Dictionary = {
	"spring": { "food": 1.3, "wood": 1.0, "stone": 1.0, "pop_growth": 1.3 },
	"summer": { "food": 1.1, "wood": 1.1, "stone": 1.0, "pop_growth": 1.1 },
	"autumn": { "food": 0.8, "wood": 1.2, "stone": 1.0, "pop_growth": 0.8 },
	"winter": { "food": 0.3, "wood": 0.8, "stone": 0.9, "pop_growth": 0.2 }
}

const SEASON_NAMES: Array = ["spring", "summer", "autumn", "winter"]


# -------------------------------------------------------------
# HELPER: get effective tick interval accounting for dev timescale
# Call this instead of TICK_INTERVAL_SECONDS directly
# -------------------------------------------------------------
static func get_tick_interval() -> float:
	return TICK_INTERVAL_SECONDS / DEV_TIMESCALE
