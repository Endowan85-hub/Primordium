class_name TileTypes

# =============================================================
# TILE TYPES
# Defines every tile type in the game, what resources it holds,
# what it looks like at each depletion state, and what
# improvements can be built on it.
# =============================================================


enum Type {
	GRASSLAND,
	FOREST,
	HILLS,
	MOUNTAIN,
	RIVER,
	COASTAL,
	OCEAN,
	DESERT,
	TUNDRA,
	SNOW
}

# Visual depletion states — each tile type has sprites for these
enum DepletionState {
	FULL,      # Resource at 100%
	SPARSE,    # Resource below DEPLETED_THRESHOLD
	BARREN,    # Resource below BARREN_THRESHOLD
	EMPTY      # Resource at 0 — tile type changes visually
}

# Tile improvements players can build
enum Improvement {
	NONE,
	FARM,         # On grassland — boosts food yield
	LUMBER_CAMP,  # On forest — boosts wood harvest, accelerates depletion
	MINE,         # On hills/mountain — boosts stone/ore harvest
	FISHING_HUT,  # On river/coastal — boosts food harvest
	WELL,         # Any tile — draws water_yield into city water storage
	IRRIGATION,   # On grassland near river/well — boosts food yield and recovery
	ROAD,         # Any tile — reduces movement cost
	REPLANTED,    # On barren former-forest — begins slow recovery
	FORT,         # Any tile — military defensive bonus
	WATCHTOWER,   # Any tile — increases vision radius
	CISTERN,      # In city tile — increases city water storage cap
	AQUEDUCT,     # Any tile — extends water from river tiles to distant cities
}

# What each tile type produces and its resource keys
# Every tile has food, wood, stone at varying levels.
# water_yield = passive water units per tick (not a depleting pool).
# primary = the resource that drives the depletion visual state.
const TILE_RESOURCES: Dictionary = {
	Type.GRASSLAND: {
		"primary": "food",
		"max": { "food": 60.0,  "wood": 15.0,  "stone": 40.0  },
		"harvest_rate":  { "food": 0.08, "wood": 0.02, "stone": 0.05 },
		"recovery_rate": { "food": 0.02, "wood": 0.01, "stone": 0.005 },
		"water_yield": 2.0,   # Soil moisture, small streams
		"tile_miles": 10,
		"improvements_allowed": [Improvement.FARM, Improvement.WELL, Improvement.IRRIGATION,
			Improvement.ROAD, Improvement.FORT, Improvement.WATCHTOWER]
	},
	Type.FOREST: {
		"primary": "wood",
		"max": { "food": 80.0,  "wood": 500.0, "stone": 60.0  },
		"harvest_rate":  { "food": 0.10, "wood": 0.50, "stone": 0.06 },
		"recovery_rate": { "food": 0.02, "wood": 0.02, "stone": 0.004 },
		"water_yield": 3.0,   # Forest canopy retains moisture, forest streams
		"tile_miles": 20,
		"improvements_allowed": [Improvement.LUMBER_CAMP, Improvement.WELL,
			Improvement.ROAD, Improvement.FORT, Improvement.WATCHTOWER]
	},
	Type.HILLS: {
		"primary": "stone",
		"max": { "food": 30.0,  "wood": 40.0,  "stone": 800.0 },
		"harvest_rate":  { "food": 0.04, "wood": 0.05, "stone": 0.30 },
		"recovery_rate": { "food": 0.01, "wood": 0.008,"stone": 0.005 },
		"water_yield": 3.5,   # Hill springs and runoff
		"tile_miles": 20,
		"improvements_allowed": [Improvement.MINE, Improvement.WELL,
			Improvement.ROAD, Improvement.FORT, Improvement.WATCHTOWER]
	},
	Type.MOUNTAIN: {
		"primary": "stone",
		"max": { "food": 10.0,  "wood": 20.0,  "stone": 2000.0 },
		"harvest_rate":  { "food": 0.01, "wood": 0.02, "stone": 0.20 },
		"recovery_rate": { "food": 0.005,"wood": 0.005,"stone": 0.001 },
		"water_yield": 4.0,   # Snowmelt streams, reliable year-round
		"tile_miles": 40,
		"improvements_allowed": [Improvement.MINE, Improvement.WATCHTOWER]
	},
	Type.RIVER: {
		"primary": "food",
		"max": { "food": 200.0, "wood": 60.0,  "stone": 80.0  },
		"harvest_rate":  { "food": 0.30, "wood": 0.08, "stone": 0.08 },
		"recovery_rate": { "food": 0.05, "wood": 0.02, "stone": 0.01 },
		"water_yield": 8.0,   # Direct river access — highest water yield
		"tile_miles": 8,
		"improvements_allowed": [Improvement.FISHING_HUT, Improvement.WELL,
			Improvement.ROAD, Improvement.FORT]
	},
	Type.COASTAL: {
		"primary": "food",
		"max": { "food": 220.0, "wood": 20.0,  "stone": 60.0  },
		"harvest_rate":  { "food": 0.28, "wood": 0.02, "stone": 0.06 },
		"recovery_rate": { "food": 0.04, "wood": 0.01, "stone": 0.005 },
		"water_yield": 4.0,   # Coastal freshwater, brackish — needs purification later
		"tile_miles": 8,
		"improvements_allowed": [Improvement.FISHING_HUT, Improvement.WELL,
			Improvement.ROAD, Improvement.FORT]
	},
	Type.OCEAN: {
		"primary": "food",
		"max": { "food": 180.0, "wood": 5.0,   "stone": 10.0  },
		"harvest_rate":  { "food": 0.25, "wood": 0.005,"stone": 0.01 },
		"recovery_rate": { "food": 0.06, "wood": 0.002,"stone": 0.001 },
		"water_yield": 0.0,   # Salt water — not usable without tech
		"tile_miles": 12,
		"improvements_allowed": []
	},
	Type.DESERT: {
		"primary": "stone",
		"max": { "food": 15.0,  "wood": 8.0,   "stone": 120.0 },
		"harvest_rate":  { "food": 0.02, "wood": 0.01, "stone": 0.08 },
		"recovery_rate": { "food": 0.008,"wood": 0.003,"stone": 0.002 },
		"water_yield": 0.2,   # Near zero — oasis tiles handled separately later
		"tile_miles": 10,
		"improvements_allowed": [Improvement.MINE, Improvement.WELL,
			Improvement.ROAD, Improvement.FORT, Improvement.WATCHTOWER]
	},
	Type.TUNDRA: {
		"primary": "food",
		"max": { "food": 25.0,  "wood": 25.0,  "stone": 200.0 },
		"harvest_rate":  { "food": 0.03, "wood": 0.03, "stone": 0.10 },
		"recovery_rate": { "food": 0.01, "wood": 0.008,"stone": 0.003 },
		"water_yield": 2.0,   # Frozen ground thaws seasonally
		"tile_miles": 25,
		"improvements_allowed": [Improvement.MINE, Improvement.WELL,
			Improvement.ROAD, Improvement.FORT, Improvement.WATCHTOWER]
	},
	Type.SNOW: {
		"primary": "stone",
		"max": { "food": 5.0,   "wood": 8.0,   "stone": 150.0 },
		"harvest_rate":  { "food": 0.005,"wood": 0.008,"stone": 0.05 },
		"recovery_rate": { "food": 0.002, "wood": 0.002,"stone": 0.001 },
		"water_yield": 1.5,   # Snowmelt but frozen much of year
		"tile_miles": 35,
		"improvements_allowed": [Improvement.WATCHTOWER]
	}
}

# Improvement effects — what each improvement does to a tile
const IMPROVEMENT_EFFECTS: Dictionary = {
	Improvement.FARM: {
		"harvest_multiplier": { "food": 5.0 },   # Farming is ~5x foraging
		"cap_multiplier":     { "food": 4.0 },   # Also raises tile food cap
		"recovery_multiplier": { "food": 2.0 },
		"build_cost": { "wood": 20, "stone": 5 },
		"build_time_ticks": 50
	},
	Improvement.LUMBER_CAMP: {
		"harvest_multiplier": { "wood": 2.0 },
		"recovery_multiplier": { "wood": 0.5 },   # Faster harvest but slower recovery — trade-off
		"build_cost": { "wood": 10, "stone": 5 },
		"build_time_ticks": 30
	},
	Improvement.MINE: {
		"harvest_multiplier": { "stone": 2.5 },
		"recovery_multiplier": { "stone": 0.4 },
		"build_cost": { "wood": 25, "stone": 10 },
		"build_time_ticks": 80
	},
	Improvement.FISHING_HUT: {
		"harvest_multiplier": { "food": 2.5 },   # Organized fishing beats casual fishing
		"recovery_multiplier": { "food": 1.2 },
		"build_cost": { "wood": 15, "stone": 5 },
		"build_time_ticks": 40
	},
	Improvement.IRRIGATION: {
		"harvest_multiplier": { "food": 1.5 },
		"recovery_multiplier": { "food": 2.0 },   # Dramatically speeds up food recovery
		"build_cost": { "wood": 10, "stone": 15 },
		"build_time_ticks": 60,
		"requires_adjacent": "river"               # Must be next to a river tile
	},
	Improvement.ROAD: {
		"travel_miles_override": 6,                # Roads reduce any tile to 6 miles regardless of terrain
		"build_cost": { "wood": 5, "stone": 10 },
		"build_time_ticks": 20
	},
	Improvement.REPLANTED: {
		"harvest_multiplier": { "wood": 0.2 },     # Very low yield while regrowing
		"recovery_multiplier": { "wood": 4.0 },    # But recovers fast
		"build_cost": { "food": 10 },
		"build_time_ticks": 10
	},
	Improvement.FORT: {
		"defense_bonus": 2.0,                      # Military defense multiplier
		"build_cost": { "wood": 40, "stone": 60 },
		"build_time_ticks": 150
	},
	Improvement.WATCHTOWER: {
		"vision_bonus": 2,
		"build_cost": { "wood": 20, "stone": 20 },
		"build_time_ticks": 60
	},
	Improvement.WELL: {
		# Multiplies the tile's water_yield drawn per tick
		"water_yield_multiplier": 3.0,
		"build_cost": { "wood": 15, "stone": 25 },
		"build_time_ticks": 50
	},
	Improvement.CISTERN: {
		# Built on city tile — increases city water storage cap
		"water_storage_bonus": 400,
		"build_cost": { "wood": 10, "stone": 60 },
		"build_time_ticks": 80
	},
	Improvement.AQUEDUCT: {
		# Carries water from high-yield tile to city regardless of distance
		"water_range_override": 20,   # tiles
		"build_cost": { "wood": 20, "stone": 100 },
		"build_time_ticks": 200
	}
}

# Tile display names for UI
const TILE_NAMES: Dictionary = {
	Type.GRASSLAND: "Grassland",
	Type.FOREST:    "Forest",
	Type.HILLS:     "Hills",
	Type.MOUNTAIN:  "Mountain",
	Type.RIVER:     "River",
	Type.COASTAL:   "Coastal",
	Type.OCEAN:     "Ocean",
	Type.DESERT:    "Desert",
	Type.TUNDRA:    "Tundra",
	Type.SNOW:      "Snow"
}

const IMPROVEMENT_NAMES: Dictionary = {
	Improvement.NONE:        "None",
	Improvement.FARM:        "Farm",
	Improvement.LUMBER_CAMP: "Lumber Camp",
	Improvement.MINE:        "Mine",
	Improvement.FISHING_HUT: "Fishing Hut",
	Improvement.WELL:        "Well",
	Improvement.IRRIGATION:  "Irrigation",
	Improvement.ROAD:        "Road",
	Improvement.REPLANTED:   "Replanted",
	Improvement.FORT:        "Fort",
	Improvement.WATCHTOWER:  "Watchtower",
	Improvement.CISTERN:     "Cistern",
	Improvement.AQUEDUCT:    "Aqueduct",
}


# Returns effective miles to cross a tile accounting for improvement
static func get_tile_miles(tile_type: Type, improvement: Improvement, season: String) -> float:
	var data = TILE_RESOURCES.get(tile_type, {})
	var base_miles = float(data.get("tile_miles", 10))

	# Road overrides terrain entirely
	if improvement == Improvement.ROAD:
		var road_effect = IMPROVEMENT_EFFECTS.get(Improvement.ROAD, {})
		base_miles = float(road_effect.get("travel_miles_override", 6))
		return base_miles

	# Season multiplier
	var season_mult = GameConstants.SEASON_TRAVEL_MULTIPLIER.get(season, 1.0)
	# Season slows movement so divide (more miles = slower)
	base_miles = base_miles / season_mult

	return base_miles


# Returns travel time in ticks for a unit to cross a tile
static func get_travel_ticks(tile_type: Type, improvement: Improvement,
		season: String, unit_type: String) -> float:
	var miles = get_tile_miles(tile_type, improvement, season)
	var speed = GameConstants.UNIT_SPEED_MILES_PER_TICK.get(unit_type, 1.0)
	if speed <= 0:
		return 999.0
	return miles / speed


# Returns a human readable travel time string
static func get_travel_time_string(ticks: float) -> String:
	var real_seconds = ticks * GameConstants.TICK_INTERVAL_SECONDS
	if real_seconds < 60:
		return str(int(real_seconds)) + "s"
	elif real_seconds < 3600:
		return str(int(real_seconds / 60)) + "m"
	else:
		return str(snappedf(real_seconds / 3600.0, 0.1)) + "h"


# Returns the depletion state of a tile based on current vs max resource
static func get_depletion_state(current: float, max_val: float) -> DepletionState:
	if max_val <= 0:
		return DepletionState.EMPTY
	var pct = current / max_val
	if pct <= 0.0:
		return DepletionState.EMPTY
	elif pct <= 0.05:
		return DepletionState.BARREN
	elif pct <= 0.25:
		return DepletionState.SPARSE
	else:
		return DepletionState.FULL


# Returns true if a given improvement can be built on a given tile type
static func can_build_improvement(tile_type: Type, improvement: Improvement) -> bool:
	var data = TILE_RESOURCES.get(tile_type, {})
	var allowed = data.get("improvements_allowed", [])
	return improvement in allowed
